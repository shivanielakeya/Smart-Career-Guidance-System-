"""
Test module for Phase 3 Recommendation Engine.

This module tests the recommendation system with different student profiles:
- Engineering-oriented (PCM, high quantitative/logical aptitude)
- Medical-oriented (PCB, high data interpretation aptitude)
- Commerce-oriented (Commerce, high analytical aptitude)
- Arts/Design-oriented (Arts, high verbal aptitude)
"""

import sys
from datetime import datetime
from sqlalchemy.orm import Session

# Add backend to path
sys.path.insert(0, '/mnt/user-data/outputs/career-guidance-system-combined/backend')

from app.db.session import SessionLocal, engine
from app.db.base import Base
from app.db.models.user import User
from app.db.models.student_profile import StudentProfile
from app.db.models.education_record import EducationRecord
from app.db.models.aptitude_result import AptitudeResult
from app.db.models.aptitude_response import AptitudeResponse
from app.db.models.interest_response import InterestResponse
from app.db.models.interest_question import InterestQuestion
from app.db.models.interest_option import InterestOption
from app.services.recommendation_service import RecommendationService
from app.core.security import get_password_hash


def create_test_interest_data(db: Session):
    """Create test interest questions and options if they don't exist."""
    existing_questions = db.query(InterestQuestion).count()
    
    if existing_questions == 0:
        # Create sample interest questions
        interest_data = [
            {
                'question': 'I enjoy solving mathematical problems',
                'options': {
                    'A': 'Technology',
                    'B': 'Finance',
                    'C': 'Science',
                    'D': 'Engineering',
                }
            },
            {
                'question': 'I like working with people and helping them',
                'options': {
                    'A': 'Healthcare',
                    'B': 'Social Work',
                    'C': 'Education',
                    'D': 'Business',
                }
            },
            {
                'question': 'I enjoy creative and artistic activities',
                'options': {
                    'A': 'Design',
                    'B': 'Arts',
                    'C': 'Media',
                    'D': 'Entertainment',
                }
            },
        ]
        
        for item in interest_data:
            q = InterestQuestion(question=item['question'])
            db.add(q)
            db.flush()
            
            for key, category in item['options'].items():
                opt = InterestOption(question_id=q.id, option_key=key, category=category)
                db.add(opt)
        
        db.commit()
        print("✓ Interest data created")
    else:
        print(f"✓ Interest data exists ({existing_questions} questions)")


def create_test_profile_engineering(db: Session) -> tuple:
    """Create engineering-oriented student profile (PCM, high quant/logical aptitude)."""
    # User
    user = User(
        email='engineer@test.local',
        hashed_password=get_password_hash('password123'),
        is_active=True,
    )
    db.add(user)
    db.flush()
    
    # Profile
    profile = StudentProfile(
        user_id=user.id,
        full_name='Rajesh Kumar',
        date_of_birth=datetime(2006, 3, 15).date(),
        gender='Male',
        contact_number='9876543210',
        district='Chennai',
        state='Tamil Nadu',
        school='Anna Senior Secondary School',
        school_type='CBSE',
    )
    db.add(profile)
    db.flush()
    
    # 10th Education
    edu_10th = EducationRecord(
        student_profile_id=profile.id,
        level='10th',
        board='CBSE',
        total_marks=500,
        marks_obtained=450,
        percentage=90.0,
    )
    db.add(edu_10th)
    
    # 12th Education (PCM)
    edu_12th = EducationRecord(
        student_profile_id=profile.id,
        level='12th',
        board='CBSE',
        stream='PCM',
        total_marks=500,
        marks_obtained=430,
        percentage=86.0,
    )
    db.add(edu_12th)
    db.flush()
    
    # Aptitude Results (high quantitative and logical reasoning)
    aptitude = AptitudeResult(
        student_profile_id=profile.id,
        overall_score=88.0,
        quantitative_score=92.0,
        logical_score=85.0,
        analytical_score=80.0,
        verbal_score=75.0,
        data_interpretation_score=82.0,
    )
    db.add(aptitude)
    db.flush()
    
    # Interest Responses (Technology, Engineering, Finance)
    interest_q = db.query(InterestQuestion).first()
    if interest_q:
        for category in ['Technology', 'Engineering', 'Finance']:
            response = InterestResponse(
                student_profile_id=profile.id,
                question_id=interest_q.id,
                option_key='A',
                category=category,
            )
            db.add(response)
    
    db.commit()
    return user.id, profile.id


def create_test_profile_medical(db: Session) -> tuple:
    """Create medical-oriented student profile (PCB, high data interpretation aptitude)."""
    # User
    user = User(
        email='doctor@test.local',
        hashed_password=get_password_hash('password123'),
        is_active=True,
    )
    db.add(user)
    db.flush()
    
    # Profile
    profile = StudentProfile(
        user_id=user.id,
        full_name='Priya Sharma',
        date_of_birth=datetime(2006, 5, 22).date(),
        gender='Female',
        contact_number='9876543211',
        district='Coimbatore',
        state='Tamil Nadu',
        school='Vidyashram Matriculation School',
        school_type='State Board',
    )
    db.add(profile)
    db.flush()
    
    # 10th Education
    edu_10th = EducationRecord(
        student_profile_id=profile.id,
        level='10th',
        board='State Board',
        total_marks=600,
        marks_obtained=540,
        percentage=90.0,
    )
    db.add(edu_10th)
    
    # 12th Education (PCB)
    edu_12th = EducationRecord(
        student_profile_id=profile.id,
        level='12th',
        board='State Board',
        stream='PCB',
        total_marks=600,
        marks_obtained=525,
        percentage=87.5,
    )
    db.add(edu_12th)
    db.flush()
    
    # Aptitude Results (high data interpretation and logical reasoning)
    aptitude = AptitudeResult(
        student_profile_id=profile.id,
        overall_score=85.0,
        quantitative_score=78.0,
        logical_score=88.0,
        analytical_score=82.0,
        verbal_score=80.0,
        data_interpretation_score=90.0,
    )
    db.add(aptitude)
    db.flush()
    
    # Interest Responses (Healthcare, Science)
    interest_q = db.query(InterestQuestion).first()
    if interest_q:
        for category in ['Healthcare', 'Science', 'Medical']:
            response = InterestResponse(
                student_profile_id=profile.id,
                question_id=interest_q.id,
                option_key='B',
                category=category,
            )
            db.add(response)
    
    db.commit()
    return user.id, profile.id


def create_test_profile_commerce(db: Session) -> tuple:
    """Create commerce-oriented student profile (Commerce stream, high analytical aptitude)."""
    # User
    user = User(
        email='ca@test.local',
        hashed_password=get_password_hash('password123'),
        is_active=True,
    )
    db.add(user)
    db.flush()
    
    # Profile
    profile = StudentProfile(
        user_id=user.id,
        full_name='Arjun Nair',
        date_of_birth=datetime(2006, 7, 10).date(),
        gender='Male',
        contact_number='9876543212',
        district='Bangalore',
        state='Karnataka',
        school='National Public School',
        school_type='ICSE',
    )
    db.add(profile)
    db.flush()
    
    # 10th Education
    edu_10th = EducationRecord(
        student_profile_id=profile.id,
        level='10th',
        board='ICSE',
        total_marks=600,
        marks_obtained=510,
        percentage=85.0,
    )
    db.add(edu_10th)
    
    # 12th Education (Commerce)
    edu_12th = EducationRecord(
        student_profile_id=profile.id,
        level='12th',
        board='ICSE',
        stream='Commerce',
        total_marks=600,
        marks_obtained=480,
        percentage=80.0,
    )
    db.add(edu_12th)
    db.flush()
    
    # Aptitude Results (high analytical and data interpretation)
    aptitude = AptitudeResult(
        student_profile_id=profile.id,
        overall_score=82.0,
        quantitative_score=85.0,
        logical_score=80.0,
        analytical_score=88.0,
        verbal_score=78.0,
        data_interpretation_score=86.0,
    )
    db.add(aptitude)
    db.flush()
    
    # Interest Responses (Finance, Business)
    interest_q = db.query(InterestQuestion).first()
    if interest_q:
        for category in ['Finance', 'Business', 'Accounting']:
            response = InterestResponse(
                student_profile_id=profile.id,
                question_id=interest_q.id,
                option_key='C',
                category=category,
            )
            db.add(response)
    
    db.commit()
    return user.id, profile.id


def create_test_profile_arts_design(db: Session) -> tuple:
    """Create arts/design-oriented student profile (Arts, high verbal aptitude)."""
    # User
    user = User(
        email='designer@test.local',
        hashed_password=get_password_hash('password123'),
        is_active=True,
    )
    db.add(user)
    db.flush()
    
    # Profile
    profile = StudentProfile(
        user_id=user.id,
        full_name='Meera Patel',
        date_of_birth=datetime(2006, 11, 8).date(),
        gender='Female',
        contact_number='9876543213',
        district='Mumbai',
        state='Maharashtra',
        school='Cathedral High School',
        school_type='ICSE',
    )
    db.add(profile)
    db.flush()
    
    # 10th Education
    edu_10th = EducationRecord(
        student_profile_id=profile.id,
        level='10th',
        board='ICSE',
        total_marks=600,
        marks_obtained=480,
        percentage=80.0,
    )
    db.add(edu_10th)
    
    # 12th Education (Arts)
    edu_12th = EducationRecord(
        student_profile_id=profile.id,
        level='12th',
        board='ICSE',
        stream='Arts',
        total_marks=600,
        marks_obtained=420,
        percentage=70.0,
    )
    db.add(edu_12th)
    db.flush()
    
    # Aptitude Results (high verbal ability)
    aptitude = AptitudeResult(
        student_profile_id=profile.id,
        overall_score=75.0,
        quantitative_score=65.0,
        logical_score=72.0,
        analytical_score=70.0,
        verbal_score=88.0,
        data_interpretation_score=68.0,
    )
    db.add(aptitude)
    db.flush()
    
    # Interest Responses (Design, Arts, Media)
    interest_q = db.query(InterestQuestion).first()
    if interest_q:
        for category in ['Design', 'Arts', 'Media', 'Creative']:
            response = InterestResponse(
                student_profile_id=profile.id,
                question_id=interest_q.id,
                option_key='D',
                category=category,
            )
            db.add(response)
    
    db.commit()
    return user.id, profile.id


def test_recommendations():
    """Test the recommendation engine with different student profiles."""
    print("\n" + "="*70)
    print("PHASE 3 RECOMMENDATION ENGINE TEST")
    print("="*70 + "\n")
    
    db = SessionLocal()
    
    try:
        # Create interest data
        print("Creating test data...")
        create_test_interest_data(db)
        
        # Create test profiles
        print("\nCreating test student profiles...")
        eng_user_id, eng_profile_id = create_test_profile_engineering(db)
        print(f"✓ Engineering profile created (user_id={eng_user_id}, profile_id={eng_profile_id})")
        
        med_user_id, med_profile_id = create_test_profile_medical(db)
        print(f"✓ Medical profile created (user_id={med_user_id}, profile_id={med_profile_id})")
        
        com_user_id, com_profile_id = create_test_profile_commerce(db)
        print(f"✓ Commerce profile created (user_id={com_user_id}, profile_id={com_profile_id})")
        
        art_user_id, art_profile_id = create_test_profile_arts_design(db)
        print(f"✓ Arts/Design profile created (user_id={art_user_id}, profile_id={art_profile_id})")
        
        # Test recommendation service methods
        print("\n" + "="*70)
        print("TESTING RECOMMENDATION SERVICE")
        print("="*70 + "\n")
        
        # Test Engineering Profile
        print("TEST 1: Engineering-Oriented Student (PCM, High Quantitative Aptitude)")
        print("-" * 70)
        edu_12th = RecommendationService.get_12th_education(db, eng_profile_id)
        print(f"Stream: {edu_12th.stream if edu_12th else 'N/A'}")
        print(f"12th Percentage: {edu_12th.percentage if edu_12th else 'N/A'}%")
        
        eligibility, streams = RecommendationService.calculate_academic_eligibility(edu_12th)
        print(f"Academic Eligibility Score: {eligibility}")
        print(f"Eligible Streams: {streams}")
        
        stream_cat = RecommendationService.stream_to_category(edu_12th.stream if edu_12th else None)
        print(f"Stream Category: {stream_cat}")
        
        interest_scores = RecommendationService.compute_interest_scores(db, eng_profile_id)
        print(f"Interest Scores: {interest_scores}")
        
        aptitude_result = db.query(AptitudeResult).filter_by(student_profile_id=eng_profile_id).first()
        aptitude_scores = RecommendationService.get_aptitude_scores(aptitude_result)
        print(f"Aptitude Overall: {aptitude_result.overall_score}")
        print(f"Top Aptitude Category: Quantitative ({aptitude_scores['Quantitative Ability']}%)")
        
        # Test Medical Profile
        print("\n\nTEST 2: Medical-Oriented Student (PCB, High Data Interpretation)")
        print("-" * 70)
        edu_12th = RecommendationService.get_12th_education(db, med_profile_id)
        print(f"Stream: {edu_12th.stream if edu_12th else 'N/A'}")
        print(f"12th Percentage: {edu_12th.percentage if edu_12th else 'N/A'}%")
        
        stream_cat = RecommendationService.stream_to_category(edu_12th.stream if edu_12th else None)
        print(f"Stream Category: {stream_cat}")
        print(f"Medical stream correctly identified: {stream_cat == 'PCB'}")
        
        # Test Commerce Profile
        print("\n\nTEST 3: Commerce-Oriented Student")
        print("-" * 70)
        edu_12th = RecommendationService.get_12th_education(db, com_profile_id)
        stream_cat = RecommendationService.stream_to_category(edu_12th.stream if edu_12th else None)
        print(f"Stream: {edu_12th.stream if edu_12th else 'N/A'}")
        print(f"Stream Category: {stream_cat}")
        print(f"Commerce stream correctly identified: {stream_cat == 'Commerce'}")
        
        # Test Arts Profile
        print("\n\nTEST 4: Arts/Design-Oriented Student")
        print("-" * 70)
        edu_12th = RecommendationService.get_12th_education(db, art_profile_id)
        stream_cat = RecommendationService.stream_to_category(edu_12th.stream if edu_12th else None)
        print(f"Stream: {edu_12th.stream if edu_12th else 'N/A'}")
        print(f"Stream Category: {stream_cat}")
        print(f"Arts stream correctly identified: {stream_cat == 'Arts'}")
        
        # College eligibility test
        print("\n\nTEST 5: College Eligibility Filtering")
        print("-" * 70)
        test_colleges = [
            {'name': 'Anna University', 'cutoff': 180},
            {'name': 'IIT Madras', 'cutoff': 200},
            {'name': 'VIT', 'cutoff': 160},
        ]
        
        for college in test_colleges:
            is_eligible, match_pct = RecommendationService.get_college_eligibility(
                edu_12th.percentage if edu_12th else 80, college['cutoff']
            )
            status = "ELIGIBLE ✓" if is_eligible else "POTENTIAL"
            print(f"{college['name']} (Cutoff: {college['cutoff']}): {status} ({match_pct:.1f}%)")
        
        print("\n" + "="*70)
        print("ALL TESTS COMPLETED SUCCESSFULLY ✓")
        print("="*70 + "\n")
        
    except Exception as e:
        print(f"\n✗ Test failed with error: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()


if __name__ == '__main__':
    test_recommendations()
