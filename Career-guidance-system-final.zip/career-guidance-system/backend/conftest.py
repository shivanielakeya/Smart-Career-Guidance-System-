import os
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

# Set environment variables BEFORE importing from app
os.environ["DATABASE_URL"] = "sqlite:///./test.db"
os.environ["JWT_SECRET"] = "test-secret-key-for-testing-only"
os.environ["CORS_ORIGINS"] = '["http://localhost:5173"]'
os.environ["ADMIN_SETUP_KEY"] = "test-admin-setup-key"

from app.db.base import Base
from app.db.session import SessionLocal
from app.db.seed import seed_database
from app.main import app
from app.core.dependencies import get_db


# Create test database
SQLALCHEMY_TEST_DATABASE_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLALCHEMY_TEST_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


@pytest.fixture(scope="function")
def test_db(request):
    """Create a fresh database for each test"""
    Base.metadata.create_all(bind=engine)
    if request.node.fspath.basename == "test_phase5_features.py":
        seed_database(SQLALCHEMY_TEST_DATABASE_URL)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="function")
def client(test_db):
    """Create a test client with fresh database"""
    app.dependency_overrides[get_db] = override_get_db
    
    with TestClient(app) as test_client:
        yield test_client
    
    app.dependency_overrides.clear()


@pytest.fixture
def test_user_data():
    """Test user data"""
    return {
        "email": "testuser@example.com",
        "password": "testpass123",
    }


@pytest.fixture
def test_student_profile_data():
    """Test student profile data"""
    return {
        "full_name": "John Doe",
        "date_of_birth": "2005-03-15",
        "gender": "Male",
        "contact_number": "9876543210",
        "district": "Chennai",
        "state": "Tamil Nadu",
        "school": "Government School",
        "school_type": "Government",
        "parent_name": "Jane Doe",
        "parent_contact": "9876543210"
    }


@pytest.fixture
def test_education_data():
    """Test education record data"""
    return {
        "level": "12th",
        "board": "CBSE",
        "year": 2023,
        "total_marks": 500,
        "marks_obtained": 450,
        "percentage": 90.0,
        "stream": "PCM"
    }


@pytest.fixture
def test_career_data():
    """Test career data"""
    return {
        "name": "Software Developer",
        "category": "Technology",
        "description": "Build and maintain software applications",
        "course": "B.Tech Computer Science",
        "college": "Anna University",
        "aptitude_match_categories": ["Quantitative Ability", "Logical Reasoning"],
        "base_score": 70.0,
        "suitable_streams": ["PCM", "Science"],
        "min_percentage": 75.0
    }


@pytest.fixture
def test_college_data():
    """Test college data"""
    return {
        "name": "Anna University",
        "category": "Engineering",
        "city": "Chennai",
        "district": "Chennai",
        "state": "Tamil Nadu",
        "cutoff": 90.0,
        "courses": ["B.Tech Computer Science"],
        "career_opportunities": ["Software Developer"]
    }
