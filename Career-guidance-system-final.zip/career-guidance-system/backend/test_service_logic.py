"""
Unit tests for Recommendation Service - Phase 3.

Tests the business logic without requiring database connections.
"""

import sys
sys.path.insert(0, '/mnt/user-data/outputs/career-guidance-system-combined/backend')

from app.services.recommendation_service import RecommendationService


def test_stream_categorization():
    """Test stream to category conversion."""
    print("\n" + "="*70)
    print("TEST 1: Stream Categorization")
    print("="*70)
    
    test_cases = [
        ('PCM', 'PCM'),
        ('Physics Chemistry Mathematics', 'PCM'),
        ('PCB', 'PCB'),
        ('Physics Chemistry Biology', 'PCB'),
        ('COMMERCE', 'Commerce'),
        ('ARTS', 'Arts'),
        ('Science (General)', 'Science'),
        ('', None),
        (None, None),
    ]
    
    for stream_input, expected in test_cases:
        result = RecommendationService.stream_to_category(stream_input)
        status = "✓" if result == expected else "✗"
        print(f"{status} {stream_input:30} -> {result:15} (expected: {expected})")
    
    print()


def test_academic_eligibility():
    """Test academic eligibility scoring."""
    print("="*70)
    print("TEST 2: Academic Eligibility Calculation")
    print("="*70)
    
    class MockEducation:
        def __init__(self, percentage, stream):
            self.percentage = percentage
            self.stream = stream
    
    test_cases = [
        (92.0, 'PCM', 95.0, ['PCM', 'PCB', 'Commerce', 'Arts']),
        (85.0, 'PCB', 85.0, ['PCM', 'PCB', 'Commerce', 'Arts']),
        (75.0, 'Commerce', 75.0, ['PCM', 'Commerce', 'Arts']),
        (65.0, 'Arts', 65.0, ['Commerce', 'Arts']),
        (55.0, 'Science', 50.0, ['Arts']),
    ]
    
    for percentage, stream, expected_score, expected_streams in test_cases:
        education = MockEducation(percentage, stream)
        score, streams = RecommendationService.calculate_academic_eligibility(education)
        
        score_match = score == expected_score
        streams_match = streams == expected_streams
        status = "✓" if (score_match and streams_match) else "✗"
        
        print(f"{status} {percentage}% -> Score: {score} (exp: {expected_score}), Streams: {len(streams)} (exp: {len(expected_streams)})")
    
    print()


def test_college_eligibility():
    """Test college eligibility filtering."""
    print("="*70)
    print("TEST 3: College Eligibility Filtering")
    print("="*70)
    
    test_cases = [
        (190, 180, True, 105.6),   # Above cutoff
        (180, 180, True, 100.0),   # Exactly at cutoff
        (170, 180, False, 94.4),   # Below cutoff but close
        (150, 180, False, 83.3),   # Well below cutoff
        (200, 200, True, 100.0),   # High achiever
    ]
    
    for marks, cutoff, expected_eligible, _ in test_cases:
        is_eligible, match_pct = RecommendationService.get_college_eligibility(marks, cutoff)
        
        status = "✓" if is_eligible == expected_eligible else "✗"
        print(f"{status} {marks} marks, {cutoff} cutoff -> Eligible: {is_eligible}, Match: {match_pct:.1f}%")
    
    print()


def test_interest_scoring():
    """Test interest score computation."""
    print("="*70)
    print("TEST 4: Interest Score Computation")
    print("="*70)
    
    class MockResponse:
        def __init__(self, category):
            self.category = category
    
    # Test 1: Balanced interest
    responses = [
        MockResponse('Technology'),
        MockResponse('Technology'),
        MockResponse('Finance'),
        MockResponse('Engineering'),
    ]
    
    result = {}
    for response in responses:
        result[response.category] = result.get(response.category, 0) + 1
    
    total = len(responses)
    scores = {cat: round((count / total) * 100) for cat, count in result.items()}
    
    print(f"Balanced interests (4 responses):")
    for cat, score in scores.items():
        print(f"  {cat}: {score}%")
    
    print()


def test_career_fit_calculation():
    """Test career fit scoring."""
    print("="*70)
    print("TEST 5: Career Fit Calculation")
    print("="*70)
    
    # Test career
    career = {
        'name': 'Software Developer',
        'base_score': 70,
        'aptitude_match_categories': ['Quantitative Ability', 'Logical Reasoning'],
        'suitable_streams': ['PCM', 'Science'],
    }
    
    # Engineering student scores
    interest_scores = {'Technology': 50, 'Engineering': 40}
    aptitude_scores = {
        'Quantitative Ability': 92,
        'Logical Reasoning': 85,
        'Analytical Reasoning': 80,
        'Verbal Ability': 75,
        'Data Interpretation': 82,
    }
    overall_score = 88.0
    academic_eligibility = 95.0
    stream_category = 'PCM'
    
    fit_score = RecommendationService.calculate_career_fit(
        career=career,
        interest_scores=interest_scores,
        aptitude_scores=aptitude_scores,
        overall_score=overall_score,
        academic_eligibility=academic_eligibility,
        stream_category=stream_category,
    )
    
    print(f"Career: {career['name']}")
    print(f"Student Profile:")
    print(f"  Stream: {stream_category}")
    print(f"  Academic Eligibility: {academic_eligibility}")
    print(f"  Overall Aptitude: {overall_score}")
    print(f"  Interests: {interest_scores}")
    print(f"\nCalculated Fit Score: {fit_score}/100")
    print(f"Status: {'✓ STRONG MATCH' if fit_score >= 80 else '✓ GOOD MATCH' if fit_score >= 60 else '✗ WEAK MATCH'}")
    
    print()


def test_explanation_generation():
    """Test explanation generation."""
    print("="*70)
    print("TEST 6: Explanation Generation")
    print("="*70)
    
    career = {
        'name': 'Software Developer',
        'suitable_streams': ['PCM'],
    }
    
    interest_scores = {'Technology': 50}
    aptitude_scores = {'Logical Reasoning': 85}
    
    explanation = RecommendationService.generate_explanation(
        career=career,
        matched_interest_category='Technology',
        matched_aptitude_category='Logical Reasoning',
        interest_scores=interest_scores,
        aptitude_scores=aptitude_scores,
        academic_eligibility=90,
        stream_category='PCM',
    )
    
    print(f"Generated Explanation:")
    print(f"'{explanation}'")
    print()


def run_all_tests():
    """Run all unit tests."""
    print("\n" + "="*70)
    print("PHASE 3 RECOMMENDATION SERVICE - UNIT TESTS")
    print("="*70)
    
    try:
        test_stream_categorization()
        test_academic_eligibility()
        test_college_eligibility()
        test_interest_scoring()
        test_career_fit_calculation()
        test_explanation_generation()
        
        print("="*70)
        print("ALL TESTS COMPLETED SUCCESSFULLY ✓")
        print("="*70 + "\n")
        return True
    except Exception as e:
        print(f"\n✗ Test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == '__main__':
    success = run_all_tests()
    exit(0 if success else 1)
