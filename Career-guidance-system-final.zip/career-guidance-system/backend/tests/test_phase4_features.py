import pytest
from fastapi import status


class TestAuthentication:
    """Test authentication endpoints"""

    def test_register_user(self, client, test_user_data):
        """Test user registration"""
        response = client.post(
            "/api/auth/register",
            json=test_user_data
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["email"] == test_user_data["email"]
        assert "access_token" in data

    def test_register_duplicate_email(self, client, test_user_data):
        """Test duplicate email registration"""
        # Register first user
        client.post("/api/auth/register", json=test_user_data)
        
        # Try to register with same email
        response = client.post("/api/auth/register", json=test_user_data)
        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_login_user(self, client, test_user_data):
        """Test user login"""
        # Register first
        client.post("/api/auth/register", json=test_user_data)
        
        # Login
        response = client.post(
            "/api/auth/login",
            json={
                "email": test_user_data["email"],
                "password": test_user_data["password"]
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "access_token" in data

    def test_login_invalid_credentials(self, client):
        """Test login with invalid credentials"""
        response = client.post(
            "/api/auth/login",
            json={
                "email": "nonexistent@example.com",
                "password": "wrongpassword"
            }
        )
        assert response.status_code == status.HTTP_401_UNAUTHORIZED


class TestStudentProfile:
    """Test student profile endpoints"""

    def test_create_profile(self, client, test_user_data, test_student_profile_data):
        """Test profile creation"""
        # Register
        auth_response = client.post("/api/auth/admin/register", json=test_user_data, headers={"X-Admin-Setup-Key": "test-admin-setup-key"})
        token = auth_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        
        # Create profile
        response = client.post(
            "/api/students/me",
            json=test_student_profile_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["full_name"] == test_student_profile_data["full_name"]
        assert data["contact_number"] == test_student_profile_data["contact_number"]

    def test_get_profile(self, client, test_user_data, test_student_profile_data):
        """Test profile retrieval"""
        # Register and create profile
        auth_response = client.post("/api/auth/admin/register", json=test_user_data, headers={"X-Admin-Setup-Key": "test-admin-setup-key"})
        token = auth_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        
        client.post("/api/students/me", json=test_student_profile_data, headers=headers)
        
        # Get profile
        response = client.get("/api/students/me", headers=headers)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["full_name"] == test_student_profile_data["full_name"]

    def test_update_profile(self, client, test_user_data, test_student_profile_data):
        """Test profile update"""
        # Register and create profile
        auth_response = client.post("/api/auth/register", json=test_user_data)
        token = auth_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        
        client.post("/api/students/me", json=test_student_profile_data, headers=headers)
        
        # Update profile
        update_data = {"full_name": "Jane Doe", "district": "Bangalore"}
        response = client.put(
            "/api/students/me",
            json=update_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["full_name"] == "Jane Doe"
        assert data["district"] == "Bangalore"

    def test_update_profile_partial(self, client, test_user_data, test_student_profile_data):
        """Test partial profile update"""
        # Register and create profile
        auth_response = client.post("/api/auth/register", json=test_user_data)
        token = auth_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        
        client.post("/api/students/me", json=test_student_profile_data, headers=headers)
        
        # Partial update
        response = client.put(
            "/api/students/me",
            json={"full_name": "Updated Name"},
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["full_name"] == "Updated Name"
        # Other fields should remain unchanged
        assert data["contact_number"] == test_student_profile_data["contact_number"]


class TestEducationRecords:
    """Test education record endpoints"""

    def setup_student_with_auth(self, client, test_user_data, test_student_profile_data):
        """Helper to set up a student with authentication"""
        auth_response = client.post("/api/auth/register", json=test_user_data)
        token = auth_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        
        client.post("/api/students/me", json=test_student_profile_data, headers=headers)
        return headers

    def test_add_education_record(self, client, test_user_data, test_student_profile_data, test_education_data):
        """Test adding education record"""
        headers = self.setup_student_with_auth(client, test_user_data, test_student_profile_data)
        
        response = client.post(
            "/api/education/me",
            json=test_education_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["level"] == test_education_data["level"]
        assert data["percentage"] == test_education_data["percentage"]
        assert "id" in data

    def test_get_education_records(self, client, test_user_data, test_student_profile_data, test_education_data):
        """Test retrieving education records"""
        headers = self.setup_student_with_auth(client, test_user_data, test_student_profile_data)
        
        # Add record
        client.post("/api/education/me", json=test_education_data, headers=headers)
        
        # Get records
        response = client.get("/api/education/me", headers=headers)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) > 0
        assert data[0]["level"] == test_education_data["level"]

    def test_get_education_record_by_id(self, client, test_user_data, test_student_profile_data, test_education_data):
        """Test getting specific education record"""
        headers = self.setup_student_with_auth(client, test_user_data, test_student_profile_data)
        
        # Add record
        add_response = client.post("/api/education/me", json=test_education_data, headers=headers)
        record_id = add_response.json()["id"]
        
        # Get specific record
        response = client.get(f"/api/education/{record_id}", headers=headers)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == record_id

    def test_update_education_record(self, client, test_user_data, test_student_profile_data, test_education_data):
        """Test updating education record"""
        headers = self.setup_student_with_auth(client, test_user_data, test_student_profile_data)
        
        # Add record
        add_response = client.post("/api/education/me", json=test_education_data, headers=headers)
        record_id = add_response.json()["id"]
        
        # Update record
        update_data = {"percentage": 95.0, "stream": "PCB"}
        response = client.put(
            f"/api/education/{record_id}",
            json=update_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["percentage"] == 95.0
        assert data["stream"] == "PCB"

    def test_delete_education_record(self, client, test_user_data, test_student_profile_data, test_education_data):
        """Test deleting education record"""
        headers = self.setup_student_with_auth(client, test_user_data, test_student_profile_data)
        
        # Add record
        add_response = client.post("/api/education/me", json=test_education_data, headers=headers)
        record_id = add_response.json()["id"]
        
        # Delete record
        response = client.delete(f"/api/education/{record_id}", headers=headers)
        assert response.status_code == status.HTTP_204_NO_CONTENT
        
        # Verify it's deleted
        get_response = client.get(f"/api/education/{record_id}", headers=headers)
        assert get_response.status_code == status.HTTP_404_NOT_FOUND

    def test_education_validation_invalid_percentage(self, client, test_user_data, test_student_profile_data):
        """Test education record validation - invalid percentage"""
        headers = self.setup_student_with_auth(client, test_user_data, test_student_profile_data)
        
        invalid_data = {
            "level": "12th",
            "board": "CBSE",
            "year": 2023,
            "total_marks": 500,
            "marks_obtained": 600,  # More than total
            "percentage": 150.0,  # Invalid percentage
            "stream": "PCM"
        }
        
        response = client.post("/api/education/me", json=invalid_data, headers=headers)
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestCareerDatabase:
    """Test career database endpoints"""

    def setup_admin_user(self, client, test_user_data):
        """Helper to set up admin user"""
        auth_response = client.post("/api/auth/admin/register", json=test_user_data, headers={"X-Admin-Setup-Key": "test-admin-setup-key"})
        token = auth_response.json()["access_token"]
        return {"Authorization": f"Bearer {token}"}

    def test_list_careers(self, client):
        """Test listing careers"""
        response = client.get("/api/careers")
        # Initially empty, but endpoint should work
        assert response.status_code == status.HTTP_200_OK
        assert isinstance(response.json(), list)

    def test_create_career(self, client, test_user_data, test_career_data):
        """Test creating a career"""
        headers = self.setup_admin_user(client, test_user_data)
        
        response = client.post(
            "/api/careers",
            json=test_career_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["name"] == test_career_data["name"]
        assert data["category"] == test_career_data["category"]

    def test_get_career(self, client, test_user_data, test_career_data):
        """Test getting specific career"""
        headers = self.setup_admin_user(client, test_user_data)
        
        # Create career
        create_response = client.post(
            "/api/careers",
            json=test_career_data,
            headers=headers
        )
        career_id = create_response.json()["id"]
        
        # Get career
        response = client.get(f"/api/careers/{career_id}")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == career_id
        assert data["name"] == test_career_data["name"]

    def test_update_career(self, client, test_user_data, test_career_data):
        """Test updating a career"""
        headers = self.setup_admin_user(client, test_user_data)
        
        # Create career
        create_response = client.post(
            "/api/careers",
            json=test_career_data,
            headers=headers
        )
        career_id = create_response.json()["id"]
        
        # Update career
        update_data = {"base_score": 80.0, "category": "IT"}
        response = client.put(
            f"/api/careers/{career_id}",
            json=update_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["base_score"] == 80.0
        assert data["category"] == "IT"

    def test_delete_career(self, client, test_user_data, test_career_data):
        """Test deleting a career"""
        headers = self.setup_admin_user(client, test_user_data)
        
        # Create career
        create_response = client.post(
            "/api/careers",
            json=test_career_data,
            headers=headers
        )
        career_id = create_response.json()["id"]
        
        # Delete career
        response = client.delete(f"/api/careers/{career_id}", headers=headers)
        assert response.status_code == status.HTTP_204_NO_CONTENT


class TestCollegeDatabase:
    """Test college database endpoints"""

    def setup_admin_user(self, client, test_user_data):
        """Helper to set up admin user"""
        auth_response = client.post("/api/auth/admin/register", json=test_user_data, headers={"X-Admin-Setup-Key": "test-admin-setup-key"})
        token = auth_response.json()["access_token"]
        return {"Authorization": f"Bearer {token}"}

    def test_list_colleges(self, client):
        """Test listing colleges"""
        response = client.get("/api/colleges")
        assert response.status_code == status.HTTP_200_OK
        assert isinstance(response.json(), list)

    def test_create_college(self, client, test_user_data, test_college_data):
        """Test creating a college"""
        headers = self.setup_admin_user(client, test_user_data)
        
        response = client.post(
            "/api/colleges",
            json=test_college_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["name"] == test_college_data["name"]
        assert data["city"] == test_college_data["city"]

    def test_get_college(self, client, test_user_data, test_college_data):
        """Test getting specific college"""
        headers = self.setup_admin_user(client, test_user_data)
        
        # Create college
        create_response = client.post(
            "/api/colleges",
            json=test_college_data,
            headers=headers
        )
        college_id = create_response.json()["id"]
        
        # Get college
        response = client.get(f"/api/colleges/{college_id}")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == college_id
        assert data["name"] == test_college_data["name"]

    def test_update_college(self, client, test_user_data, test_college_data):
        """Test updating a college"""
        headers = self.setup_admin_user(client, test_user_data)
        
        # Create college
        create_response = client.post(
            "/api/colleges",
            json=test_college_data,
            headers=headers
        )
        college_id = create_response.json()["id"]
        
        # Update college
        update_data = {"cutoff": 95.0, "city": "Bangalore"}
        response = client.put(
            f"/api/colleges/{college_id}",
            json=update_data,
            headers=headers
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["cutoff"] == 95.0
        assert data["city"] == "Bangalore"

    def test_delete_college(self, client, test_user_data, test_college_data):
        """Test deleting a college"""
        headers = self.setup_admin_user(client, test_user_data)
        
        # Create college
        create_response = client.post(
            "/api/colleges",
            json=test_college_data,
            headers=headers
        )
        college_id = create_response.json()["id"]
        
        # Delete college
        response = client.delete(f"/api/colleges/{college_id}", headers=headers)
        assert response.status_code == status.HTTP_204_NO_CONTENT


class TestDashboardAndRecommendations:
    """Test that dashboard and recommendations still work"""

    def test_dashboard_after_profile_and_education(self, client, test_user_data, test_student_profile_data, test_education_data):
        """Test dashboard still works with new fields"""
        # Register
        auth_response = client.post("/api/auth/register", json=test_user_data)
        token = auth_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        
        # Create profile
        client.post("/api/students/me", json=test_student_profile_data, headers=headers)
        
        # Add education
        client.post("/api/education/me", json=test_education_data, headers=headers)
        
        # Dashboard should still be accessible
        response = client.get("/api/students/me", headers=headers)
        assert response.status_code == status.HTTP_200_OK
