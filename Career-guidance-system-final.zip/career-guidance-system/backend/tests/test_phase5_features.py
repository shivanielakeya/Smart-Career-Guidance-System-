from fastapi import status

from conftest import TestingSessionLocal
from app.db.models.aptitude_result import AptitudeResult
from app.db.models.interest_response import InterestResponse
from app.db.models.student_profile import StudentProfile


class TestPhase5AdminFeatures:
    def test_admin_registration_requires_setup_key_and_student_is_denied(self, client):
        rejected = client.post(
            "/api/auth/register",
            json={"email": "forbidden-admin@example.com", "password": "AdminPass123", "role": "admin"},
        )
        assert rejected.status_code == status.HTTP_403_FORBIDDEN

        student = client.post(
            "/api/auth/register",
            json={"email": "regular-student@example.com", "password": "StudentPass123"},
        )
        student_token = student.json()["access_token"]
        denied = client.get(
            "/api/admin/dashboard",
            headers={"Authorization": f"Bearer {student_token}"},
        )
        assert denied.status_code == status.HTTP_403_FORBIDDEN

    def test_admin_registration_and_dashboard(self, client):
        admin_payload = {
            "email": "admin@example.com",
            "password": "AdminPass123",
            "role": "admin",
        }
        register_response = client.post("/api/auth/admin/register", json=admin_payload, headers={"X-Admin-Setup-Key": "test-admin-setup-key"})
        assert register_response.status_code == status.HTTP_200_OK
        token = register_response.json()["access_token"]

        response = client.get(
            "/api/admin/dashboard",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == status.HTTP_200_OK
        payload = response.json()
        assert payload["stats"]["careers"] >= 0
        assert "recent_activity" in payload

    def test_student_management_and_notifications_endpoints(self, client):
        admin_response = client.post(
            "/api/auth/admin/register",
            json={"email": "manager@example.com", "password": "AdminPass123", "role": "admin"},
            headers={"X-Admin-Setup-Key": "test-admin-setup-key"},
        )
        admin_token = admin_response.json()["access_token"]

        student_response = client.post(
            "/api/auth/register",
            json={"email": "student@example.com", "password": "StudentPass123"},
        )
        assert student_response.status_code == status.HTTP_200_OK

        students_response = client.get(
            "/api/admin/students",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert students_response.status_code == status.HTTP_200_OK
        assert isinstance(students_response.json(), list)

        email_response = client.post(
            "/api/admin/notifications/email",
            json={"recipient_email": "student@example.com", "subject": "Test email", "message": "Hello"},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert email_response.status_code == status.HTTP_200_OK
        assert email_response.json()["status"] in {"queued", "sent", "simulated"}

    def test_career_and_college_search_filters(self, client):
        payload = {
            "name": "AI Engineer",
            "category": "Technology",
            "description": "Build intelligent systems and automation workflows.",
            "course": "B.Tech AI & Data Science",
            "college": "VIT Vellore",
            "aptitude_match_categories": ["Quantitative Ability", "Logical Reasoning"],
            "base_score": 80.0,
            "suitable_streams": ["PCM", "Science"],
            "min_percentage": 80.0,
        }
        admin_response = client.post(
            "/api/auth/admin/register",
            json={"email": "search-admin@example.com", "password": "AdminPass123", "role": "admin"},
            headers={"X-Admin-Setup-Key": "test-admin-setup-key"},
        )
        token = admin_response.json()["access_token"]
        create_response = client.post(
            "/api/careers",
            json=payload,
            headers={"Authorization": f"Bearer {token}"},
        )
        assert create_response.status_code == status.HTTP_200_OK

        search_response = client.get(
            "/api/careers",
            params={"search": "engineer", "category": "Technology", "min_percentage": 70},
        )
        assert search_response.status_code == status.HTTP_200_OK
        assert len(search_response.json()) >= 1

        college_response = client.post(
            "/api/colleges",
            json={
                "name": "VIT Vellore",
                "category": "Technology",
                "city": "Vellore",
                "district": "Vellore",
                "state": "Tamil Nadu",
                "cutoff": 88.0,
                "courses": ["B.Tech AI & Data Science"],
                "career_opportunities": ["AI Engineer"],
            },
            headers={"Authorization": f"Bearer {token}"},
        )
        assert college_response.status_code == status.HTTP_200_OK

        filtered_college_response = client.get(
            "/api/colleges",
            params={"search": "VIT", "state": "Tamil Nadu", "min_cutoff": 80},
        )
        assert filtered_college_response.status_code == status.HTTP_200_OK
        assert len(filtered_college_response.json()) >= 1

    def test_pdf_export_for_recommendations(self, client):
        user_response = client.post(
            "/api/auth/register",
            json={"email": "pdf-user@example.com", "password": "StudentPass123"},
        )
        token = user_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}

        client.post(
            "/api/students/me",
            json={
                "full_name": "PDF User",
                "date_of_birth": "2005-02-01",
                "gender": "Female",
                "contact_number": "9876543212",
                "district": "Coimbatore",
                "state": "Tamil Nadu",
                "school": "Model School",
                "school_type": "Private",
                "parent_name": "Parent",
                "parent_contact": "9876543212",
            },
            headers=headers,
        )
        client.post(
            "/api/education/me",
            json={
                "level": "12th",
                "board": "CBSE",
                "year": 2024,
                "total_marks": 500,
                "marks_obtained": 450,
                "percentage": 90.0,
                "stream": "PCM",
            },
            headers=headers,
        )
        client.post(
            "/api/aptitude/submit",
            json={
                "answers": [
                    {"question_id": 1, "answer": "option_c"},
                    {"question_id": 2, "answer": "option_b"},
                    {"question_id": 3, "answer": "option_a"},
                    {"question_id": 4, "answer": "option_b"},
                    {"question_id": 5, "answer": "option_c"},
                    {"question_id": 6, "answer": "option_c"},
                    {"question_id": 7, "answer": "option_c"},
                    {"question_id": 8, "answer": "option_c"},
                    {"question_id": 9, "answer": "option_d"},
                    {"question_id": 10, "answer": "option_c"},
                    {"question_id": 11, "answer": "option_c"},
                    {"question_id": 12, "answer": "option_d"},
                    {"question_id": 13, "answer": "option_d"},
                    {"question_id": 14, "answer": "option_a"},
                    {"question_id": 15, "answer": "option_a"},
                    {"question_id": 16, "answer": "option_b"},
                    {"question_id": 17, "answer": "option_c"},
                    {"question_id": 18, "answer": "option_c"},
                    {"question_id": 19, "answer": "option_b"},
                    {"question_id": 20, "answer": "option_b"},
                ]
            },
            headers=headers,
        )
        client.post(
            "/api/interest/submit",
            json={
                "answers": [
                    {"question_id": 1, "option_id": 1},
                    {"question_id": 2, "option_id": 1},
                    {"question_id": 3, "option_id": 1},
                    {"question_id": 4, "option_id": 1},
                    {"question_id": 5, "option_id": 1},
                    {"question_id": 6, "option_id": 1},
                    {"question_id": 7, "option_id": 1},
                    {"question_id": 8, "option_id": 1},
                    {"question_id": 9, "option_id": 1},
                    {"question_id": 10, "option_id": 1},
                ]
            },
            headers=headers,
        )

        response = client.get(
            "/api/recommendations/export-pdf",
            headers=headers,
        )
        assert response.status_code == status.HTTP_200_OK
        assert response.headers["content-type"].startswith("application/pdf")
        assert b"PDF User" in response.content
        assert b"Top Careers:" in response.content
        assert b"Recommended Colleges:" in response.content

    def test_recommendations_reflect_database_updates(self, client):
        admin = client.post(
            "/api/auth/admin/register",
            json={"email": "catalog-admin@example.com", "password": "AdminPass123"},
            headers={"X-Admin-Setup-Key": "test-admin-setup-key"},
        )
        admin_headers = {"Authorization": f"Bearer {admin.json()['access_token']}"}
        career = client.post(
            "/api/careers",
            json={
                "name": "Database Career",
                "category": "Technology",
                "description": "A database-managed career used for integration testing.",
                "course": "Database Course",
                "college": "Database College",
                "aptitude_match_categories": ["Logical Reasoning"],
                "base_score": 80,
                "suitable_streams": ["PCM"],
                "min_percentage": 50,
            },
            headers=admin_headers,
        )
        college = client.post(
            "/api/colleges",
            json={
                "name": "Database College",
                "category": "Technology",
                "city": "Chennai",
                "district": "Chennai",
                "state": "Tamil Nadu",
                "cutoff": 70,
                "courses": ["Database Course"],
                "career_opportunities": ["Database Career"],
            },
            headers=admin_headers,
        )
        student = client.post(
            "/api/auth/register",
            json={"email": "catalog-student@example.com", "password": "StudentPass123"},
        )
        student_headers = {"Authorization": f"Bearer {student.json()['access_token']}"}
        client.post(
            "/api/students/me",
            json={"full_name": "Catalog Student", "date_of_birth": "2005-01-01", "gender": "Other", "contact_number": "9876543212", "district": "Chennai", "state": "Tamil Nadu", "school": "School", "school_type": "Private", "parent_name": "Parent", "parent_contact": "9876543212"},
            headers=student_headers,
        )
        client.post(
            "/api/education/me",
            json={"level": "12th", "board": "CBSE", "year": 2024, "total_marks": 500, "marks_obtained": 450, "percentage": 90, "stream": "PCM"},
            headers=student_headers,
        )
        db = TestingSessionLocal()
        profile = db.query(StudentProfile).filter(StudentProfile.user_id == 2).first()
        db.add(AptitudeResult(student_profile_id=profile.id, overall_score=90, quantitative_score=90, logical_score=90, analytical_score=80, verbal_score=70, data_interpretation_score=80))
        db.add(InterestResponse(student_profile_id=profile.id, question_id=1, option_key="A", category="Technology"))
        db.commit()
        db.close()

        before = client.get("/api/recommendations", headers=student_headers).json()
        assert any(item["name"] == "Database Career" for item in before["careers"])
        updated_career = client.put(f"/api/careers/{career.json()['id']}", json={"name": "Updated Database Career"}, headers=admin_headers)
        updated_college = client.put(f"/api/colleges/{college.json()['id']}", json={"name": "Updated Database College"}, headers=admin_headers)
        assert updated_career.status_code == status.HTTP_200_OK
        assert updated_college.status_code == status.HTTP_200_OK
        after = client.get("/api/recommendations", headers=student_headers).json()
        assert any(item["name"] == "Updated Database Career" for item in after["careers"])
        assert any(item["name"] == "Updated Database College" for item in after["colleges"])
