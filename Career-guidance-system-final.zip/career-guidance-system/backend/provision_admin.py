"""Promote an existing user to admin without creating another account."""

import argparse
import getpass
import secrets

from app.core.config import get_settings
from app.db.models.user import User
from app.db.session import SessionLocal


def main() -> None:
    parser = argparse.ArgumentParser(description='Promote an existing Career Guidance user to admin.')
    parser.add_argument('--email', required=True, help='Email address of the existing user')
    args = parser.parse_args()

    settings = get_settings()
    if not settings.admin_setup_key:
        raise SystemExit('ADMIN_SETUP_KEY is not configured in the backend environment.')

    setup_key = getpass.getpass('Admin provisioning key: ')
    if not secrets.compare_digest(setup_key, settings.admin_setup_key):
        raise SystemExit('Invalid admin provisioning key.')

    db = SessionLocal()
    try:
        email = args.email.strip().lower()
        user = db.query(User).filter(User.email == email).first()
        if not user:
            raise SystemExit(f'No existing account found for {email}. No account was created.')
        if user.role == 'admin':
            print(f'{email} is already an admin.')
            return

        user.role = 'admin'
        db.commit()
        print(f'Updated existing account {email} (id={user.id}) to admin.')
    finally:
        db.close()


if __name__ == '__main__':
    main()
