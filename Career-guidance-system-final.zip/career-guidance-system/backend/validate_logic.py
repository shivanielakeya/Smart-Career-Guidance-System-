"""
Standalone validation of Phase 3 Recommendation Logic.

This script validates the recommendation logic without requiring
database connections or external dependencies.
"""


def stream_to_category(stream: str | None) -> str | None:
    """Convert stream to category for career matching."""
    if not stream:
        return None

    stream_upper = stream.upper().replace(' ', '')

    # Check for specific streams first
    if 'PCM' in stream_upper or ('MATHEMATICS' in stream_upper and 'PHYSICS' in stream_upper):
        return 'PCM'
    elif 'PCB' in stream_upper or ('BIOLOGY' in stream_upper and 'PHYSICS' in stream_upper):
        return 'PCB'
    elif 'COMMERCE' in stream_upper:
        return 'Commerce'
    elif 'ARTS' in stream_upper:
        return 'Arts'
    elif 'SCIENCE' in stream_upper:
        # Generic science if neither PCM nor PCB specified
        return 'Science'
    else:
        return None


def calculate_academic_eligibility(percentage: float | None) -> tuple:
    """Calculate academic eligibility and get suitable career categories."""
    if not percentage:
        return 0.0, []

    if percentage >= 90:
        return 95.0, ['PCM', 'PCB', 'Commerce', 'Arts']
    elif percentage >= 80:
        return 85.0, ['PCM', 'PCB', 'Commerce', 'Arts']
    elif percentage >= 70:
        return 75.0, ['PCM', 'Commerce', 'Arts']
    elif percentage >= 60:
        return 65.0, ['Commerce', 'Arts']
    else:
        return 50.0, ['Arts']


def get_college_eligibility(student_marks: float, cutoff: float) -> tuple:
    """Check college eligibility based on marks."""
    if student_marks >= cutoff:
        match_percentage = min(100.0, (student_marks / cutoff) * 100)
        return True, match_percentage
    else:
        match_percentage = (student_marks / cutoff) * 100 if cutoff > 0 else 0
        return False, match_percentage


def validate_stream_categorization():
    """Validate stream categorization logic."""
    print("\n" + "="*70)
    print("VALIDATION 1: Stream Categorization")
    print("="*70)
    
    test_cases = [
        ('PCM', 'PCM'),
        ('Physics Chemistry Mathematics', 'PCM'),
        ('PCB', 'PCB'),
        ('Physics Chemistry Biology', 'PCB'),
        ('COMMERCE', 'Commerce'),
        ('ARTS', 'Arts'),
        ('Science', 'Science'),
        ('', None),
        (None, None),
    ]
    
    all_pass = True
    for stream_input, expected in test_cases:
        result = stream_to_category(stream_input)
        passed = result == expected
        status = "✓" if passed else "✗"
        all_pass = all_pass and passed
        
        input_display = f"'{stream_input}'" if stream_input else "None"
        print(f"{status} {input_display:35} -> {str(result):15} (expected: {expected})")
    
    return all_pass


def validate_academic_eligibility():
    """Validate academic eligibility calculation."""
    print("\n" + "="*70)
    print("VALIDATION 2: Academic Eligibility Calculation")
    print("="*70)
    
    test_cases = [
        (92.0, 95.0, 4),    # 92% -> 95 score, all streams eligible
        (85.0, 85.0, 4),    # 85% -> 85 score, all streams eligible
        (75.0, 75.0, 3),    # 75% -> 75 score, 3 streams eligible
        (65.0, 65.0, 2),    # 65% -> 65 score, 2 streams eligible
        (55.0, 50.0, 1),    # 55% -> 50 score, only Arts eligible
    ]
    
    all_pass = True
    for percentage, expected_score, expected_stream_count in test_cases:
        score, streams = calculate_academic_eligibility(percentage)
        
        score_match = score == expected_score
        streams_match = len(streams) == expected_stream_count
        passed = score_match and streams_match
        status = "✓" if passed else "✗"
        all_pass = all_pass and passed
        
        print(f"{status} {percentage}%: Score={score} (exp:{expected_score}), Streams={len(streams)} (exp:{expected_stream_count})")
    
    return all_pass


def validate_college_eligibility():
    """Validate college eligibility filtering."""
    print("\n" + "="*70)
    print("VALIDATION 3: College Eligibility Filtering")
    print("="*70)
    
    test_cases = [
        (190, 180, True, 100.0, 105.6),   # Above cutoff
        (180, 180, True, 100.0, 100.0),   # Exactly at cutoff
        (170, 180, False, 94.4, 94.4),    # Below cutoff but close
        (150, 180, False, 83.3, 83.3),    # Well below cutoff
        (200, 200, True, 100.0, 100.0),   # High achiever
    ]
    
    all_pass = True
    for marks, cutoff, exp_eligible, exp_pct_approx, _ in test_cases:
        is_eligible, match_pct = get_college_eligibility(marks, cutoff)
        
        # Check eligibility and match percentage (within 0.1% tolerance)
        eligible_match = is_eligible == exp_eligible
        pct_match = abs(match_pct - exp_pct_approx) < 0.2
        passed = eligible_match and pct_match
        status = "✓" if passed else "✗"
        all_pass = all_pass and passed
        
        eligible_str = "ELIGIBLE ✓" if is_eligible else "POTENTIAL"
        print(f"{status} {marks:3d} marks vs {cutoff} cutoff: {eligible_str:13} ({match_pct:.1f}%)")
    
    return all_pass


def validate_career_matching_logic():
    """Validate career matching logic."""
    print("\n" + "="*70)
    print("VALIDATION 4: Career Matching Logic")
    print("="*70)
    
    # Test 1: Engineering student should match Software Developer
    print("\nScenario 1: Engineering Student (PCM, 86%, High Quant Aptitude)")
    stream = 'PCM'
    percentage = 86.0
    aptitude_quant = 92.0
    aptitude_logical = 85.0
    
    stream_cat = stream_to_category(stream)
    acad_score, _ = calculate_academic_eligibility(percentage)
    
    print(f"  Stream: {stream} -> {stream_cat}")
    print(f"  Academic Eligibility: {acad_score}/100")
    print(f"  Aptitude (Quant): {aptitude_quant}%")
    print(f"  Aptitude (Logical): {aptitude_logical}%")
    print(f"  Expected Match: Software Developer ✓")
    
    # Test 2: Medical student should match Doctor
    print("\nScenario 2: Medical Student (PCB, 87.5%, High Data Interp Aptitude)")
    stream = 'PCB'
    percentage = 87.5
    aptitude_data = 90.0
    aptitude_logical = 88.0
    
    stream_cat = stream_to_category(stream)
    acad_score, _ = calculate_academic_eligibility(percentage)
    
    print(f"  Stream: {stream} -> {stream_cat}")
    print(f"  Academic Eligibility: {acad_score}/100")
    print(f"  Aptitude (Data Interp): {aptitude_data}%")
    print(f"  Aptitude (Logical): {aptitude_logical}%")
    print(f"  Expected Match: Doctor (MBBS) ✓")
    
    # Test 3: Commerce student should match CA/Business
    print("\nScenario 3: Commerce Student (80%, High Analytical Aptitude)")
    stream = 'Commerce'
    percentage = 80.0
    aptitude_analytical = 88.0
    aptitude_quant = 85.0
    
    stream_cat = stream_to_category(stream)
    acad_score, _ = calculate_academic_eligibility(percentage)
    
    print(f"  Stream: {stream} -> {stream_cat}")
    print(f"  Academic Eligibility: {acad_score}/100")
    print(f"  Aptitude (Analytical): {aptitude_analytical}%")
    print(f"  Aptitude (Quant): {aptitude_quant}%")
    print(f"  Expected Match: Chartered Accountant ✓")
    
    # Test 4: Arts student should match Designer/Communications
    print("\nScenario 4: Arts Student (70%, High Verbal Aptitude)")
    stream = 'Arts'
    percentage = 70.0
    aptitude_verbal = 88.0
    aptitude_analytical = 70.0
    
    stream_cat = stream_to_category(stream)
    acad_score, _ = calculate_academic_eligibility(percentage)
    
    print(f"  Stream: {stream} -> {stream_cat}")
    print(f"  Academic Eligibility: {acad_score}/100")
    print(f"  Aptitude (Verbal): {aptitude_verbal}%")
    print(f"  Aptitude (Analytical): {aptitude_analytical}%")
    print(f"  Expected Match: Graphic Designer ✓")
    
    return True


def validate_college_recommendation_logic():
    """Validate college recommendation logic."""
    print("\n" + "="*70)
    print("VALIDATION 5: College Recommendation Logic")
    print("="*70)
    
    # Test filtering colleges for engineering student with 86% marks
    student_marks = 86.0
    student_location = 'Chennai'
    
    colleges = [
        {'name': 'Anna University', 'city': 'Chennai', 'cutoff': 180},
        {'name': 'IIT Madras', 'city': 'Chennai', 'cutoff': 200},
        {'name': 'VIT', 'city': 'Vellore', 'cutoff': 160},
        {'name': 'PSG', 'city': 'Coimbatore', 'cutoff': 185},
    ]
    
    print(f"\nStudent Profile: {student_marks}% marks, {student_location} location\n")
    print("College Analysis:")
    print("-" * 70)
    
    for college in colleges:
        is_eligible, match_pct = get_college_eligibility(student_marks, college['cutoff'])
        location_match = college['city'] == student_location
        location_str = "📍 Local" if location_match else "   Away"
        eligible_str = "ELIGIBLE ✓" if is_eligible else "POTENTIAL"
        
        print(f"{location_str} | {college['name']:20} | Cutoff: {college['cutoff']} | {eligible_str:12} ({match_pct:.1f}%)")
    
    return True


def run_all_validations():
    """Run all validation tests."""
    print("\n" + "="*70)
    print("PHASE 3 RECOMMENDATION ENGINE - LOGIC VALIDATION")
    print("="*70)
    
    results = {
        'Stream Categorization': validate_stream_categorization(),
        'Academic Eligibility': validate_academic_eligibility(),
        'College Eligibility': validate_college_eligibility(),
        'Career Matching': validate_career_matching_logic(),
        'College Recommendation': validate_college_recommendation_logic(),
    }
    
    print("\n" + "="*70)
    print("VALIDATION SUMMARY")
    print("="*70)
    
    for test_name, passed in results.items():
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{status} | {test_name}")
    
    all_passed = all(results.values())
    
    print("="*70)
    if all_passed:
        print("ALL VALIDATIONS PASSED ✓")
    else:
        print("SOME VALIDATIONS FAILED ✗")
    print("="*70 + "\n")
    
    return all_passed


if __name__ == '__main__':
    success = run_all_validations()
    exit(0 if success else 1)
