from typing import Literal

from pydantic import BaseModel, Field


class AnalyticsEventCreate(BaseModel):
    event_type: Literal['college_view', 'college_selection']
    entity_id: int | None = None
    entity_name: str | None = Field(default=None, max_length=255)