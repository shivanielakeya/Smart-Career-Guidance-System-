from pydantic import BaseModel, Field, field_validator
from datetime import datetime


class EducationRecordBase(BaseModel):
    level: str = Field(..., min_length=2)
    board: str | None = Field(None, min_length=2)
    year: int | None = Field(None, ge=1990, le=2030)
    total_marks: int | None = Field(None, ge=0)
    marks_obtained: int | None = Field(None, ge=0)
    percentage: float | None = Field(None, ge=0, le=100)
    stream: str | None = Field(None, min_length=2)

    @field_validator('marks_obtained', 'total_marks')
    @classmethod
    def validate_marks(cls, v):
        if v is not None and v < 0:
            raise ValueError('Marks cannot be negative')
        return v

    @field_validator('percentage')
    @classmethod
    def validate_percentage(cls, v):
        if v is not None and (v < 0 or v > 100):
            raise ValueError('Percentage must be between 0 and 100')
        return v


class EducationRecordCreate(EducationRecordBase):
    pass


class EducationRecordUpdate(BaseModel):
    level: str | None = Field(None, min_length=2)
    board: str | None = Field(None, min_length=2)
    year: int | None = Field(None, ge=1990, le=2030)
    total_marks: int | None = Field(None, ge=0)
    marks_obtained: int | None = Field(None, ge=0)
    percentage: float | None = Field(None, ge=0, le=100)
    stream: str | None = Field(None, min_length=2)


class EducationRecordResponse(EducationRecordBase):
    id: int
    student_profile_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
