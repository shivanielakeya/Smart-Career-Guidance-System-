from datetime import date, datetime
from pydantic import BaseModel, Field, field_validator


class StudentProfileBase(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=255)
    date_of_birth: date
    gender: str | None = Field(None, min_length=2)
    contact_number: str | None = Field(None, min_length=10, max_length=20)
    district: str | None = Field(None, min_length=2)
    state: str | None = Field(default='Tamil Nadu', min_length=2)
    school: str | None = Field(None, min_length=2)
    school_type: str | None = Field(None, min_length=2)
    parent_name: str | None = Field(None, min_length=2)
    parent_contact: str | None = Field(None, min_length=10, max_length=20)

    @field_validator('contact_number', 'parent_contact', mode='before')
    @classmethod
    def validate_phone(cls, v):
        if v is not None and not v.replace('-', '').replace(' ', '').isdigit():
            raise ValueError('Phone number must contain only digits')
        return v


class StudentProfileCreate(StudentProfileBase):
    pass


class StudentProfileUpdate(BaseModel):
    full_name: str | None = Field(None, min_length=2, max_length=255)
    date_of_birth: date | None = None
    gender: str | None = Field(None, min_length=2)
    contact_number: str | None = Field(None, min_length=10, max_length=20)
    district: str | None = Field(None, min_length=2)
    state: str | None = Field(None, min_length=2)
    school: str | None = Field(None, min_length=2)
    school_type: str | None = Field(None, min_length=2)
    parent_name: str | None = Field(None, min_length=2)
    parent_contact: str | None = Field(None, min_length=10, max_length=20)

    @field_validator('contact_number', 'parent_contact', mode='before')
    @classmethod
    def validate_phone(cls, v):
        if v is not None and not v.replace('-', '').replace(' ', '').isdigit():
            raise ValueError('Phone number must contain only digits')
        return v


class StudentProfileResponse(StudentProfileBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
