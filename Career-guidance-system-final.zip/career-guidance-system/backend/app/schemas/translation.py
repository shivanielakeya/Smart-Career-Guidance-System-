from typing import Literal

from pydantic import BaseModel, Field


class TranslationRequest(BaseModel):
    texts: list[str] = Field(min_length=1, max_length=50)
    language: Literal['en', 'ta']


class TranslationResponse(BaseModel):
    translations: list[str]
    provider: str
    model: str