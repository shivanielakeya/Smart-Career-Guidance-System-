from pydantic import BaseModel
from typing import List


class AptitudeQuestionPayload(BaseModel):
    id: int
    question: str
    category: str
    difficulty: str
    option_a: str
    option_b: str
    option_c: str
    option_d: str


class AptitudeQuestionResponse(BaseModel):
    id: int
    question: str
    category: str
    difficulty: str
    option_a: str
    option_b: str
    option_c: str
    option_d: str

    class Config:
        orm_mode = True


class AptitudeAnswer(BaseModel):
    question_id: int
    answer: str


class AptitudeSubmission(BaseModel):
    answers: List[AptitudeAnswer]


class CategoryScore(BaseModel):
    category: str
    score: float


class AptitudeResultResponse(BaseModel):
    overall_score: float
    category_scores: List[CategoryScore]

    class Config:
        orm_mode = True
