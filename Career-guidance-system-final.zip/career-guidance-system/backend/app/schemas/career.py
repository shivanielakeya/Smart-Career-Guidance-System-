from pydantic import BaseModel, Field
from typing import List
from datetime import datetime


class CareerBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    category: str = Field(..., min_length=1, max_length=100)
    description: str = Field(..., min_length=10)
    course: str = Field(..., min_length=1, max_length=255)
    college: str = Field(..., min_length=1, max_length=255)
    aptitude_match_categories: List[str]
    base_score: float = Field(default=60, ge=0, le=100)
    suitable_streams: List[str]
    min_percentage: float = Field(default=50, ge=0, le=100)


class CareerCreate(CareerBase):
    pass


class CareerUpdate(BaseModel):
    name: str = Field(None, min_length=1, max_length=255)
    category: str = Field(None, min_length=1, max_length=100)
    description: str = Field(None, min_length=10)
    course: str = Field(None, min_length=1, max_length=255)
    college: str = Field(None, min_length=1, max_length=255)
    aptitude_match_categories: List[str] = None
    base_score: float = Field(None, ge=0, le=100)
    suitable_streams: List[str] = None
    min_percentage: float = Field(None, ge=0, le=100)


class CareerResponse(CareerBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class CollegeBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    category: str = Field(..., min_length=1, max_length=100)
    city: str = Field(..., min_length=1, max_length=150)
    district: str = Field(..., min_length=1, max_length=150)
    state: str = Field(..., min_length=1, max_length=150)
    cutoff: float = Field(..., ge=0, le=100)
    courses: List[str]
    career_opportunities: List[str]


class CollegeCreate(CollegeBase):
    pass


class CollegeUpdate(BaseModel):
    name: str = Field(None, min_length=1, max_length=255)
    category: str = Field(None, min_length=1, max_length=100)
    city: str = Field(None, min_length=1, max_length=150)
    district: str = Field(None, min_length=1, max_length=150)
    state: str = Field(None, min_length=1, max_length=150)
    cutoff: float = Field(None, ge=0, le=100)
    courses: List[str] = None
    career_opportunities: List[str] = None


class CollegeResponse(CollegeBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
