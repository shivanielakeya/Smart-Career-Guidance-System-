from pydantic import BaseModel
from typing import List, Optional


class CareerRecommendation(BaseModel):
    id: int
    name: str
    category: str
    description: str
    overall_score: float
    course: str
    college: str
    matched_interest_category: Optional[str] = None
    matched_aptitude_category: Optional[str] = None
    explanation: str
    academic_suitability: Optional[float] = None
    required_stream: Optional[str] = None


class CourseRecommendation(BaseModel):
    id: int
    name: str
    category: str
    college: str
    college_id: Optional[int] = None
    duration: str
    eligibility_required: Optional[str] = None
    career_opportunities: Optional[List[str]] = None


class CollegeRecommendation(BaseModel):
    id: int
    name: str
    city: str
    cutoff: int
    category: str
    eligibility: Optional[bool] = None
    match_percentage: Optional[float] = None
    location_match: Optional[bool] = None
    courses: Optional[List[str]] = None


class RecommendationResponse(BaseModel):
    careers: List[CareerRecommendation]
    courses: List[CourseRecommendation]
    colleges: List[CollegeRecommendation]
    student_data: Optional[dict] = None  # For debugging: shows what data was used
