from pydantic import BaseModel
from typing import List


class InterestOptionPayload(BaseModel):
    key: str
    label: str
    text: str
    category: str


class InterestQuestionPayload(BaseModel):
    id: int
    question: str
    options: List[InterestOptionPayload]


class InterestQuestionResponse(BaseModel):
    id: int
    question: str
    options: List[InterestOptionPayload]

    class Config:
        orm_mode = True


class InterestAnswer(BaseModel):
    question_id: int
    answer: str | None = None
    option_id: int | None = None


class InterestSubmission(BaseModel):
    answers: List[InterestAnswer]


class InterestScore(BaseModel):
    category: str
    score: float


class InterestResultResponse(BaseModel):
    scores: List[InterestScore]

    class Config:
        orm_mode = True
