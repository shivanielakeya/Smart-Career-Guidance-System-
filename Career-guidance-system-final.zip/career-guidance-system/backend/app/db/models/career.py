from sqlalchemy import Column, Integer, String, Float, Text, DateTime, JSON
from sqlalchemy.sql import func

from app.db.base import Base


class Career(Base):
    __tablename__ = 'careers'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    category = Column(String(100), nullable=False, index=True)
    description = Column(Text, nullable=False)
    course = Column(String(255), nullable=False)
    college = Column(String(255), nullable=False)
    aptitude_match_categories = Column(JSON, nullable=False)  # List of categories
    base_score = Column(Float, default=60, nullable=False)
    suitable_streams = Column(JSON, nullable=False)  # List of streams (PCM, PCB, Commerce, Arts, Science)
    min_percentage = Column(Float, default=50, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
