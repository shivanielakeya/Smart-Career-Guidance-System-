from sqlalchemy import Column, Integer, Float, ForeignKey, DateTime
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.db.base import Base


class AptitudeResult(Base):
    __tablename__ = 'aptitude_results'

    id = Column(Integer, primary_key=True, index=True)
    student_profile_id = Column(Integer, ForeignKey('student_profiles.id', ondelete='CASCADE'), nullable=False, index=True)
    overall_score = Column(Float, nullable=False)
    quantitative_score = Column(Float, nullable=False)
    logical_score = Column(Float, nullable=False)
    analytical_score = Column(Float, nullable=False)
    verbal_score = Column(Float, nullable=False)
    data_interpretation_score = Column(Float, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    student_profile = relationship('StudentProfile', backref='aptitude_results')
