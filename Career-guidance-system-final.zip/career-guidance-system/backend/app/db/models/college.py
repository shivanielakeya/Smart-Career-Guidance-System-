from sqlalchemy import Column, Integer, String, Float, DateTime, JSON
from sqlalchemy.sql import func

from app.db.base import Base


class College(Base):
    __tablename__ = 'colleges'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    category = Column(String(100), nullable=False, index=True)
    city = Column(String(150), nullable=False, index=True)
    district = Column(String(150), nullable=False, index=True)
    state = Column(String(150), nullable=False)
    cutoff = Column(Float, nullable=False)
    courses = Column(JSON, nullable=False)  # List of course names
    career_opportunities = Column(JSON, nullable=False)  # List of career names
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
