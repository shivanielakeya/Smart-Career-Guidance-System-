from sqlalchemy import Column, Integer, String, Date, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.db.base import Base


class StudentProfile(Base):
    __tablename__ = 'student_profiles'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    full_name = Column(String(255), nullable=False)
    date_of_birth = Column(Date, nullable=False)
    gender = Column(String(50), nullable=True)
    contact_number = Column(String(50), nullable=True)
    district = Column(String(150), nullable=True)
    state = Column(String(150), default='Tamil Nadu', nullable=False)
    school = Column(String(255), nullable=True)
    school_type = Column(String(100), nullable=True)
    parent_name = Column(String(255), nullable=True)
    parent_contact = Column(String(50), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user = relationship('User', backref='student_profile')
