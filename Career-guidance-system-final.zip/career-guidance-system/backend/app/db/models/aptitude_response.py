from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.db.base import Base


class AptitudeResponse(Base):
    __tablename__ = 'aptitude_responses'

    id = Column(Integer, primary_key=True, index=True)
    student_profile_id = Column(Integer, ForeignKey('student_profiles.id', ondelete='CASCADE'), nullable=False, index=True)
    question_id = Column(Integer, ForeignKey('aptitude_questions.id', ondelete='CASCADE'), nullable=False, index=True)
    selected_option = Column(String(20), nullable=False)
    is_correct = Column(Boolean, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    question = relationship('AptitudeQuestion', backref='responses')
