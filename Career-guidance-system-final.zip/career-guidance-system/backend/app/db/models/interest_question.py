from sqlalchemy import Column, Integer, Text, DateTime
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.db.base import Base


class InterestQuestion(Base):
    __tablename__ = 'interest_questions'

    id = Column(Integer, primary_key=True, index=True)
    question = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    options = relationship('InterestOption', back_populates='question', cascade='all, delete-orphan')
