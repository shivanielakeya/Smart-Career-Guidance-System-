from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.db.base import Base


class InterestOption(Base):
    __tablename__ = 'interest_options'

    id = Column(Integer, primary_key=True, index=True)
    question_id = Column(Integer, ForeignKey('interest_questions.id', ondelete='CASCADE'), nullable=False, index=True)
    option_key = Column(String(2), nullable=False)
    label = Column(String(10), nullable=False)
    text = Column(String(500), nullable=False)
    category = Column(String(100), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    question = relationship('InterestQuestion', back_populates='options')
