from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.db.base import Base


class EducationRecord(Base):
    __tablename__ = 'education_records'

    id = Column(Integer, primary_key=True, index=True)
    student_profile_id = Column(Integer, ForeignKey('student_profiles.id', ondelete='CASCADE'), nullable=False, index=True)
    level = Column(String(50), nullable=False)
    board = Column(String(100), nullable=True)
    year = Column(Integer, nullable=True)
    total_marks = Column(Integer, nullable=True)
    marks_obtained = Column(Integer, nullable=True)
    percentage = Column(Float, nullable=True)
    stream = Column(String(100), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    student_profile = relationship('StudentProfile', backref='education_records')
