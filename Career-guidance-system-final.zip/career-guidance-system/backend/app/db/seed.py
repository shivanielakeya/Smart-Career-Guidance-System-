from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from app.db.base import Base
from app.db.models.aptitude_question import AptitudeQuestion
from app.db.models.interest_question import InterestQuestion
from app.db.models.interest_option import InterestOption


def create_database(database_url: str):
    engine = create_engine(database_url, future=True)
    Base.metadata.create_all(engine)
    return engine


def seed_aptitude_questions(session: Session):
    questions = [
        {
            'question': 'If 5x + 7 = 2x + 19, what is x?',
            'category': 'Quantitative Ability',
            'difficulty': 'Easy',
            'option_a': '2',
            'option_b': '3',
            'option_c': '4',
            'option_d': '5',
            'correct_answer': 'option_c',
            'explanation': 'Solve 5x - 2x = 19 - 7, so x = 12 / 3 = 4.',
        },
        {
            'question': 'A train covers 150 km in 3 hours. What is its average speed?',
            'category': 'Quantitative Ability',
            'difficulty': 'Easy',
            'option_a': '45 km/h',
            'option_b': '50 km/h',
            'option_c': '55 km/h',
            'option_d': '60 km/h',
            'correct_answer': 'option_b',
            'explanation': 'Speed = distance / time = 150 / 3 = 50 km/h.',
        },
        {
            'question': 'If the sequence is 3, 6, 12, 24, what is the 6th term?',
            'category': 'Logical Reasoning',
            'difficulty': 'Medium',
            'option_a': '96',
            'option_b': '48',
            'option_c': '72',
            'option_d': '120',
            'correct_answer': 'option_a',
            'explanation': 'Each term doubles, so 5th is 48 and 6th is 96.',
        },
        {
            'question': 'A set of numbers is 2, 6, 12, 20, 30. What is the next number in the pattern?',
            'category': 'Analytical Reasoning',
            'difficulty': 'Medium',
            'option_a': '36',
            'option_b': '42',
            'option_c': '48',
            'option_d': '56',
            'correct_answer': 'option_b',
            'explanation': 'The pattern is n*(n+1): 2, 6, 12, 20, 30, next is 42.',
        },
        {
            'question': 'Which word does not belong with the others?',
            'category': 'Verbal Ability',
            'difficulty': 'Easy',
            'option_a': 'Banana',
            'option_b': 'Apple',
            'option_c': 'Carrot',
            'option_d': 'Orange',
            'correct_answer': 'option_c',
            'explanation': 'Carrot is a vegetable while the others are fruits.',
        },
        {
            'question': 'If a train travels 180 km in 2.5 hours, what is the average speed?',
            'category': 'Quantitative Ability',
            'difficulty': 'Medium',
            'option_a': '64 km/h',
            'option_b': '68 km/h',
            'option_c': '72 km/h',
            'option_d': '76 km/h',
            'correct_answer': 'option_c',
            'explanation': '180 / 2.5 = 72 km/h.',
        },
        {
            'question': 'A rectangle has length 12 and width 5. What is its area?',
            'category': 'Data Interpretation',
            'difficulty': 'Easy',
            'option_a': '50',
            'option_b': '55',
            'option_c': '60',
            'option_d': '65',
            'correct_answer': 'option_c',
            'explanation': 'Area = length × width = 12 × 5 = 60.',
        },
        {
            'question': 'Which continues the series: 2, 4, 8, 16, ?',
            'category': 'Analytical Reasoning',
            'difficulty': 'Easy',
            'option_a': '18',
            'option_b': '24',
            'option_c': '32',
            'option_d': '36',
            'correct_answer': 'option_c',
            'explanation': 'The pattern doubles each term: next is 32.',
        },
        {
            'question': 'If a pair of shoes costs 180 rupees after a 20% discount, what was the original price?',
            'category': 'Quantitative Ability',
            'difficulty': 'Medium',
            'option_a': '210',
            'option_b': '220',
            'option_c': '225',
            'option_d': '240',
            'correct_answer': 'option_d',
            'explanation': 'After 20% discount, price is 80% of original. Original = 180 / 0.8 = 225.',
        },
        {
            'question': 'A shopkeeper sells an item for Rs. 460 after giving an 8% discount. What was the marked price?',
            'category': 'Quantitative Ability',
            'difficulty': 'Medium',
            'option_a': '480',
            'option_b': '490',
            'option_c': '500',
            'option_d': '510',
            'correct_answer': 'option_c',
            'explanation': 'Marked price × 0.92 = 460, so marked price = 460 / 0.92 = 500.',
        },
        {
            'question': 'The sum of three consecutive integers is 72. What is the largest integer?',
            'category': 'Quantitative Ability',
            'difficulty': 'Easy',
            'option_a': '23',
            'option_b': '24',
            'option_c': '25',
            'option_d': '26',
            'correct_answer': 'option_c',
            'explanation': 'Let the integers be x-1, x, x+1. Their sum is 3x = 72, so x = 24 and the largest is 25.',
        },
        {
            'question': 'Find the next number in the series: 1, 4, 9, 16, 25, ?',
            'category': 'Logical Reasoning',
            'difficulty': 'Easy',
            'option_a': '30',
            'option_b': '32',
            'option_c': '34',
            'option_d': '36',
            'correct_answer': 'option_d',
            'explanation': 'The series is perfect squares: 1², 2², 3², 4², 5², so the next term is 6² = 36.',
        },
        {
            'question': 'Which number replaces the question mark: 3, 9, 27, 81, ?',
            'category': 'Logical Reasoning',
            'difficulty': 'Easy',
            'option_a': '162',
            'option_b': '189',
            'option_c': '216',
            'option_d': '243',
            'correct_answer': 'option_d',
            'explanation': 'Each term is multiplied by 3, so the next term is 81 × 3 = 243.',
        },
        {
            'question': 'If CAT is coded as DBU, how is DOG coded using the same rule?',
            'category': 'Logical Reasoning',
            'difficulty': 'Medium',
            'option_a': 'EPH',
            'option_b': 'EQH',
            'option_c': 'FPH',
            'option_d': 'EPI',
            'correct_answer': 'option_a',
            'explanation': 'Each letter is shifted forward by one: D→E, O→P, G→H, giving EPH.',
        },
        {
            'question': 'Complete the series: 2, 5, 11, 23, 47, ?',
            'category': 'Logical Reasoning',
            'difficulty': 'Hard',
            'option_a': '94',
            'option_b': '95',
            'option_c': '96',
            'option_d': '97',
            'correct_answer': 'option_b',
            'explanation': 'Each term follows n × 2 + 1, so the next term is 47 × 2 + 1 = 95.',
        },
        {
            'question': 'A is taller than B. C is shorter than B. Who is the shortest?',
            'category': 'Analytical Reasoning',
            'difficulty': 'Easy',
            'option_a': 'A',
            'option_b': 'B',
            'option_c': 'C',
            'option_d': 'Cannot be determined',
            'correct_answer': 'option_c',
            'explanation': 'Since C is shorter than B, and B is shorter than A, C is the shortest.',
        },
        {
            'question': 'Ravi ranks 7th from the top and 18th from the bottom in his class. How many students are in the class?',
            'category': 'Analytical Reasoning',
            'difficulty': 'Medium',
            'option_a': '22',
            'option_b': '23',
            'option_c': '24',
            'option_d': '25',
            'correct_answer': 'option_c',
            'explanation': 'Total students = (rank from top) + (rank from bottom) - 1 = 7 + 18 - 1 = 24.',
        },
        {
            'question': 'If today is Wednesday, what day will it be after 17 days?',
            'category': 'Analytical Reasoning',
            'difficulty': 'Medium',
            'option_a': 'Friday',
            'option_b': 'Saturday',
            'option_c': 'Sunday',
            'option_d': 'Monday',
            'correct_answer': 'option_b',
            'explanation': '17 days is 2 full weeks plus 3 days. Wednesday + 3 days = Saturday.',
        },
        {
            'question': "Choose the word most opposite in meaning to 'Abundant'.",
            'category': 'Verbal Ability',
            'difficulty': 'Easy',
            'option_a': 'Plentiful',
            'option_b': 'Scarce',
            'option_c': 'Generous',
            'option_d': 'Ample',
            'correct_answer': 'option_b',
            'explanation': "'Scarce' means in short supply, the opposite of 'abundant'.",
        },
        {
            'question': "Choose the word most similar in meaning to 'Meticulous'.",
            'category': 'Verbal Ability',
            'difficulty': 'Easy',
            'option_a': 'Careless',
            'option_b': 'Careful',
            'option_c': 'Hasty',
            'option_d': 'Lazy',
            'correct_answer': 'option_b',
            'explanation': "'Meticulous' means showing great attention to detail, closest to 'careful'.",
        },
        {
            'question': "Fill in the blank: She was too tired ___ continue working.",
            'category': 'Verbal Ability',
            'difficulty': 'Easy',
            'option_a': 'to',
            'option_b': 'for',
            'option_c': 'that',
            'option_d': 'of',
            'correct_answer': 'option_a',
            'explanation': "The idiom 'too ... to' correctly completes the sentence.",
        },
        {
            'question': 'Choose the correctly spelled word.',
            'category': 'Verbal Ability',
            'difficulty': 'Easy',
            'option_a': 'Recieve',
            'option_b': 'Receive',
            'option_c': 'Receeve',
            'option_d': 'Receve',
            'correct_answer': 'option_b',
            'explanation': "The correct spelling follows 'i before e except after c': Receive.",
        },
        {
            'question': 'A survey of 200 students found that 120 prefer tea and the rest prefer coffee. What percentage prefer coffee?',
            'category': 'Data Interpretation',
            'difficulty': 'Easy',
            'option_a': '30',
            'option_b': '35',
            'option_c': '40',
            'option_d': '45',
            'correct_answer': 'option_c',
            'explanation': '80 out of 200 prefer coffee, which is (80 / 200) × 100 = 40%.',
        },
        {
            'question': 'Sales rose from 200 units in January to 250 units in February. What is the percentage increase?',
            'category': 'Data Interpretation',
            'difficulty': 'Medium',
            'option_a': '20',
            'option_b': '22',
            'option_c': '25',
            'option_d': '28',
            'correct_answer': 'option_c',
            'explanation': 'Increase = 50 units. Percentage increase = (50 / 200) × 100 = 25%.',
        },
        {
            'question': 'A budget pie chart shows: Housing 40%, Food 25%, Transport 15%, Other 20%. If the total budget is Rs. 40,000, how much is spent on Food?',
            'category': 'Data Interpretation',
            'difficulty': 'Medium',
            'option_a': '8000',
            'option_b': '9000',
            'option_c': '10000',
            'option_d': '11000',
            'correct_answer': 'option_c',
            'explanation': '25% of 40,000 = 10,000.',
        },
        {
            'question': 'The average of 5 numbers is 20. If one number is removed, the average of the remaining 4 becomes 18. What was the removed number?',
            'category': 'Data Interpretation',
            'difficulty': 'Hard',
            'option_a': '26',
            'option_b': '27',
            'option_c': '28',
            'option_d': '29',
            'correct_answer': 'option_c',
            'explanation': 'Sum of 5 numbers = 100. Sum of remaining 4 = 72. Removed number = 100 - 72 = 28.',
        },
    ]

    for item in questions:
        existing = session.query(AptitudeQuestion).filter(AptitudeQuestion.question == item['question']).first()
        if not existing:
            session.add(AptitudeQuestion(**item))
    session.commit()


def seed_interest_questions(session: Session):
    questions = [
        {
            'question': 'Which activity sounds most interesting to you?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Building an application or writing code.', 'category': 'Technology'},
                {'option_key': 'B', 'label': 'B', 'text': 'Understanding the human body and health.', 'category': 'Healthcare'},
                {'option_key': 'C', 'label': 'C', 'text': 'Managing a team or running a business.', 'category': 'Business'},
                {'option_key': 'D', 'label': 'D', 'text': 'Designing visuals or creative layouts.', 'category': 'Design'},
            ],
        },
        {
            'question': 'Which scenario appeals to you most?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Analyzing data to find insights.', 'category': 'Finance'},
                {'option_key': 'B', 'label': 'B', 'text': 'Creating a user interface for a website.', 'category': 'Design'},
                {'option_key': 'C', 'label': 'C', 'text': 'Conducting experiments in a laboratory.', 'category': 'Science'},
                {'option_key': 'D', 'label': 'D', 'text': 'Teaching a class or mentoring students.', 'category': 'Education'},
            ],
        },
        {
            'question': 'What kind of problem would you rather solve?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Building software solutions.', 'category': 'Technology'},
                {'option_key': 'B', 'label': 'B', 'text': 'Planning a business strategy.', 'category': 'Business'},
                {'option_key': 'C', 'label': 'C', 'text': 'Interpreting data and numbers.', 'category': 'Finance'},
                {'option_key': 'D', 'label': 'D', 'text': 'Creating engaging visual designs.', 'category': 'Design'},
            ],
        },
        {
            'question': 'Which description fits you best?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'I enjoy systematic thinking and structure.', 'category': 'Engineering'},
                {'option_key': 'B', 'label': 'B', 'text': 'I enjoy advising people and solving problems.', 'category': 'Law'},
                {'option_key': 'C', 'label': 'C', 'text': 'I enjoy working with numbers and budgets.', 'category': 'Finance'},
                {'option_key': 'D', 'label': 'D', 'text': 'I enjoy storytelling and creating content.', 'category': 'Media'},
            ],
        },
        {
            'question': 'Which setting do you prefer?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'A hospital or healthcare environment.', 'category': 'Healthcare'},
                {'option_key': 'B', 'label': 'B', 'text': 'A studio or creative workspace.', 'category': 'Design'},
                {'option_key': 'C', 'label': 'C', 'text': 'A corporate office or team room.', 'category': 'Management'},
                {'option_key': 'D', 'label': 'D', 'text': 'A lab or research facility.', 'category': 'Science'},
            ],
        },
        {
            'question': 'Which project would you enjoy leading?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Building a mobile app from scratch.', 'category': 'Technology'},
                {'option_key': 'B', 'label': 'B', 'text': 'Organizing a fundraising campaign.', 'category': 'Business'},
                {'option_key': 'C', 'label': 'C', 'text': 'Running clinical trials for a new medicine.', 'category': 'Healthcare'},
                {'option_key': 'D', 'label': 'D', 'text': 'Directing a short film.', 'category': 'Media'},
            ],
        },
        {
            'question': 'Which subject do you enjoy the most?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Mathematics and Physics.', 'category': 'Engineering'},
                {'option_key': 'B', 'label': 'B', 'text': 'Biology.', 'category': 'Healthcare'},
                {'option_key': 'C', 'label': 'C', 'text': 'Economics.', 'category': 'Finance'},
                {'option_key': 'D', 'label': 'D', 'text': 'Art and Literature.', 'category': 'Design'},
            ],
        },
        {
            'question': 'What motivates you most at work?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Solving complex technical problems.', 'category': 'Technology'},
                {'option_key': 'B', 'label': 'B', 'text': 'Helping people resolve disputes fairly.', 'category': 'Law'},
                {'option_key': 'C', 'label': 'C', 'text': "Growing a company's revenue.", 'category': 'Business'},
                {'option_key': 'D', 'label': 'D', 'text': 'Discovering how things work through experiments.', 'category': 'Science'},
            ],
        },
        {
            'question': "Pick the task you'd find most satisfying.",
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Debugging a piece of code until it works.', 'category': 'Technology'},
                {'option_key': 'B', 'label': 'B', 'text': 'Preparing a lesson plan for students.', 'category': 'Education'},
                {'option_key': 'C', 'label': 'C', 'text': "Managing a project team's deadlines.", 'category': 'Management'},
                {'option_key': 'D', 'label': 'D', 'text': 'Sketching a new product design.', 'category': 'Design'},
            ],
        },
        {
            'question': 'Which outcome would make you feel most accomplished?',
            'options': [
                {'option_key': 'A', 'label': 'A', 'text': 'Launching a useful technology product.', 'category': 'Technology'},
                {'option_key': 'B', 'label': 'B', 'text': 'Improving someone\'s health or wellbeing.', 'category': 'Healthcare'},
                {'option_key': 'C', 'label': 'C', 'text': 'Growing a successful organization.', 'category': 'Business'},
                {'option_key': 'D', 'label': 'D', 'text': 'Creating work that inspires people.', 'category': 'Media'},
            ],
        },
    ]

    for entry in questions:
        existing = session.query(InterestQuestion).filter(InterestQuestion.question == entry['question']).first()
        if not existing:
            question = InterestQuestion(question=entry['question'])
            session.add(question)
            session.flush()
            for option_data in entry['options']:
                session.add(InterestOption(question_id=question.id, **option_data))
    session.commit()


def seed_careers(session: Session):
    from app.db.models.career import Career

    careers = [
        {
            'name': 'Software Developer',
            'category': 'Technology',
            'description': 'Build and maintain software applications using programming, problem solving, and engineering thinking.',
            'course': 'B.Tech Computer Science',
            'college': 'Anna University',
            'aptitude_match_categories': ['Quantitative Ability', 'Logical Reasoning'],
            'base_score': 70,
            'suitable_streams': ['PCM', 'Science'],
            'min_percentage': 75,
        },
        {
            'name': 'Data Analyst',
            'category': 'Finance',
            'description': 'Analyze business data, generate insights, and support decision-making using statistics and visualization.',
            'course': 'B.Sc Statistics',
            'college': 'Madras Christian College',
            'aptitude_match_categories': ['Data Interpretation', 'Analytical Reasoning'],
            'base_score': 65,
            'suitable_streams': ['PCM', 'Science', 'Commerce'],
            'min_percentage': 70,
        },
        {
            'name': 'Civil Engineer',
            'category': 'Engineering',
            'description': 'Design and manage construction projects, infrastructure, and urban development with practical engineering skills.',
            'course': 'B.E Civil Engineering',
            'college': 'PSG College of Technology',
            'aptitude_match_categories': ['Analytical Reasoning', 'Quantitative Ability'],
            'base_score': 60,
            'suitable_streams': ['PCM', 'Science'],
            'min_percentage': 65,
        },
        {
            'name': 'Graphic Designer',
            'category': 'Design',
            'description': 'Create visual content, branding, and digital design for communication and creative experiences.',
            'course': 'B.Des Visual Communication',
            'college': 'Sathyabama Institute of Science and Technology',
            'aptitude_match_categories': ['Verbal Ability', 'Analytical Reasoning'],
            'base_score': 55,
            'suitable_streams': ['Arts', 'Commerce', 'Science'],
            'min_percentage': 50,
        },
        {
            'name': 'Medical Laboratory Technologist',
            'category': 'Healthcare',
            'description': 'Work in diagnostic labs, supporting healthcare through tests, data analysis, and clinical reporting.',
            'course': 'B.Sc Medical Laboratory Science',
            'college': 'SRM Institute of Science and Technology',
            'aptitude_match_categories': ['Data Interpretation', 'Logical Reasoning'],
            'base_score': 58,
            'suitable_streams': ['PCB', 'Science'],
            'min_percentage': 70,
        },
        {
            'name': 'Business Analyst',
            'category': 'Business',
            'description': 'Bridge business needs and technical solutions through analysis, communication, and strategy.',
            'course': 'BBA Business Analytics',
            'college': 'Loyola College',
            'aptitude_match_categories': ['Data Interpretation', 'Verbal Ability'],
            'base_score': 62,
            'suitable_streams': ['Commerce', 'PCM', 'Science'],
            'min_percentage': 68,
        },
        {
            'name': 'Doctor (MBBS)',
            'category': 'Healthcare',
            'description': 'Practice medicine, diagnose diseases, and provide patient care using medical knowledge and clinical skills.',
            'course': 'Bachelor of Medicine, Bachelor of Surgery',
            'college': 'Tamil Nadu Medical College',
            'aptitude_match_categories': ['Data Interpretation', 'Analytical Reasoning'],
            'base_score': 75,
            'suitable_streams': ['PCB', 'Science'],
            'min_percentage': 85,
        },
        {
            'name': 'Chartered Accountant',
            'category': 'Finance',
            'description': 'Manage financial records, taxation, and auditing for businesses and individuals.',
            'course': 'B.Com Accounting',
            'college': 'Madras University',
            'aptitude_match_categories': ['Quantitative Ability', 'Logical Reasoning'],
            'base_score': 68,
            'suitable_streams': ['Commerce'],
            'min_percentage': 72,
        },
        {
            'name': 'Mechanical Engineer',
            'category': 'Engineering',
            'description': 'Design, develop, and improve machines, manufacturing systems, and mechanical products.',
            'course': 'B.E Mechanical Engineering',
            'college': 'PSG College of Technology',
            'aptitude_match_categories': ['Quantitative Ability', 'Analytical Reasoning'],
            'base_score': 64,
            'suitable_streams': ['PCM', 'Science'],
            'min_percentage': 65,
        },
        {
            'name': 'Electrical Engineer',
            'category': 'Engineering',
            'description': 'Plan and build electrical systems, power solutions, and electronic control systems.',
            'course': 'B.E Electrical Engineering',
            'college': 'Anna University',
            'aptitude_match_categories': ['Quantitative Ability', 'Logical Reasoning'],
            'base_score': 63,
            'suitable_streams': ['PCM', 'Science'],
            'min_percentage': 65,
        },
        {
            'name': 'Data Scientist',
            'category': 'Technology',
            'description': 'Use statistics, programming, and machine learning to turn data into useful decisions.',
            'course': 'B.Tech Data Science',
            'college': 'Anna University',
            'aptitude_match_categories': ['Data Interpretation', 'Analytical Reasoning'],
            'base_score': 72,
            'suitable_streams': ['PCM', 'Science', 'Commerce'],
            'min_percentage': 75,
        },
        {
            'name': 'AI/ML Engineer',
            'category': 'Technology',
            'description': 'Build intelligent software systems with machine learning models and applied artificial intelligence.',
            'course': 'B.Tech Artificial Intelligence and Machine Learning',
            'college': 'Sathyabama Institute of Science and Technology',
            'aptitude_match_categories': ['Logical Reasoning', 'Data Interpretation'],
            'base_score': 73,
            'suitable_streams': ['PCM', 'Science'],
            'min_percentage': 75,
        },
        {
            'name': 'Registered Nurse',
            'category': 'Healthcare',
            'description': 'Provide patient care, coordinate treatment, and support recovery in clinical settings.',
            'course': 'B.Sc Nursing',
            'college': 'SRM Institute of Science and Technology',
            'aptitude_match_categories': ['Verbal Ability', 'Logical Reasoning'],
            'base_score': 66,
            'suitable_streams': ['PCB', 'Science'],
            'min_percentage': 70,
        },
        {
            'name': 'Pharmacist',
            'category': 'Healthcare',
            'description': 'Prepare and advise on medicines while supporting safe and effective patient treatment.',
            'course': 'B.Pharm Pharmacy',
            'college': 'Tamil Nadu Medical College',
            'aptitude_match_categories': ['Data Interpretation', 'Analytical Reasoning'],
            'base_score': 64,
            'suitable_streams': ['PCB', 'Science'],
            'min_percentage': 70,
        },
        {
            'name': 'Financial Analyst',
            'category': 'Finance',
            'description': 'Evaluate financial information, budgets, and market trends to guide business decisions.',
            'course': 'B.Com Finance',
            'college': 'Madras University',
            'aptitude_match_categories': ['Quantitative Ability', 'Data Interpretation'],
            'base_score': 66,
            'suitable_streams': ['Commerce', 'PCM'],
            'min_percentage': 65,
        },
        {
            'name': 'Auditor',
            'category': 'Finance',
            'description': 'Review financial records and controls to support accuracy, compliance, and accountability.',
            'course': 'B.Com Accounting',
            'college': 'Madras University',
            'aptitude_match_categories': ['Quantitative Ability', 'Logical Reasoning'],
            'base_score': 64,
            'suitable_streams': ['Commerce'],
            'min_percentage': 65,
        },
        {
            'name': 'UI/UX Designer',
            'category': 'Design',
            'description': 'Design clear, useful digital experiences through user research, interaction, and visual design.',
            'course': 'B.Des User Experience Design',
            'college': 'Sathyabama Institute of Science and Technology',
            'aptitude_match_categories': ['Analytical Reasoning', 'Verbal Ability'],
            'base_score': 62,
            'suitable_streams': ['Arts', 'Commerce', 'Science'],
            'min_percentage': 55,
        },
        {
            'name': 'Fashion Designer',
            'category': 'Design',
            'description': 'Create clothing and accessory concepts through creative direction, materials, and design technique.',
            'course': 'B.Des Fashion Design',
            'college': 'Sathyabama Institute of Science and Technology',
            'aptitude_match_categories': ['Verbal Ability', 'Analytical Reasoning'],
            'base_score': 58,
            'suitable_streams': ['Arts', 'Commerce'],
            'min_percentage': 50,
        },
        {
            'name': 'Lawyer',
            'category': 'Law',
            'description': 'Advise clients, interpret laws, and represent people or organizations in legal matters.',
            'course': 'B.A. LL.B Law',
            'college': 'Loyola College',
            'aptitude_match_categories': ['Verbal Ability', 'Logical Reasoning'],
            'base_score': 63,
            'suitable_streams': ['Arts', 'Commerce', 'Science'],
            'min_percentage': 60,
        },
        {
            'name': 'Legal Consultant',
            'category': 'Law',
            'description': 'Research legal requirements and provide practical guidance for contracts, policy, and compliance.',
            'course': 'B.B.A. LL.B Business Law',
            'college': 'Loyola College',
            'aptitude_match_categories': ['Verbal Ability', 'Analytical Reasoning'],
            'base_score': 61,
            'suitable_streams': ['Arts', 'Commerce'],
            'min_percentage': 60,
        },
        {
            'name': 'Project Manager',
            'category': 'Management',
            'description': 'Plan projects, coordinate teams, and deliver outcomes within scope, time, and budget.',
            'course': 'BBA Business Management',
            'college': 'Loyola College',
            'aptitude_match_categories': ['Logical Reasoning', 'Verbal Ability'],
            'base_score': 65,
            'suitable_streams': ['Commerce', 'Arts', 'Science'],
            'min_percentage': 60,
        },
        {
            'name': 'Marketing Manager',
            'category': 'Management',
            'description': 'Shape marketing strategy, understand customers, and grow products through coordinated campaigns.',
            'course': 'BBA Marketing',
            'college': 'Loyola College',
            'aptitude_match_categories': ['Verbal Ability', 'Data Interpretation'],
            'base_score': 62,
            'suitable_streams': ['Commerce', 'Arts'],
            'min_percentage': 60,
        },
        {
            'name': 'School Teacher',
            'category': 'Education',
            'description': 'Teach academic subjects, assess learning, and help students build confidence and understanding.',
            'course': 'B.Ed Education',
            'college': 'Madras Christian College',
            'aptitude_match_categories': ['Verbal Ability', 'Analytical Reasoning'],
            'base_score': 60,
            'suitable_streams': ['Arts', 'Commerce', 'Science'],
            'min_percentage': 55,
        },
        {
            'name': 'Education Counselor',
            'category': 'Education',
            'description': 'Guide students through academic choices, applications, learning goals, and career planning.',
            'course': 'B.A. Education Psychology',
            'college': 'Madras Christian College',
            'aptitude_match_categories': ['Verbal Ability', 'Logical Reasoning'],
            'base_score': 59,
            'suitable_streams': ['Arts', 'Commerce', 'Science'],
            'min_percentage': 55,
        },
    ]

    for career_data in careers:
        existing = session.query(Career).filter(Career.name == career_data['name']).first()
        if not existing:
            session.add(Career(**career_data))
    session.commit()


def seed_colleges(session: Session):
    from app.db.models.college import College

    colleges = [
        {
            'name': 'Anna University',
            'category': 'Engineering',
            'city': 'Chennai',
            'district': 'Chennai',
            'state': 'Tamil Nadu',
            'cutoff': 90,
            'courses': ['B.Tech Computer Science', 'B.Tech Civil Engineering', 'B.Tech Mechanical'],
            'career_opportunities': ['Software Developer', 'Civil Engineer', 'Mechanical Engineer'],
        },
        {
            'name': 'Madras Christian College',
            'category': 'General',
            'city': 'Chennai',
            'district': 'Chennai',
            'state': 'Tamil Nadu',
            'cutoff': 75,
            'courses': ['B.Sc Statistics', 'B.Sc Physics', 'B.Sc Mathematics'],
            'career_opportunities': ['Data Analyst', 'Statistician', 'Researcher'],
        },
        {
            'name': 'PSG College of Technology',
            'category': 'Engineering',
            'city': 'Coimbatore',
            'district': 'Coimbatore',
            'state': 'Tamil Nadu',
            'cutoff': 88,
            'courses': ['B.E Civil Engineering', 'B.E Mechanical', 'B.E Electrical'],
            'career_opportunities': ['Civil Engineer', 'Mechanical Engineer', 'Electrical Engineer'],
        },
        {
            'name': 'Sathyabama Institute of Science and Technology',
            'category': 'Engineering',
            'city': 'Chennai',
            'district': 'Chennai',
            'state': 'Tamil Nadu',
            'cutoff': 70,
            'courses': ['B.Des Visual Communication', 'B.Tech Information Technology', 'B.Sc Design'],
            'career_opportunities': ['Graphic Designer', 'Software Developer', 'UI/UX Designer'],
        },
        {
            'name': 'SRM Institute of Science and Technology',
            'category': 'General',
            'city': 'Chennai',
            'district': 'Chennai',
            'state': 'Tamil Nadu',
            'cutoff': 85,
            'courses': ['B.Sc Medical Laboratory Science', 'B.Tech Biotechnology', 'B.Sc Microbiology'],
            'career_opportunities': ['Medical Laboratory Technologist', 'Biotechnologist', 'Microbiologist'],
        },
        {
            'name': 'Loyola College',
            'category': 'General',
            'city': 'Chennai',
            'district': 'Chennai',
            'state': 'Tamil Nadu',
            'cutoff': 72,
            'courses': ['BBA Business Analytics', 'BBA Finance', 'BBA Marketing'],
            'career_opportunities': ['Business Analyst', 'Financial Analyst', 'Marketing Manager'],
        },
        {
            'name': 'Tamil Nadu Medical College',
            'category': 'Medical',
            'city': 'Chennai',
            'district': 'Chennai',
            'state': 'Tamil Nadu',
            'cutoff': 95,
            'courses': ['Bachelor of Medicine, Bachelor of Surgery'],
            'career_opportunities': ['Doctor (MBBS)', 'Surgeon', 'Medical Researcher'],
        },
        {
            'name': 'Madras University',
            'category': 'General',
            'city': 'Chennai',
            'district': 'Chennai',
            'state': 'Tamil Nadu',
            'cutoff': 78,
            'courses': ['B.Com Accounting', 'B.Com Finance', 'BBA Accounting'],
            'career_opportunities': ['Chartered Accountant', 'Financial Analyst', 'Auditor'],
        },
    ]

    for college_data in colleges:
        existing = session.query(College).filter(College.name == college_data['name']).first()
        if not existing:
            session.add(College(**college_data))
    session.commit()


def seed_database(database_url: str):
    engine = create_engine(database_url, future=True)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    Base.metadata.create_all(engine)

    with SessionLocal() as session:
        seed_aptitude_questions(session)
        seed_interest_questions(session)
        seed_careers(session)
        seed_colleges(session)


if __name__ == '__main__':
    from dotenv import load_dotenv
    from app.core.config import get_settings

    load_dotenv()
    settings = get_settings()
    seed_database(settings.database_url)
    print('Database seeded successfully.')
