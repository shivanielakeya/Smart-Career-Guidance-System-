from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings
from typing import Optional
import json
import os


class Settings(BaseSettings):
    database_url: str = "sqlite:///./career_guidance_dev.db"
    jwt_secret: str = "supersecretjwtkey123"
    ai_api_key: Optional[str] = None
    ai_api_url: str = "https://api.openai.com/v1/chat/completions"
    ai_model: str = "gpt-4o-mini"
    powerbi_embed_url: Optional[str] = None
    powerbi_embed_token: Optional[str] = None
    powerbi_report_id: Optional[str] = None
    admin_setup_key: Optional[str] = None
    cors_origins: list[str] = [
        "http://localhost:4173",
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:4173",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
    ]

    class Config:
        # Load .env from backend directory
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "allow"

    def __init__(self, **data):
        # Set defaults from environment variables or .env file
        super().__init__(**data)
        
        # Parse CORS_ORIGINS from environment if it's a JSON string
        cors_env = os.getenv("CORS_ORIGINS")
        if cors_env:
            try:
                # Try to parse as JSON
                self.cors_origins = json.loads(cors_env)
            except (json.JSONDecodeError, TypeError):
                # If JSON parsing fails, treat as comma-separated string
                self.cors_origins = [origin.strip() for origin in cors_env.split(",")]


@lru_cache()
def get_settings() -> Settings:
    return Settings()
