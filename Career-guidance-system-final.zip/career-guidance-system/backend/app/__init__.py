# Smart Career Guidance backend package
