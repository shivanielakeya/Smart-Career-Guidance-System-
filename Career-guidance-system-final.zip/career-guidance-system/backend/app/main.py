from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import auth, health, students, education, aptitude, interest, recommendations, admin, careers, colleges, chat, translation, analytics
from app.core.config import get_settings
from app.db.base import Base
from app.db.session import engine

settings = get_settings()
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title='Smart Career Guidance API',
    description='Backend API for student career guidance and recommendation services.',
    version='0.2.0'
)

# Configure CORS with explicit settings for better preflight handling
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
    expose_headers=["Content-Type"],
    max_age=600,  # Cache preflight requests for 10 minutes
)

# Include all routers
app.include_router(auth, prefix='/api/auth', tags=['auth'])
app.include_router(health, prefix='/api/health', tags=['health'])
app.include_router(students, prefix='/api', tags=['students'])
app.include_router(education, prefix='/api', tags=['education'])
app.include_router(aptitude, prefix='/api/aptitude', tags=['aptitude'])
app.include_router(interest, prefix='/api/interest', tags=['interest'])
app.include_router(recommendations, prefix='/api/recommendations', tags=['recommendations'])
app.include_router(admin, prefix='/api/admin', tags=['admin'])
app.include_router(careers.router, prefix='/api', tags=['careers'])
app.include_router(colleges.router, prefix='/api', tags=['colleges'])
app.include_router(chat.router, prefix='/api/chat', tags=['chat'])
app.include_router(translation.router, prefix='/api/translate', tags=['translation'])
app.include_router(analytics.router, prefix='/api/admin/analytics', tags=['analytics'])
app.include_router(analytics.router, prefix='/api/analytics', tags=['analytics-events'])
