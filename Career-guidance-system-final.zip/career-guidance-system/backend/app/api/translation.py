import json

import httpx
from fastapi import APIRouter, Depends, HTTPException, status

from app.core.config import get_settings
from app.core.dependencies import get_current_user
from app.schemas.translation import TranslationRequest, TranslationResponse

router = APIRouter()


@router.post('', response_model=TranslationResponse)
def translate(payload: TranslationRequest, current_user=Depends(get_current_user)):
    if payload.language == 'en':
        return TranslationResponse(translations=payload.texts, provider='identity', model='none')

    settings = get_settings()
    if not settings.ai_api_key:
        return TranslationResponse(translations=payload.texts, provider='original-text-fallback', model='none')

    system_prompt = (
        'Translate each input string into natural Tamil. Preserve names, numbers, percentages, URLs, '
        'course codes, and formatting. Return only a JSON array of translated strings in the same order.'
    )
    try:
        with httpx.Client(timeout=20.0) as client:
            response = client.post(
                settings.ai_api_url,
                headers={'Authorization': f'Bearer {settings.ai_api_key}', 'Content-Type': 'application/json'},
                json={
                    'model': settings.ai_model,
                    'messages': [
                        {'role': 'system', 'content': system_prompt},
                        {'role': 'user', 'content': json.dumps(payload.texts, ensure_ascii=False)},
                    ],
                    'temperature': 0.1,
                    'max_tokens': 2000,
                },
            )
            response.raise_for_status()
            content = response.json()['choices'][0]['message']['content'].strip()
            translations = json.loads(content)
            if not isinstance(translations, list) or len(translations) != len(payload.texts):
                raise ValueError('Translation count did not match input count')
    except (httpx.HTTPError, KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail='Translation service is temporarily unavailable') from exc

    return TranslationResponse(translations=translations, provider='openai-compatible', model=settings.ai_model)