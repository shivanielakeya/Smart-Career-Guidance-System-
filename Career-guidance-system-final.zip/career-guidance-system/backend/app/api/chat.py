import json
from typing import Any

import httpx
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.dependencies import get_current_user, get_db
from app.db.models.aptitude_result import AptitudeResult
from app.db.models.career import Career
from app.db.models.college import College
from app.db.models.education_record import EducationRecord
from app.db.models.interest_response import InterestResponse
from app.db.models.student_profile import StudentProfile
from app.schemas.chat import ChatRequest, ChatResponse
from app.services.recommendation_service import RecommendationService

router = APIRouter()


def _student_context(db: Session, user_id: int) -> dict[str, Any]:
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == user_id).first()
    if not profile:
        return {'profile': None, 'education': [], 'aptitude': None, 'interests': {}, 'recommendations': {}}

    education = db.query(EducationRecord).filter(EducationRecord.student_profile_id == profile.id).all()
    aptitude = (
        db.query(AptitudeResult)
        .filter(AptitudeResult.student_profile_id == profile.id)
        .order_by(AptitudeResult.created_at.desc())
        .first()
    )
    responses = db.query(InterestResponse).filter(InterestResponse.student_profile_id == profile.id).all()
    interest_counts: dict[str, int] = {}
    for response in responses:
        interest_counts[response.category] = interest_counts.get(response.category, 0) + 1
    total_interests = len(responses) or 1
    interest_scores = {category: round(count / total_interests * 100, 1) for category, count in interest_counts.items()}

    aptitude_scores = (
        {
            'Quantitative Ability': aptitude.quantitative_score,
            'Logical Reasoning': aptitude.logical_score,
            'Analytical Reasoning': aptitude.analytical_score,
            'Verbal Ability': aptitude.verbal_score,
            'Data Interpretation': aptitude.data_interpretation_score,
        }
        if aptitude
        else {}
    )
    education_12th = next((record for record in education if record.level == '12th'), None)
    academic_eligibility, _ = RecommendationService.calculate_academic_eligibility(education_12th)
    stream_category = RecommendationService.stream_to_category(education_12th.stream) if education_12th else None
    career_recommendations = []
    for career in db.query(Career).all():
        score = RecommendationService.calculate_career_fit(
            career={
                'category': career.category,
                'base_score': career.base_score,
                'aptitude_match_categories': career.aptitude_match_categories or [],
                'suitable_streams': career.suitable_streams or [],
            },
            interest_scores=interest_scores,
            aptitude_scores=aptitude_scores,
            overall_score=aptitude.overall_score if aptitude else 0.0,
            academic_eligibility=academic_eligibility,
            stream_category=stream_category,
        )
        career_recommendations.append({'name': career.name, 'category': career.category, 'course': career.course, 'match_score': score})
    career_recommendations.sort(key=lambda item: item['match_score'], reverse=True)
    colleges = db.query(College).order_by(College.cutoff.asc()).limit(8).all()

    return {
        'profile': {
            'name': profile.full_name,
            'district': profile.district,
            'state': profile.state,
            'school': profile.school,
        },
        'education': [
            {
                'level': record.level,
                'board': record.board,
                'percentage': record.percentage,
                'stream': record.stream,
            }
            for record in education
        ],
        'aptitude': (
            {
                'overall_score': aptitude.overall_score,
                'category_scores': {
                    'Quantitative Ability': aptitude.quantitative_score,
                    'Logical Reasoning': aptitude.logical_score,
                    'Analytical Reasoning': aptitude.analytical_score,
                    'Verbal Ability': aptitude.verbal_score,
                    'Data Interpretation': aptitude.data_interpretation_score,
                },
            }
            if aptitude
            else None
        ),
        'interests': interest_scores,
        'recommendations': {
            'careers': career_recommendations[:8],
            'colleges': [
                {'name': college.name, 'city': college.city, 'cutoff': college.cutoff, 'courses': college.courses}
                for college in colleges
            ],
        },
    }


def _fallback_reply(message: str, context: dict[str, Any], language: str) -> str:
    lower_message = message.lower()
    if language == 'ta':
        if 'aptitude' in lower_message and context['aptitude']:
            return f"உங்கள் சமீபத்திய திறனறிவு மதிப்பெண் {context['aptitude']['overall_score']}%. எந்தப் பிரிவு மதிப்பெண்ணையும் தொழில்களுடன் இணைத்து விளக்க உதவுகிறேன்."
        if 'interest' in lower_message and context['interests']:
            strongest = max(context['interests'], key=context['interests'].get)
            return f"உங்கள் வலுவான ஆர்வப் பகுதி {strongest}, மதிப்பெண் {context['interests'][strongest]}%. அதற்கேற்ற பாடநெறிகள் மற்றும் தொழில்களை ஆராயலாம்."
        return 'தொழில்கள், பாடநெறிகள், திறன்கள், மதிப்பீட்டு முடிவுகள் மற்றும் கல்லூரிகள் பற்றி நான் உதவ முடியும். உங்கள் கேள்வியைத் தமிழில் கேளுங்கள்.'
    if 'aptitude' in lower_message and context['aptitude']:
        return f"Your latest aptitude score is {context['aptitude']['overall_score']}%. I can help you interpret any category score or connect it to suitable careers."
    if 'interest' in lower_message and context['interests']:
        strongest = max(context['interests'], key=context['interests'].get)
        return f"Your strongest recorded interest area is {strongest} at {context['interests'][strongest]}%. We can explore courses and careers that match it."
    if 'college' in lower_message:
        names = ', '.join(college['name'] for college in context['recommendations']['colleges'][:3])
        return f"Some colleges in the current catalog are {names}. Tell me your preferred course, state, or cutoff range for a narrower suggestion."
    names = ', '.join(career['name'] for career in context['recommendations']['careers'][:3])
    return f"I can help compare careers, courses, skills, aptitude, interests, and colleges. Good starting points from the catalog include {names}."


@router.post('', response_model=ChatResponse)
def chat(payload: ChatRequest, current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    settings = get_settings()
    context = _student_context(db, current_user.id)
    latest_message = payload.messages[-1].content.strip()
    if not latest_message:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail='Message cannot be empty')

    if not settings.ai_api_key:
        return ChatResponse(message=_fallback_reply(latest_message, context, payload.language), provider='local-fallback', model='career-guidance-context')

    system_prompt = (
        'You are a concise, supportive career guidance assistant. Answer only career, course, skill, '
        'aptitude, interest, recommendation, or college questions. Use the student context when relevant, '
        'avoid inventing scores or admission guarantees, and recommend checking official college sources. '
        f"Respond in {'Tamil' if payload.language == 'ta' else 'English'}. If context is missing, ask a focused follow-up question. Student context:\n"
        + json.dumps(context, default=str)
    )
    request_messages = [{'role': 'system', 'content': system_prompt}]
    request_messages.extend(message.model_dump() for message in payload.messages)

    try:
        with httpx.Client(timeout=20.0) as client:
            response = client.post(
                settings.ai_api_url,
                headers={'Authorization': f'Bearer {settings.ai_api_key}', 'Content-Type': 'application/json'},
                json={'model': settings.ai_model, 'messages': request_messages, 'temperature': 0.4, 'max_tokens': 500},
            )
            response.raise_for_status()
            response_data = response.json()
            answer = response_data['choices'][0]['message']['content'].strip()
    except (httpx.HTTPError, KeyError, IndexError, TypeError, ValueError) as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail='AI service is temporarily unavailable') from exc

    if not answer:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail='AI service returned an empty response')
    return ChatResponse(message=answer, provider='openai-compatible', model=settings.ai_model)