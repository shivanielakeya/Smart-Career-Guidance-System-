from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_current_user, get_db
from app.db.models.interest_question import InterestQuestion
from app.db.models.interest_option import InterestOption
from app.db.models.interest_response import InterestResponse
from app.db.models.student_profile import StudentProfile
from app.schemas.interest import InterestQuestionResponse, InterestSubmission, InterestResultResponse, InterestScore

router = APIRouter()

@router.get('/questions', response_model=list[InterestQuestionResponse])
def get_interest_questions(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    questions = db.query(InterestQuestion).all()
    result = []
    for question in questions:
        options = [
            {
                'key': option.option_key,
                'label': option.label,
                'text': option.text,
                'category': option.category,
            }
            for option in question.options
        ]
        result.append(InterestQuestionResponse(id=question.id, question=question.question, options=options))
    return result


@router.post('/submit', response_model=InterestResultResponse)
def submit_interest_answers(payload: InterestSubmission, current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')

    db.query(InterestResponse).filter(InterestResponse.student_profile_id == profile.id).delete()
    db.commit()

    category_count: dict[str, int] = {}
    for answer in payload.answers:
        option_query = db.query(InterestOption).filter(InterestOption.question_id == answer.question_id)
        if answer.option_id is not None:
            option = option_query.filter(InterestOption.id == answer.option_id).first()
            if not option:
                option = option_query.order_by(InterestOption.id).offset(answer.option_id - 1).first()
        else:
            option = option_query.filter(InterestOption.option_key == answer.answer).first()
        if not option:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Invalid answer option')

        db.add(InterestResponse(
            student_profile_id=profile.id,
            question_id=answer.question_id,
            option_key=option.option_key,
            category=option.category,
        ))
        category_count[option.category] = category_count.get(option.category, 0) + 1

    db.commit()

    total_answers = len(payload.answers)
    scores = [InterestScore(category=category, score=round((count / total_answers) * 100, 1)) for category, count in category_count.items()]
    return InterestResultResponse(scores=scores)


@router.get('/result', response_model=InterestResultResponse)
def get_interest_result(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')

    responses = db.query(InterestResponse).filter(InterestResponse.student_profile_id == profile.id).all()
    if not responses:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='No interest result found')

    category_count: dict[str, int] = {}
    for response in responses:
        category_count[response.category] = category_count.get(response.category, 0) + 1

    total = len(responses)
    scores = [InterestScore(category=category, score=round((count / total) * 100, 1)) for category, count in category_count.items()]
    return InterestResultResponse(scores=scores)
