from datetime import datetime
from io import BytesIO

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.db.models.aptitude_result import AptitudeResult
from app.db.models.interest_response import InterestResponse
from app.db.models.student_profile import StudentProfile
from app.db.models.education_record import EducationRecord
from app.db.models.career import Career
from app.db.models.college import College
from app.schemas.recommendation import RecommendationResponse
from app.services.recommendation_service import RecommendationService

router = APIRouter()

# Enhanced Career Library with stream suitability
CAREER_LIBRARY = [
    {
        'id': 1,
        'name': 'Software Developer',
        'category': 'Technology',
        'description': 'Build and maintain software applications using programming, problem solving, and engineering thinking.',
        'course': 'B.Tech Computer Science',
        'college': 'Anna University',
        'aptitude_match_categories': ['Quantitative Ability', 'Logical Reasoning'],
        'base_score': 70,
        'suitable_streams': ['PCM', 'Science'],
        'min_percentage': 75,
    },
    {
        'id': 2,
        'name': 'Data Analyst',
        'category': 'Finance',
        'description': 'Analyze business data, generate insights, and support decision-making using statistics and visualization.',
        'course': 'B.Sc Statistics',
        'college': 'Madras Christian College',
        'aptitude_match_categories': ['Data Interpretation', 'Analytical Reasoning'],
        'base_score': 65,
        'suitable_streams': ['PCM', 'Science', 'Commerce'],
        'min_percentage': 70,
    },
    {
        'id': 3,
        'name': 'Civil Engineer',
        'category': 'Engineering',
        'description': 'Design and manage construction projects, infrastructure, and urban development with practical engineering skills.',
        'course': 'B.E Civil Engineering',
        'college': 'PSG College of Technology',
        'aptitude_match_categories': ['Analytical Reasoning', 'Quantitative Ability'],
        'base_score': 60,
        'suitable_streams': ['PCM', 'Science'],
        'min_percentage': 65,
    },
    {
        'id': 4,
        'name': 'Graphic Designer',
        'category': 'Design',
        'description': 'Create visual content, branding, and digital design for communication and creative experiences.',
        'course': 'B.Des Visual Communication',
        'college': 'Sathyabama Institute of Science and Technology',
        'aptitude_match_categories': ['Verbal Ability', 'Analytical Reasoning'],
        'base_score': 55,
        'suitable_streams': ['Arts', 'Commerce', 'Science'],
        'min_percentage': 50,
    },
    {
        'id': 5,
        'name': 'Medical Laboratory Technologist',
        'category': 'Healthcare',
        'description': 'Work in diagnostic labs, supporting healthcare through tests, data analysis, and clinical reporting.',
        'course': 'B.Sc Medical Laboratory Science',
        'college': 'SRM Institute of Science and Technology',
        'aptitude_match_categories': ['Data Interpretation', 'Logical Reasoning'],
        'base_score': 58,
        'suitable_streams': ['PCB', 'Science'],
        'min_percentage': 70,
    },
    {
        'id': 6,
        'name': 'Business Analyst',
        'category': 'Business',
        'description': 'Bridge business needs and technical solutions through analysis, communication, and strategy.',
        'course': 'BBA Business Analytics',
        'college': 'Loyola College',
        'aptitude_match_categories': ['Logical Reasoning', 'Verbal Ability'],
        'base_score': 62,
        'suitable_streams': ['Commerce', 'PCM', 'Arts'],
        'min_percentage': 60,
    },
    {
        'id': 7,
        'name': 'Doctor (MBBS)',
        'category': 'Healthcare',
        'description': 'Provide medical care, diagnosis, and treatment to patients.',
        'course': 'MBBS (Bachelor of Medicine)',
        'college': 'JIPMER / Government Medical College',
        'aptitude_match_categories': ['Data Interpretation', 'Logical Reasoning', 'Analytical Reasoning'],
        'base_score': 75,
        'suitable_streams': ['PCB'],
        'min_percentage': 85,
    },
    {
        'id': 8,
        'name': 'Chartered Accountant',
        'category': 'Finance',
        'description': 'Provide financial and accounting services to individuals and businesses.',
        'course': 'B.Com / CA Course',
        'college': 'Madras University',
        'aptitude_match_categories': ['Quantitative Ability', 'Data Interpretation'],
        'base_score': 68,
        'suitable_streams': ['Commerce'],
        'min_percentage': 75,
    },
]

COURSE_LIBRARY = [
    {
        'id': 1,
        'name': 'B.Tech Computer Science',
        'category': 'Technology',
        'college': 'Anna University',
        'duration': '4 years',
    },
    {
        'id': 2,
        'name': 'B.Sc Statistics',
        'category': 'Finance',
        'college': 'Madras Christian College',
        'duration': '3 years',
    },
    {
        'id': 3,
        'name': 'B.E Civil Engineering',
        'category': 'Engineering',
        'college': 'PSG College of Technology',
        'duration': '4 years',
    },
]

COLLEGE_LIBRARY = [
    {
        'id': 1,
        'name': 'Anna University',
        'city': 'Chennai',
        'cutoff': 190,
        'category': 'Technology',
    },
    {
        'id': 2,
        'name': 'Madras Christian College',
        'city': 'Chennai',
        'cutoff': 180,
        'category': 'Finance',
    },
    {
        'id': 3,
        'name': 'PSG College of Technology',
        'city': 'Coimbatore',
        'cutoff': 185,
        'category': 'Engineering',
    },
]


def compute_interest_scores(responses: list[InterestResponse]) -> dict[str, int]:
    """Compute interest category scores from student responses."""
    category_counts: dict[str, int] = {}
    for response in responses:
        category_counts[response.category] = category_counts.get(response.category, 0) + 1
    total = len(responses) or 1
    return {category: round((count / total) * 100) for category, count in category_counts.items()}


def calculate_career_fit(
    career: dict,
    interest_scores: dict[str, int],
    aptitude_scores: dict[str, float],
    overall_score: float,
    academic_eligibility: float,
    stream_category: str | None,
) -> float:
    """Calculate career fit score considering academic data."""
    return RecommendationService.calculate_career_fit(
        career=career,
        interest_scores=interest_scores,
        aptitude_scores=aptitude_scores,
        overall_score=overall_score,
        academic_eligibility=academic_eligibility,
        stream_category=stream_category,
    )


@router.get('', response_model=RecommendationResponse)
def get_recommendations(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    """
    Get personalized career, course, and college recommendations.
    
    Uses student's:
    - 10th and 12th marks
    - 12th stream
    - Aptitude assessment scores
    - Interest assessment scores
    - Location
    """
    # Get student profile
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')

    # Get aptitude results (required)
    aptitude_result = (
        db.query(AptitudeResult)
        .filter(AptitudeResult.student_profile_id == profile.id)
        .order_by(AptitudeResult.created_at.desc())
        .first()
    )
    if not aptitude_result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Aptitude results not found')

    # Get interest responses (required)
    interest_responses = (
        db.query(InterestResponse)
        .filter(InterestResponse.student_profile_id == profile.id)
        .all()
    )
    if not interest_responses:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Interest results not found')

    # Get education data (optional but helpful)
    education_12th = RecommendationService.get_12th_education(db, profile.id)
    education_10th = RecommendationService.get_10th_education(db, profile.id)

    # Compute scores
    interest_scores = compute_interest_scores(interest_responses)
    aptitude_scores = RecommendationService.get_aptitude_scores(aptitude_result)
    
    # Academic eligibility from 12th marks
    academic_eligibility, eligible_streams = RecommendationService.calculate_academic_eligibility(
        education_12th
    )
    
    # Get stream category for career matching
    stream_category = (
        RecommendationService.stream_to_category(education_12th.stream) if education_12th else None
    )

    career_records = db.query(Career).order_by(Career.name.asc()).all()

    # Generate career recommendations from the administrator-managed catalog.
    careers = []
    for career_record in career_records:
        career = {
            'id': career_record.id,
            'name': career_record.name,
            'category': career_record.category,
            'description': career_record.description,
            'course': career_record.course,
            'college': career_record.college,
            'aptitude_match_categories': career_record.aptitude_match_categories or [],
            'base_score': career_record.base_score,
            'suitable_streams': career_record.suitable_streams or [],
            'min_percentage': career_record.min_percentage,
        }
        # Find matched interest category
        matched_interest_category = (
            career['category'] if career['category'] in interest_scores else None
        )

        # Find best matched aptitude category
        matched_aptitude_category = None
        best_aptitude_value = -1.0
        for category in career['aptitude_match_categories']:
            value = aptitude_scores.get(category, 0.0)
            if value > best_aptitude_value:
                best_aptitude_value = value
                matched_aptitude_category = category

        # Generate explanation
        explanation = RecommendationService.generate_explanation(
            career=career,
            matched_interest_category=matched_interest_category,
            matched_aptitude_category=matched_aptitude_category,
            interest_scores=interest_scores,
            aptitude_scores=aptitude_scores,
            academic_eligibility=academic_eligibility,
            stream_category=stream_category,
        )

        # Calculate fit score
        fit_score = calculate_career_fit(
            career=career,
            interest_scores=interest_scores,
            aptitude_scores=aptitude_scores,
            overall_score=aptitude_result.overall_score,
            academic_eligibility=academic_eligibility,
            stream_category=stream_category,
        )

        careers.append({
            'id': career['id'],
            'name': career['name'],
            'category': career['category'],
            'description': career['description'],
            'course': career['course'],
            'college': career['college'],
            'overall_score': fit_score,
            'matched_interest_category': matched_interest_category,
            'matched_aptitude_category': matched_aptitude_category,
            'explanation': explanation,
            'academic_suitability': academic_eligibility,
            'required_stream': career.get('suitable_streams', [None])[0],
        })

    # Sort by overall score (descending)
    sorted_careers = sorted(careers, key=lambda item: item['overall_score'], reverse=True)

    # Derive courses from the same database career catalog.
    courses = []
    seen_courses = set()
    colleges_by_name = {
        college.name.lower(): college
        for college in db.query(College).all()
    }
    for career in career_records:
        if career.course in seen_courses:
            continue
        seen_courses.add(career.course)
        course_data = {
            'id': career.id,
            'name': career.course,
            'category': career.category,
            'college': career.college,
            'college_id': getattr(colleges_by_name.get(career.college.lower()), 'id', None),
            'duration': 'Check institution details',
            'eligibility_required': '75% in 12th' if education_12th else 'Check eligibility',
            'career_opportunities': [
                c['name'] for c in sorted_careers[:3]
            ] if sorted_careers else None,
        }
        courses.append(course_data)

    # Prepare colleges with eligibility filtering
    colleges_with_eligibility = []
    for college in db.query(College).order_by(College.name.asc()).all():
        college_data = {
            'id': college.id,
            'name': college.name,
            'city': college.city,
            'cutoff': college.cutoff,
            'category': college.category,
        }

        # Check eligibility if student has 12th marks
        if education_12th and education_12th.percentage:
            is_eligible, match_pct = RecommendationService.get_college_eligibility(
                education_12th.percentage, college.cutoff
            )
            college_data['eligibility'] = is_eligible
            college_data['match_percentage'] = round(match_pct, 1)
        else:
            college_data['eligibility'] = None
            college_data['match_percentage'] = None

        # Location match
        if profile.district:
            college_data['location_match'] = college.city.lower() == profile.district.lower()

        colleges_with_eligibility.append(college_data)

    # Sort colleges: eligible first, then by match percentage
    if education_12th and education_12th.percentage:
        colleges_with_eligibility.sort(
            key=lambda x: (x.get('eligibility', False), x.get('match_percentage', 0)),
            reverse=True,
        )

    return RecommendationResponse(
        careers=sorted_careers,
        courses=courses,
        colleges=colleges_with_eligibility,
        student_data={
            'has_12th_education': education_12th is not None,
            'has_10th_education': education_10th is not None,
            '12th_percentage': education_12th.percentage if education_12th else None,
            '12th_stream': stream_category,
            'aptitude_overall': aptitude_result.overall_score,
            'interest_categories': list(interest_scores.keys()),
        } if education_12th else None,
    )


@router.get('/export-pdf')
def export_recommendations_pdf(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    """Export the authenticated student's recommendation report."""
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')

    recommendations = get_recommendations(current_user=current_user, db=db)
    education_records = db.query(EducationRecord).filter(
        EducationRecord.student_profile_id == profile.id
    ).order_by(EducationRecord.level.asc()).all()
    aptitude_result = db.query(AptitudeResult).filter(
        AptitudeResult.student_profile_id == profile.id
    ).order_by(AptitudeResult.created_at.desc()).first()
    interest_responses = db.query(InterestResponse).filter(
        InterestResponse.student_profile_id == profile.id
    ).all()
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas

    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=letter, pageCompression=0)
    pdf.setTitle('Career Recommendation Report')
    pdf.setFont('Helvetica-Bold', 18)
    pdf.drawString(72, 760, f'Recommendation Report for {profile.full_name}')
    pdf.setFont('Helvetica', 11)

    y = 725
    pdf.drawString(72, y, f'Report date: {datetime.utcnow().strftime("%Y-%m-%d")}')
    y -= 18
    pdf.drawString(72, y, f'Location: {profile.district or "Not provided"}, {profile.state or "Not provided"}')
    y -= 24
    pdf.drawString(72, y, 'Education:')
    y -= 18
    for record in education_records:
        pdf.drawString(90, y, f'{record.level}: {record.board or "Board not specified"}, {record.percentage or 0}% ({record.stream or "General"})')
        y -= 18
    if aptitude_result:
        pdf.drawString(72, y, f'Aptitude overall score: {aptitude_result.overall_score}%')
        y -= 18
    pdf.drawString(72, y, f'Interest responses recorded: {len(interest_responses)}')
    y -= 24
    pdf.drawString(72, y, 'Top Careers:')
    y -= 18
    for career in recommendations.careers[:5]:
        pdf.drawString(72, y, f'- {career.name} ({career.overall_score}% fit)')
        y -= 18

    y -= 10
    pdf.drawString(72, y, 'Suggested Courses:')
    y -= 18
    for course in recommendations.courses[:5]:
        pdf.drawString(72, y, f'- {course.name} ({course.college})')
        y -= 18

    y -= 10
    pdf.drawString(72, y, 'Recommended Colleges:')
    y -= 18
    for college in recommendations.colleges[:5]:
        pdf.drawString(72, y, f'- {college.name} ({college.city}, cutoff {college.cutoff})')
        y -= 18

    pdf.showPage()
    pdf.save()
    buffer.seek(0)

    return StreamingResponse(
        buffer,
        media_type='application/pdf',
        headers={'Content-Disposition': 'attachment; filename=recommendations-report.pdf'},
    )
