from .auth import router as auth
from .health import router as health
from .students import router as students
from .education import router as education
from .aptitude import router as aptitude
from .interest import router as interest
from .recommendations import router as recommendations
from .admin import router as admin
from . import careers
from . import colleges
