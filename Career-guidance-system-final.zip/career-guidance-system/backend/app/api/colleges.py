from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_admin_user, get_db
from app.db.models.college import College
from app.schemas.career import CollegeCreate, CollegeUpdate, CollegeResponse

router = APIRouter(prefix='/colleges', tags=['colleges'])


@router.get('', response_model=list[CollegeResponse])
def list_colleges(
    search: str | None = None,
    category: str | None = None,
    state: str | None = None,
    city: str | None = None,
    min_cutoff: float | None = None,
    db: Session = Depends(get_db),
):
    """List all colleges with optional search and filtering."""
    query = db.query(College)
    if search:
        search_term = search.lower()
        query = query.filter(
            (College.name.ilike(f'%{search_term}%')) |
            (College.category.ilike(f'%{search_term}%')) |
            (College.city.ilike(f'%{search_term}%')) |
            (College.state.ilike(f'%{search_term}%'))
        )
    if category:
        query = query.filter(College.category.ilike(f'%{category}%'))
    if state:
        query = query.filter(College.state.ilike(f'%{state}%'))
    if city:
        query = query.filter(College.city.ilike(f'%{city}%'))
    if min_cutoff is not None:
        query = query.filter(College.cutoff >= min_cutoff)
    colleges = query.order_by(College.name.asc()).all()
    return colleges


@router.get('/{college_id}', response_model=CollegeResponse)
def get_college(college_id: int, db: Session = Depends(get_db)):
    """Get a specific college by ID"""
    college = db.query(College).filter(College.id == college_id).first()
    if not college:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='College not found')
    return college


@router.post('', response_model=CollegeResponse)
def create_college(payload: CollegeCreate, current_user=Depends(get_admin_user), db: Session = Depends(get_db)):
    """Create a new college (admin only)"""
    # Check if college with same name already exists
    existing = db.query(College).filter(College.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='College with this name already exists')
    
    college = College(**payload.model_dump())
    db.add(college)
    db.commit()
    db.refresh(college)
    return college


@router.put('/{college_id}', response_model=CollegeResponse)
def update_college(college_id: int, payload: CollegeUpdate, current_user=Depends(get_admin_user), db: Session = Depends(get_db)):
    """Update a college (admin only)"""
    college = db.query(College).filter(College.id == college_id).first()
    if not college:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='College not found')
    
    update_data = payload.model_dump(exclude_unset=True)
    
    # Check if new name conflicts with another college
    if 'name' in update_data and update_data['name'] != college.name:
        existing = db.query(College).filter(College.name == update_data['name']).first()
        if existing:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='College with this name already exists')
    
    for field, value in update_data.items():
        setattr(college, field, value)
    
    db.add(college)
    db.commit()
    db.refresh(college)
    return college


@router.delete('/{college_id}', status_code=status.HTTP_204_NO_CONTENT)
def delete_college(college_id: int, current_user=Depends(get_admin_user), db: Session = Depends(get_db)):
    """Delete a college (admin only)"""
    college = db.query(College).filter(College.id == college_id).first()
    if not college:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='College not found')
    
    db.delete(college)
    db.commit()
    return None
