from fastapi import APIRouter

router = APIRouter()

@router.get('/', summary='Health check')
def health_check():
    return {'status': 'ok', 'message': 'Smart Career Guidance API is running'}
