from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, get_db
from app.db.models.education_record import EducationRecord
from app.db.models.student_profile import StudentProfile
from app.schemas.education import EducationRecordCreate, EducationRecordResponse, EducationRecordUpdate

router = APIRouter(prefix='/education', tags=['education'])


@router.post('/me', response_model=EducationRecordResponse)
def add_education_record(payload: EducationRecordCreate, current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')

    record = EducationRecord(student_profile_id=profile.id, **payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get('/me', response_model=list[EducationRecordResponse])
def get_my_education_records(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')
    return db.query(EducationRecord).filter(EducationRecord.student_profile_id == profile.id).all()


@router.get('/{record_id}', response_model=EducationRecordResponse)
def get_education_record(record_id: int, current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')
    
    record = db.query(EducationRecord).filter(
        EducationRecord.id == record_id,
        EducationRecord.student_profile_id == profile.id
    ).first()
    
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Education record not found')
    
    return record


@router.put('/{record_id}', response_model=EducationRecordResponse)
def update_education_record(record_id: int, payload: EducationRecordUpdate, current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')
    
    record = db.query(EducationRecord).filter(
        EducationRecord.id == record_id,
        EducationRecord.student_profile_id == profile.id
    ).first()
    
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Education record not found')
    
    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(record, field, value)
    
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.delete('/{record_id}', status_code=status.HTTP_204_NO_CONTENT)
def delete_education_record(record_id: int, current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')
    
    record = db.query(EducationRecord).filter(
        EducationRecord.id == record_id,
        EducationRecord.student_profile_id == profile.id
    ).first()
    
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Education record not found')
    
    db.delete(record)
    db.commit()
    return None
