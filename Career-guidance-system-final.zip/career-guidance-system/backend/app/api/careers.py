from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core.dependencies import get_admin_user, get_db
from app.db.models.career import Career
from app.schemas.career import CareerCreate, CareerUpdate, CareerResponse

router = APIRouter(prefix='/careers', tags=['careers'])

CATEGORY_ALIASES = {
    'computer science & it': ['Technology'],
    'medical & healthcare': ['Healthcare'],
    'commerce': ['Finance', 'Business'],
    'management': ['Management', 'Business'],
}


@router.get('', response_model=list[CareerResponse])
def list_careers(
    search: str | None = None,
    category: str | None = None,
    min_percentage: float | None = None,
    db: Session = Depends(get_db),
):
    """List all careers with optional search and filtering."""
    query = db.query(Career)
    if search:
        search_term = search.lower()
        query = query.filter(
            (Career.name.ilike(f'%{search_term}%')) |
            (Career.category.ilike(f'%{search_term}%')) |
            (Career.description.ilike(f'%{search_term}%'))
        )
    if category:
        category_values = CATEGORY_ALIASES.get(category.strip().lower(), [category])
        query = query.filter(or_(*[
            Career.category.ilike(f'%{category_value}%')
            for category_value in category_values
        ]))
    if min_percentage is not None:
        query = query.filter(Career.min_percentage >= min_percentage)
    careers = query.order_by(Career.name.asc()).all()
    return careers


@router.get('/{career_id}', response_model=CareerResponse)
def get_career(career_id: int, db: Session = Depends(get_db)):
    """Get a specific career by ID"""
    career = db.query(Career).filter(Career.id == career_id).first()
    if not career:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Career not found')
    return career


@router.post('', response_model=CareerResponse)
def create_career(payload: CareerCreate, current_user=Depends(get_admin_user), db: Session = Depends(get_db)):
    """Create a new career (admin only)"""
    # Check if career with same name already exists
    existing = db.query(Career).filter(Career.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Career with this name already exists')
    
    career = Career(**payload.model_dump())
    db.add(career)
    db.commit()
    db.refresh(career)
    return career


@router.put('/{career_id}', response_model=CareerResponse)
def update_career(career_id: int, payload: CareerUpdate, current_user=Depends(get_admin_user), db: Session = Depends(get_db)):
    """Update a career (admin only)"""
    career = db.query(Career).filter(Career.id == career_id).first()
    if not career:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Career not found')
    
    update_data = payload.model_dump(exclude_unset=True)
    
    # Check if new name conflicts with another career
    if 'name' in update_data and update_data['name'] != career.name:
        existing = db.query(Career).filter(Career.name == update_data['name']).first()
        if existing:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Career with this name already exists')
    
    for field, value in update_data.items():
        setattr(career, field, value)
    
    db.add(career)
    db.commit()
    db.refresh(career)
    return career


@router.delete('/{career_id}', status_code=status.HTTP_204_NO_CONTENT)
def delete_career(career_id: int, current_user=Depends(get_admin_user), db: Session = Depends(get_db)):
    """Delete a career (admin only)"""
    career = db.query(Career).filter(Career.id == career_id).first()
    if not career:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Career not found')
    
    db.delete(career)
    db.commit()
    return None
