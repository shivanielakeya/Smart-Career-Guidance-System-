from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.orm import Session
from app.schemas.auth import RegisterRequest, LoginRequest, TokenResponse
from app.services.auth_service import hash_password, verify_password, create_token_for_user
from app.core.dependencies import get_db
from app.db.models.user import User
from app.core.config import get_settings

router = APIRouter()


@router.post('/register', response_model=TokenResponse)
def register_user(payload: RegisterRequest, db: Session = Depends(get_db)):
    email = str(payload.email).lower()
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Email already registered')

    role = (payload.role or 'student').lower()
    if role != 'student':
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Admin accounts must be provisioned securely')
    user = User(email=email, password_hash=hash_password(payload.password), role=role)
    db.add(user)
    db.commit()
    db.refresh(user)

    access_token = create_token_for_user(user.email, user.role)
    return {
        'email': user.email,
        'role': user.role,
        'access_token': access_token,
        'token_type': 'bearer'
    }


@router.post('/admin/register', response_model=TokenResponse)
def register_admin_user(
    payload: RegisterRequest,
    setup_key: str | None = Header(default=None, alias='X-Admin-Setup-Key'),
    db: Session = Depends(get_db),
):
    settings = get_settings()
    if not settings.admin_setup_key or setup_key != settings.admin_setup_key:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Valid admin setup key required')
    email = str(payload.email).lower()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Email already registered')
    user = User(email=email, password_hash=hash_password(payload.password), role='admin')
    db.add(user)
    db.commit()
    db.refresh(user)
    return {
        'email': user.email,
        'role': user.role,
        'access_token': create_token_for_user(user.email, user.role),
        'token_type': 'bearer',
    }


@router.post('/login', response_model=TokenResponse)
def login_user(payload: LoginRequest, db: Session = Depends(get_db)):
    email = str(payload.email).lower()
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid credentials')

    access_token = create_token_for_user(user.email, user.role)
    return {
        'email': user.email,
        'role': user.role,
        'access_token': access_token,
        'token_type': 'bearer'
    }

