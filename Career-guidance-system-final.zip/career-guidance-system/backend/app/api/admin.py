from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.dependencies import get_admin_user, get_db
from app.db.models.career import Career
from app.db.models.college import College
from app.db.models.student_profile import StudentProfile
from app.db.models.user import User
from app.db.models.education_record import EducationRecord
from app.db.models.aptitude_result import AptitudeResult
from app.db.models.interest_response import InterestResponse
from app.db.models.aptitude_response import AptitudeResponse
from app.services.recommendation_service import RecommendationService

router = APIRouter()


@router.get('/dashboard')
def get_admin_dashboard(current_user: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    student_count = db.query(User).filter(User.role == 'student').count()
    admin_count = db.query(User).filter(User.role == 'admin').count()
    career_count = db.query(Career).count()
    college_count = db.query(College).count()
    avg_aptitude = db.query(func.avg(AptitudeResult.overall_score)).scalar() or 0
    profiles = db.query(StudentProfile).all()

    recent_activity = []
    for user in db.query(User).order_by(User.created_at.desc()).limit(5).all():
        profile = db.query(StudentProfile).filter(StudentProfile.user_id == user.id).first()
        recent_activity.append({
            'user_email': user.email,
            'role': user.role,
            'name': profile.full_name if profile else 'New user',
            'created_at': user.created_at.isoformat() if user.created_at else datetime.utcnow().isoformat(),
        })

    return {
        'stats': {
            'students': student_count,
            'admins': admin_count,
            'careers': career_count,
            'colleges': college_count,
            'avg_aptitude_score': round(float(avg_aptitude), 1),
            'profiles': len(profiles),
        },
        'recent_activity': recent_activity,
        'generated_at': datetime.utcnow().isoformat(),
    }


@router.get('/students')
def list_students(current_user: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    rows = []
    for user in db.query(User).filter(User.role == 'student').order_by(User.created_at.desc()).all():
        profile = db.query(StudentProfile).filter(StudentProfile.user_id == user.id).first()
        education = db.query(EducationRecord).filter(EducationRecord.student_profile_id == profile.id).all() if profile else []
        aptitude = db.query(AptitudeResult).filter(AptitudeResult.student_profile_id == profile.id).order_by(AptitudeResult.created_at.desc()).first() if profile else None
        interest_response_count = db.query(InterestResponse).filter(InterestResponse.student_profile_id == profile.id).count() if profile else 0
        rows.append({
            'id': user.id,
            'email': user.email,
            'role': user.role,
            'full_name': profile.full_name if profile else None,
            'district': profile.district if profile else None,
            'school': profile.school if profile else None,
            'education_count': len(education),
            'aptitude_score': aptitude.overall_score if aptitude else None,
            'interest_response_count': interest_response_count,
            'created_at': user.created_at.isoformat() if user.created_at else None,
        })
    return rows


@router.post('/notifications/email')
def send_email_notification(payload: dict, current_user: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    recipient_email = str(payload.get('recipient_email') or '').strip()
    subject = str(payload.get('subject') or 'Career Guidance Update').strip()
    message = str(payload.get('message') or '').strip()
    if not recipient_email:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='recipient_email is required')
    if not message:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='message is required')

    user = db.query(User).filter(User.email == recipient_email).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Recipient user not found')

    notification = {
        'recipient_email': recipient_email,
        'subject': subject,
        'message': message,
        'sent_by': current_user.email,
        'sent_at': datetime.utcnow().isoformat(),
        'status': 'queued',
    }
    return {'status': 'queued', 'notification': notification}


@router.get('/stats')
def get_admin_stats(current_user: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    return get_admin_dashboard(current_user=current_user, db=db)


@router.get('/activity-logs')
def get_activity_logs(current_user: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    logs = []
    for user in db.query(User).order_by(User.created_at.desc()).all():
        logs.append({
            'email': user.email,
            'role': user.role,
            'created_at': user.created_at.isoformat() if user.created_at else None,
            'event': 'user_registered' if user.role else 'user_activity',
        })
    return logs


@router.get('/recommendations/export-pdf')
def export_admin_report(current_user: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas

    buf = __import__('io').BytesIO()
    pdf = canvas.Canvas(buf, pagesize=letter)
    pdf.setTitle('Admin Report')
    pdf.setFont('Helvetica-Bold', 18)
    pdf.drawString(72, 750, 'Career Guidance System - Admin Summary')
    pdf.setFont('Helvetica', 11)
    page_data = get_admin_dashboard(current_user=current_user, db=db)
    line = 720
    for key, value in page_data['stats'].items():
        pdf.drawString(72, line, f'{key}: {value}')
        line -= 18
    pdf.showPage()
    pdf.save()
    buf.seek(0)
    return StreamingResponse(buf, media_type='application/pdf', headers={'Content-Disposition': 'attachment; filename=admin-summary.pdf'})
