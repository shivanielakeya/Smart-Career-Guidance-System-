from collections import Counter, defaultdict
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.dependencies import get_admin_user, get_current_user, get_db
from app.db.models.analytics_event import AnalyticsEvent
from app.db.models.aptitude_result import AptitudeResult
from app.db.models.college import College
from app.db.models.education_record import EducationRecord
from app.db.models.interest_response import InterestResponse
from app.db.models.student_profile import StudentProfile
from app.db.models.user import User
from app.db.models.career import Career
from app.schemas.analytics import AnalyticsEventCreate
from app.services.recommendation_service import RecommendationService

router = APIRouter()


def _bucket(score: float) -> str:
    if score < 40:
        return '0-39'
    if score < 60:
        return '40-59'
    if score < 75:
        return '60-74'
    if score < 90:
        return '75-89'
    return '90-100'


@router.get('')
def get_analytics(current_user: User = Depends(get_admin_user), db: Session = Depends(get_db)):
    student_ids = [row[0] for row in db.query(User.id).filter(User.role == 'student').all()]
    profiles = db.query(StudentProfile).filter(StudentProfile.user_id.in_(student_ids)).all() if student_ids else []
    profile_ids = [profile.id for profile in profiles]
    total_students = len(student_ids)

    aptitude_results = {}
    for result in db.query(AptitudeResult).filter(AptitudeResult.student_profile_id.in_(profile_ids)).order_by(AptitudeResult.created_at.desc()).all() if profile_ids else []:
        aptitude_results.setdefault(result.student_profile_id, result)
    interest_rows = db.query(InterestResponse).filter(InterestResponse.student_profile_id.in_(profile_ids)).all() if profile_ids else []
    interest_by_profile = defaultdict(list)
    for row in interest_rows:
        interest_by_profile[row.student_profile_id].append(row)

    education_rows = db.query(EducationRecord).filter(EducationRecord.student_profile_id.in_(profile_ids)).all() if profile_ids else []
    education_12th = {row.student_profile_id: row for row in education_rows if row.level == '12th'}
    completed_aptitude = len(aptitude_results)
    completed_interest = len(interest_by_profile)
    completed_both = len(set(aptitude_results) & set(interest_by_profile))

    aptitude_distribution = Counter(_bucket(float(result.overall_score or 0)) for result in aptitude_results.values())
    interest_distribution = Counter(row.category for row in interest_rows)
    stream_distribution = Counter((row.stream or 'Not specified') for row in education_12th.values())

    careers = db.query(Career).all()
    recommended_careers = Counter()
    profile_map = {profile.id: profile for profile in profiles}
    for profile_id, result in aptitude_results.items():
        interest_scores = Counter(row.category for row in interest_by_profile.get(profile_id, []))
        total_interests = sum(interest_scores.values()) or 1
        interest_scores = {key: round(value / total_interests * 100) for key, value in interest_scores.items()}
        aptitude_scores = RecommendationService.get_aptitude_scores(result)
        education = education_12th.get(profile_id)
        academic_score, _ = RecommendationService.calculate_academic_eligibility(education)
        stream = RecommendationService.stream_to_category(education.stream) if education else None
        scored = []
        for career in careers:
            score = RecommendationService.calculate_career_fit(
                career={'category': career.category, 'base_score': career.base_score, 'aptitude_match_categories': career.aptitude_match_categories or [], 'suitable_streams': career.suitable_streams or []},
                interest_scores=interest_scores,
                aptitude_scores=aptitude_scores,
                overall_score=result.overall_score or 0,
                academic_eligibility=academic_score,
                stream_category=stream,
            )
            scored.append((score, career.name))
        for _, career_name in sorted(scored, reverse=True)[:3]:
            recommended_careers[career_name] += 1

    trend_map = defaultdict(lambda: {'date': '', 'aptitude': 0, 'interest': 0})
    for result in aptitude_results.values():
        date = result.created_at.date().isoformat() if result.created_at else 'unknown'
        trend_map[date].update({'date': date, 'aptitude': trend_map[date]['aptitude'] + 1})
    seen_interest = set()
    for row in interest_rows:
        date = row.created_at.date().isoformat() if row.created_at else 'unknown'
        key = (row.student_profile_id, date)
        if key not in seen_interest:
            seen_interest.add(key)
            trend_map[date].update({'date': date, 'interest': trend_map[date]['interest'] + 1})

    def event_counts(event_type: str):
        rows = db.query(AnalyticsEvent.entity_name, AnalyticsEvent.entity_id).filter(AnalyticsEvent.event_type == event_type).all()
        counts = Counter((name or f'College {entity_id}') for name, entity_id in rows)
        return [{'name': name, 'count': count} for name, count in counts.most_common(10)]

    return {
        'summary': {
            'total_students': total_students,
            'profile_completion': len(profiles),
            'aptitude_completion': completed_aptitude,
            'interest_completion': completed_interest,
            'both_assessments_completion': completed_both,
            'aptitude_completion_rate': round(completed_aptitude / total_students * 100, 1) if total_students else 0,
            'interest_completion_rate': round(completed_interest / total_students * 100, 1) if total_students else 0,
        },
        'aptitude_score_distribution': [{'range': key, 'count': aptitude_distribution.get(key, 0)} for key in ['0-39', '40-59', '60-74', '75-89', '90-100']],
        'interest_category_distribution': [{'category': key, 'count': value} for key, value in interest_distribution.most_common()],
        'most_recommended_careers': [{'name': key, 'count': value} for key, value in recommended_careers.most_common(10)],
        'career_recommendation_distribution': [{'name': key, 'count': value} for key, value in recommended_careers.items()],
        'college_views': event_counts('college_view'),
        'college_selections': event_counts('college_selection'),
        'student_stream_distribution': [{'stream': key, 'count': value} for key, value in stream_distribution.most_common()],
        'assessment_completion_trends': [trend_map[key] for key in sorted(trend_map)],
    }


@router.get('/powerbi-config')
def get_powerbi_config(current_user: User = Depends(get_admin_user)):
    settings = get_settings()
    return {
        'configured': bool(settings.powerbi_embed_url),
        'embed_url': settings.powerbi_embed_url,
        'report_id': settings.powerbi_report_id,
        'embed_token': settings.powerbi_embed_token,
    }


@router.post('/events', status_code=status.HTTP_201_CREATED)
def record_event(payload: AnalyticsEventCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if payload.entity_id is not None:
        college = db.query(College).filter(College.id == payload.entity_id).first()
        if not college:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='College not found')
        entity_name = college.name
    else:
        entity_name = payload.entity_name
    event = AnalyticsEvent(user_id=current_user.id, event_type=payload.event_type, entity_type='college', entity_id=payload.entity_id, entity_name=entity_name)
    db.add(event)
    db.commit()
    return {'status': 'recorded'}