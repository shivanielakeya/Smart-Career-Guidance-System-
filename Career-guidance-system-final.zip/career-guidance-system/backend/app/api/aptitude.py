from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_current_user, get_db
from app.db.models.aptitude_question import AptitudeQuestion
from app.db.models.aptitude_response import AptitudeResponse
from app.db.models.aptitude_result import AptitudeResult
from app.schemas.aptitude import AptitudeQuestionResponse, AptitudeSubmission, AptitudeResultResponse, CategoryScore
from app.db.models.student_profile import StudentProfile

router = APIRouter()

@router.get('/questions', response_model=list[AptitudeQuestionResponse])
def get_aptitude_questions(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    questions = db.query(AptitudeQuestion).all()
    return questions


@router.post('/submit', response_model=AptitudeResultResponse)
def submit_aptitude_answers(payload: AptitudeSubmission, current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')

    db.query(AptitudeResponse).filter(AptitudeResponse.student_profile_id == profile.id).delete()
    db.query(AptitudeResult).filter(AptitudeResult.student_profile_id == profile.id).delete()
    db.commit()

    answers = {item.question_id: item.answer for item in payload.answers}

    questions = db.query(AptitudeQuestion).all()
    score_map = {
        'Quantitative Ability': 0,
        'Logical Reasoning': 0,
        'Analytical Reasoning': 0,
        'Verbal Ability': 0,
        'Data Interpretation': 0,
    }
    counts = {category: 0 for category in score_map}
    total_correct = 0

    for question in questions:
        selected = answers.get(question.id)
        is_correct = selected == question.correct_answer
        if selected is not None:
            db.add(AptitudeResponse(
                student_profile_id=profile.id,
                question_id=question.id,
                selected_option=selected,
                is_correct=is_correct,
            ))
        counts[question.category] += 1
        if is_correct:
            score_map[question.category] += 1
            total_correct += 1

    db.commit()

    category_scores = []
    for category, correct_count in score_map.items():
        total = counts.get(category, 1)
        score = round((correct_count / total) * 100, 1) if total > 0 else 0.0
        category_scores.append(CategoryScore(category=category, score=score))

    if len(questions) > 0:
        overall_score = round((total_correct / len(questions)) * 100, 1)
    else:
        overall_score = 0.0

    result = AptitudeResult(
        student_profile_id=profile.id,
        overall_score=overall_score,
        quantitative_score=next((item.score for item in category_scores if item.category == 'Quantitative Ability'), 0.0),
        logical_score=next((item.score for item in category_scores if item.category == 'Logical Reasoning'), 0.0),
        analytical_score=next((item.score for item in category_scores if item.category == 'Analytical Reasoning'), 0.0),
        verbal_score=next((item.score for item in category_scores if item.category == 'Verbal Ability'), 0.0),
        data_interpretation_score=next((item.score for item in category_scores if item.category == 'Data Interpretation'), 0.0),
    )
    db.add(result)
    db.commit()
    db.refresh(result)

    return AptitudeResultResponse(
        overall_score=result.overall_score,
        category_scores=category_scores,
    )


@router.get('/result', response_model=AptitudeResultResponse)
def get_aptitude_result(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Student profile not found')

    result = db.query(AptitudeResult).filter(AptitudeResult.student_profile_id == profile.id).order_by(AptitudeResult.created_at.desc()).first()
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='No aptitude result found')

    return AptitudeResultResponse(
        overall_score=result.overall_score,
        category_scores=[
            CategoryScore(category='Quantitative Ability', score=result.quantitative_score),
            CategoryScore(category='Logical Reasoning', score=result.logical_score),
            CategoryScore(category='Analytical Reasoning', score=result.analytical_score),
            CategoryScore(category='Verbal Ability', score=result.verbal_score),
            CategoryScore(category='Data Interpretation', score=result.data_interpretation_score),
        ],
    )
