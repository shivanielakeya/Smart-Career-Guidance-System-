"""
Recommendation Service - Phase 3
Provides career, course, and college recommendations based on student profile data.
"""

from typing import Dict, List, Optional, Tuple
from sqlalchemy.orm import Session
from app.db.models.student_profile import StudentProfile
from app.db.models.education_record import EducationRecord
from app.db.models.aptitude_result import AptitudeResult
from app.db.models.interest_response import InterestResponse


class RecommendationService:
    """Service for generating personalized recommendations."""

    @staticmethod
    def get_12th_education(db: Session, student_profile_id: int) -> Optional[EducationRecord]:
        """Get 12th standard education record."""
        return (
            db.query(EducationRecord)
            .filter(
                EducationRecord.student_profile_id == student_profile_id,
                EducationRecord.level == '12th',
            )
            .first()
        )

    @staticmethod
    def get_10th_education(db: Session, student_profile_id: int) -> Optional[EducationRecord]:
        """Get 10th standard education record."""
        return (
            db.query(EducationRecord)
            .filter(
                EducationRecord.student_profile_id == student_profile_id,
                EducationRecord.level == '10th',
            )
            .first()
        )

    @staticmethod
    def compute_interest_scores(
        db: Session, student_profile_id: int
    ) -> Dict[str, int]:
        """Compute interest category scores from student responses."""
        responses = (
            db.query(InterestResponse)
            .filter(InterestResponse.student_profile_id == student_profile_id)
            .all()
        )

        if not responses:
            return {}

        category_counts: Dict[str, int] = {}
        for response in responses:
            category_counts[response.category] = category_counts.get(response.category, 0) + 1

        total = len(responses) or 1
        return {
            category: round((count / total) * 100) for category, count in category_counts.items()
        }

    @staticmethod
    def get_aptitude_scores(aptitude_result: AptitudeResult) -> Dict[str, float]:
        """Extract aptitude scores by category."""
        return {
            'Quantitative Ability': aptitude_result.quantitative_score,
            'Logical Reasoning': aptitude_result.logical_score,
            'Analytical Reasoning': aptitude_result.analytical_score,
            'Verbal Ability': aptitude_result.verbal_score,
            'Data Interpretation': aptitude_result.data_interpretation_score,
        }

    @staticmethod
    def stream_to_category(stream: Optional[str]) -> Optional[str]:
        """Convert stream to category for career matching.
        
        Stream can be: PCM (Physics, Chemistry, Math), PCB (Physics, Chemistry, Biology),
        Commerce, Arts, etc.
        """
        if not stream:
            return None

        stream_upper = stream.upper().replace(' ', '')

        # Check for specific streams first
        if 'PCM' in stream_upper or ('MATHEMATICS' in stream_upper and 'PHYSICS' in stream_upper):
            return 'PCM'
        elif 'PCB' in stream_upper or ('BIOLOGY' in stream_upper and 'PHYSICS' in stream_upper):
            return 'PCB'
        elif 'COMMERCE' in stream_upper:
            return 'Commerce'
        elif 'ARTS' in stream_upper:
            return 'Arts'
        elif 'SCIENCE' in stream_upper:
            # Generic science if neither PCM nor PCB specified
            return 'Science'
        else:
            return None

    @staticmethod
    def calculate_academic_eligibility(education: Optional[EducationRecord]) -> Tuple[float, List[str]]:
        """
        Calculate academic eligibility and get suitable career categories.
        
        Returns: (eligibility_score, suitable_streams)
        """
        if not education:
            return 0.0, []

        eligible_streams = []
        eligibility_score = 0.0

        if education.percentage and education.percentage >= 90:
            eligibility_score = 95.0
            eligible_streams = ['PCM', 'PCB', 'Commerce', 'Arts']
        elif education.percentage and education.percentage >= 80:
            eligibility_score = 85.0
            eligible_streams = ['PCM', 'PCB', 'Commerce', 'Arts']
        elif education.percentage and education.percentage >= 70:
            eligibility_score = 75.0
            eligible_streams = ['PCM', 'Commerce', 'Arts']
        elif education.percentage and education.percentage >= 60:
            eligibility_score = 65.0
            eligible_streams = ['Commerce', 'Arts']
        else:
            eligibility_score = 50.0
            eligible_streams = ['Arts']

        # Check stream-specific eligibility
        stream_category = RecommendationService.stream_to_category(education.stream)
        if stream_category:
            # PCM students get engineering/science careers
            # PCB students get medical/biology careers
            # Commerce students get finance careers
            # Arts students get social/humanities careers
            pass

        return eligibility_score, eligible_streams

    @staticmethod
    def calculate_career_fit(
        career: Dict,
        interest_scores: Dict[str, int],
        aptitude_scores: Dict[str, float],
        overall_score: float,
        academic_eligibility: float,
        stream_category: Optional[str],
    ) -> float:
        """
        Calculate career fit score (0-100).
        
        Factors:
        - Base career score
        - Interest match (0-25)
        - Aptitude match (0-20)
        - Academic performance (0-25)
        - Stream suitability (0-15)
        - Overall aptitude (0-15)
        """
        score = career['base_score']

        # Interest match (up to 25 points)
        if career['category'] in interest_scores:
            score += min(interest_scores[career['category']], 25)

        # Aptitude match (up to 20 points)
        for category in career['aptitude_match_categories']:
            if category in aptitude_scores:
                score += min(aptitude_scores[category] / 5.0, 10)

        # Academic performance (up to 25 points)
        score += min(academic_eligibility / 4, 25)

        # Stream suitability (up to 15 points)
        if stream_category and stream_category in career.get('suitable_streams', []):
            score += 15
        elif stream_category:
            # Penalty if stream doesn't match
            score = max(0, score - 5)

        # Overall aptitude score (up to 15 points)
        if overall_score >= 85:
            score += 15
        elif overall_score >= 70:
            score += 10
        elif overall_score >= 55:
            score += 5

        return round(min(score, 100.0), 1)

    @staticmethod
    def generate_explanation(
        career: Dict,
        matched_interest_category: Optional[str],
        matched_aptitude_category: Optional[str],
        interest_scores: Dict[str, int],
        aptitude_scores: Dict[str, float],
        academic_eligibility: float,
        stream_category: Optional[str],
    ) -> str:
        """Generate human-readable explanation for career recommendation."""
        explanation_parts = []

        # Interest explanation
        if matched_interest_category:
            score = interest_scores.get(matched_interest_category, 0)
            explanation_parts.append(
                f"Your strong interest in {matched_interest_category} ({score}%) aligns well with this career."
            )

        # Aptitude explanation
        if matched_aptitude_category:
            score = aptitude_scores.get(matched_aptitude_category, 0)
            explanation_parts.append(
                f"Your excellent {matched_aptitude_category} ({score:.0f}%) is crucial for this role."
            )

        # Academic explanation
        if academic_eligibility >= 80:
            explanation_parts.append("Your strong academic performance opens doors to top institutions.")
        elif academic_eligibility >= 60:
            explanation_parts.append("Your academic background supports this career path.")

        # Stream explanation
        if stream_category:
            if stream_category in career.get('suitable_streams', []):
                explanation_parts.append(
                    f"Your {stream_category} stream is ideal for this field."
                )
            else:
                suitable = career.get('suitable_streams', [])
                if suitable:
                    explanation_parts.append(
                        f"While your current stream differs, the career remains viable given your strengths."
                    )

        if not explanation_parts:
            explanation_parts.append("Based on your overall performance, this is a suitable career option.")

        return " ".join(explanation_parts)

    @staticmethod
    def get_college_eligibility(student_marks: float, cutoff: float) -> Tuple[bool, float]:
        """
        Check if student is eligible for a college based on marks.
        
        Returns: (is_eligible, match_percentage)
        """
        if student_marks >= cutoff:
            match_percentage = min(100.0, (student_marks / cutoff) * 100)
            return True, match_percentage
        else:
            # Show potential (how close to cutoff)
            match_percentage = (student_marks / cutoff) * 100 if cutoff > 0 else 0
            return False, match_percentage

    @staticmethod
    def filter_colleges_for_student(
        colleges: List[Dict],
        student_marks: Optional[float],
        location: Optional[str],
        stream: Optional[str],
    ) -> List[Dict]:
        """
        Filter and rank colleges suitable for student.
        
        Factors:
        - Eligibility based on marks
        - Location preference
        - Stream compatibility
        """
        if not student_marks:
            return colleges

        filtered_colleges = []

        for college in colleges:
            is_eligible, match_pct = RecommendationService.get_college_eligibility(
                student_marks, college.get('cutoff', 0)
            )

            college_data = college.copy()
            college_data['eligibility'] = is_eligible
            college_data['match_percentage'] = match_pct

            # Location bonus (if available)
            if location and college.get('city', '').lower() == location.lower():
                college_data['location_match'] = True
            else:
                college_data['location_match'] = False

            filtered_colleges.append(college_data)

        # Sort: eligible first, then by match percentage
        filtered_colleges.sort(
            key=lambda x: (x['eligibility'], x['match_percentage']), reverse=True
        )

        return filtered_colleges
