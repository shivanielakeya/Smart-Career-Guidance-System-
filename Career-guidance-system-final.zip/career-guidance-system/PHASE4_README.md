# Career Guidance System - Phase 4 Complete

## Quick Start

### Prerequisites
- Python 3.8+
- Node.js 14+
- npm or yarn

### Backend Setup

```bash
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Initialize database
python -m app.db.seed

# Run backend server
uvicorn app.main:app --reload
```

Backend API will be available at: `http://localhost:8000`
Swagger docs: `http://localhost:8000/docs`

### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Run frontend development server
npm run dev
```

Frontend will be available at: `http://localhost:5173`

---

## What's New in Phase 4

### 1. Profile Editing ✅
- **Endpoint**: `PUT /api/students/me`
- **Description**: Update student profile with partial or full data
- **Authentication**: Required (JWT token)

### 2. Education Record Management ✅
- **Endpoints**:
  - `GET /api/education/{record_id}` - Get specific record
  - `PUT /api/education/{record_id}` - Update record
  - `DELETE /api/education/{record_id}` - Delete record
- **Description**: Full CRUD operations on education records
- **Validation**: Percentage (0-100), marks (non-negative), year (1990-2030)

### 3. Career Database ✅
- **Endpoints**:
  - `GET /api/careers` - List all careers
  - `GET /api/careers/{id}` - Get specific career
  - `POST /api/careers` - Create career
  - `PUT /api/careers/{id}` - Update career
  - `DELETE /api/careers/{id}` - Delete career
- **Description**: Manage careers via API instead of hardcoded data
- **8 careers pre-seeded**: Software Developer, Data Analyst, Civil Engineer, Graphic Designer, Medical Lab Tech, Business Analyst, Doctor, Chartered Accountant

### 4. College Database ✅
- **Endpoints**:
  - `GET /api/colleges` - List all colleges
  - `GET /api/colleges/{id}` - Get specific college
  - `POST /api/colleges` - Create college
  - `PUT /api/colleges/{id}` - Update college
  - `DELETE /api/colleges/{id}` - Delete college
- **Description**: Manage colleges via API instead of hardcoded data
- **8 colleges pre-seeded**: Anna University, Madras Christian College, PSG College of Technology, etc.

### 5. Comprehensive Test Suite ✅
- **Framework**: pytest
- **Coverage**: 60+ test cases
- **Test Areas**:
  - Authentication (register, login)
  - Profile management (create, update, retrieve)
  - Education records (CRUD)
  - Career management (CRUD)
  - College management (CRUD)
  - Validation and error handling

---

## API Endpoints - Complete Reference

### Authentication
```
POST   /api/auth/register    - Register new user
POST   /api/auth/login       - Login user
GET    /api/health           - Health check
```

### Student Profile
```
GET    /api/students/me      - Get profile
POST   /api/students/me      - Create profile
PUT    /api/students/me      - Update profile (NEW - Phase 4)
```

### Education Records
```
POST   /api/education/me     - Add education record
GET    /api/education/me     - Get all education records
GET    /api/education/{id}   - Get specific record (NEW - Phase 4)
PUT    /api/education/{id}   - Update record (NEW - Phase 4)
DELETE /api/education/{id}   - Delete record (NEW - Phase 4)
```

### Aptitude Assessment
```
GET    /api/aptitude/questions  - Get all questions
POST   /api/aptitude/submit      - Submit answers
GET    /api/aptitude/result      - Get results
```

### Interest Assessment
```
GET    /api/interest/questions  - Get all questions
POST   /api/interest/submit      - Submit answers
GET    /api/interest/result      - Get results
```

### Career Management (NEW - Phase 4)
```
GET    /api/careers            - List all careers
GET    /api/careers/{id}       - Get specific career
POST   /api/careers            - Create career
PUT    /api/careers/{id}       - Update career
DELETE /api/careers/{id}       - Delete career
```

### College Management (NEW - Phase 4)
```
GET    /api/colleges           - List all colleges
GET    /api/colleges/{id}      - Get specific college
POST   /api/colleges           - Create college
PUT    /api/colleges/{id}      - Update college
DELETE /api/colleges/{id}      - Delete college
```

### Recommendations
```
GET    /api/recommendations    - Get recommendations for current user
```

---

## Testing

### Run all tests
```bash
cd backend
python -m pytest tests/ -v
```

### Run specific test class
```bash
python -m pytest tests/test_phase4_features.py::TestEducationRecords -v
```

### Run with coverage report
```bash
python -m pytest tests/ --cov=app --cov-report=html
```

### Sample test output
```
tests/test_phase4_features.py::TestAuthentication::test_register_user PASSED
tests/test_phase4_features.py::TestAuthentication::test_login_user PASSED
tests/test_phase4_features.py::TestStudentProfile::test_create_profile PASSED
tests/test_phase4_features.py::TestEducationRecords::test_add_education_record PASSED
tests/test_phase4_features.py::TestEducationRecords::test_update_education_record PASSED
tests/test_phase4_features.py::TestEducationRecords::test_delete_education_record PASSED
tests/test_phase4_features.py::TestCareerDatabase::test_create_career PASSED
tests/test_phase4_features.py::TestCollegeDatabase::test_create_college PASSED
```

---

## Example Usage Workflow

### 1. Register and Create Profile
```bash
# Register
curl -X POST http://localhost:8000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "student@example.com",
    "password": "secure_password"
  }'

# Create profile
curl -X POST http://localhost:8000/api/students/me \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "full_name": "John Doe",
    "date_of_birth": "2005-03-15",
    "gender": "Male",
    "contact_number": "9876543210",
    "district": "Chennai"
  }'
```

### 2. Add and Update Education
```bash
# Add education record
curl -X POST http://localhost:8000/api/education/me \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "level": "12th",
    "board": "CBSE",
    "year": 2023,
    "total_marks": 500,
    "marks_obtained": 450,
    "percentage": 90.0,
    "stream": "PCM"
  }'

# Update education record
curl -X PUT http://localhost:8000/api/education/1 \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "percentage": 95.0
  }'
```

### 3. Manage Careers
```bash
# List all careers
curl http://localhost:8000/api/careers

# Get specific career
curl http://localhost:8000/api/careers/1

# Create new career (admin)
curl -X POST http://localhost:8000/api/careers \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Data Scientist",
    "category": "Technology",
    "description": "Analyze data and build ML models",
    "course": "B.Tech Data Science",
    "college": "IIT Bombay",
    "aptitude_match_categories": ["Data Interpretation"],
    "base_score": 75,
    "suitable_streams": ["PCM", "Science"],
    "min_percentage": 80
  }'
```

---

## Database Schema

### Models
- `User` - User account information
- `StudentProfile` - Student personal details (with updated_at)
- `EducationRecord` - Education history (with created_at, updated_at)
- `Career` - Career information (NEW - Phase 4)
- `College` - College information (NEW - Phase 4)
- `AptitudeQuestion`, `AptitudeResponse`, `AptitudeResult` - Aptitude assessment
- `InterestQuestion`, `InterestOption`, `InterestResponse` - Interest assessment

### Tables
```
users
student_profiles
education_records
careers                 (NEW - Phase 4)
colleges                (NEW - Phase 4)
aptitude_questions
aptitude_responses
aptitude_results
interest_questions
interest_options
interest_responses
```

---

## Configuration

### Environment Variables (.env)
```
DATABASE_URL=sqlite:///./career_guidance_dev.db
SECRET_KEY=your-secret-key-here
CORS_ORIGINS=["http://localhost:5173", "http://localhost:3000"]
```

### Backend Config (backend/app/core/config.py)
- Database URL
- CORS settings
- JWT configuration
- API versioning

---

## Backward Compatibility

Phase 4 maintains 100% backward compatibility:
- ✅ All Phase 1 frontend pages still work
- ✅ All Phase 2 & 3 APIs still work
- ✅ No breaking changes
- ✅ New features are additive

---

## Project Structure

```
career-guidance-system-combined/
├── frontend/
│   ├── src/
│   │   ├── pages/           (10 pages)
│   │   ├── services/        (9 services)
│   │   ├── components/      (Layout, AssessmentSteps)
│   │   ├── routes/          (AppRoutes, ProtectedRoute)
│   │   ├── context/         (AuthContext)
│   │   └── hooks/           (useAuth)
│   └── package.json
│
├── backend/
│   ├── app/
│   │   ├── api/             (8 modules + 2 new: careers, colleges)
│   │   ├── db/
│   │   │   ├── models/      (10 models + 2 new: Career, College)
│   │   │   └── seed.py      (with career & college data)
│   │   ├── schemas/         (6 schemas + 1 new: career.py)
│   │   ├── services/        (2 services)
│   │   ├── core/            (config, security, dependencies)
│   │   └── main.py          (updated with new routes)
│   ├── tests/               (NEW - Phase 4)
│   │   └── test_phase4_features.py (60+ tests)
│   ├── conftest.py          (NEW - Phase 4)
│   ├── pytest.ini           (NEW - Phase 4)
│   └── requirements.txt     (updated with pytest)
│
└── Documentation/
    ├── PHASE4_IMPLEMENTATION.md  (NEW - Phase 4)
    ├── PHASE4_README.md          (This file)
    ├── README.md                 (Original)
    └── [Other phase docs]
```

---

## Troubleshooting

### Database Issues
```bash
# Reset database (WARNING: deletes all data)
cd backend
rm career_guidance_dev.db
python -m app.db.seed
```

### Venv Issues
```bash
cd backend
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Port Already in Use
```bash
# Change backend port
uvicorn app.main:app --port 8001 --reload

# Change frontend port
npm run dev -- --port 5174
```

### Test Failures
```bash
# Make sure database is clean
rm -f backend/test.db

# Run tests with verbose output
cd backend
python -m pytest tests/test_phase4_features.py -v -s
```

---

## Phase 5 Features

Implemented enhancements:
- [x] Admin dashboard and role-based access control
- [x] Search and advanced filtering for careers and colleges
- [x] PDF export of student recommendations and admin summaries
- [x] Email notification queue endpoint
- [x] Phase 5 regression tests

Future enhancements:
- [ ] Assessment history comparison
- [ ] Career and college detail pages
- [ ] Comparison tools
- [ ] Performance optimization and caching

---

## Support & Documentation

- **API Documentation**: http://localhost:8000/docs (Swagger)
- **Phase 4 Details**: See `PHASE4_IMPLEMENTATION.md`
- **Test Guide**: Run `python -m pytest tests/ -v`
- **Database**: SQLite file at `backend/career_guidance_dev.db`

---

**Phase 4 Status**: ✅ COMPLETE  
**Phase 5 Status**: ✅ COMPLETE  
**Version**: 0.2.0  
**Date**: August 20, 2026

