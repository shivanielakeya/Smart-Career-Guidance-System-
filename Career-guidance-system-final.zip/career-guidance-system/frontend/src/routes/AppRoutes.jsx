import { Routes, Route } from 'react-router-dom';
import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import GetStarted from '../pages/GetStarted';
import PersonalDetails from '../pages/PersonalDetails';
import EducationDetails from '../pages/EducationDetails';
import AptitudeAssessment from '../pages/AptitudeAssessment';
import InterestAssessment from '../pages/InterestAssessment';
import AptitudeResult from '../pages/AptitudeResult';
import InterestResult from '../pages/InterestResult';
import ReviewAssessment from '../pages/ReviewAssessment';
import Dashboard from '../pages/Dashboard';
import AdminDashboard from '../pages/AdminDashboard';
import CareerCatalog from '../pages/CareerCatalog';
import CollegeDetails from '../pages/CollegeDetails';
import Colleges from '../pages/Colleges';
import ProtectedRoute from './ProtectedRoute';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/get-started" element={<GetStarted />} />
      <Route path="/careers" element={<CareerCatalog />} />
      <Route path="/colleges/:collegeId" element={<CollegeDetails />} />
      <Route path="/colleges" element={<Colleges />} />
      <Route path="/personal-details" element={
        <ProtectedRoute>
          <PersonalDetails />
        </ProtectedRoute>
      } />
      <Route path="/education-details" element={
        <ProtectedRoute>
          <EducationDetails />
        </ProtectedRoute>
      } />
      <Route path="/aptitude-assessment" element={
        <ProtectedRoute>
          <AptitudeAssessment />
        </ProtectedRoute>
      } />
      <Route path="/interest-assessment" element={
        <ProtectedRoute>
          <InterestAssessment />
        </ProtectedRoute>
      } />
      <Route path="/aptitude-result" element={
        <ProtectedRoute>
          <AptitudeResult />
        </ProtectedRoute>
      } />
      <Route path="/interest-result" element={
        <ProtectedRoute>
          <InterestResult />
        </ProtectedRoute>
      } />
      <Route path="/review" element={
        <ProtectedRoute>
          <ReviewAssessment />
        </ProtectedRoute>
      } />
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />
      <Route path="/admin" element={
        <ProtectedRoute adminOnly>
          <AdminDashboard />
        </ProtectedRoute>
      } />
    </Routes>
  );
}
