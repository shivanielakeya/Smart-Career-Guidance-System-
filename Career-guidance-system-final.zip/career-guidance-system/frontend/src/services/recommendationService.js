import apiClient from './apiClient';

export async function fetchRecommendations() {
  const response = await apiClient.get('/recommendations');
  return response.data;
}

export async function downloadRecommendationReport() {
  const response = await apiClient.get('/recommendations/export-pdf', { responseType: 'blob' });
  const url = window.URL.createObjectURL(response.data);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'career-recommendation-report.pdf';
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}
