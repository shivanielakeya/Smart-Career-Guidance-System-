import apiClient from './apiClient';

export async function translateTexts(texts, language) {
  if (language === 'en' || !texts.length) return texts;
  const response = await apiClient.post('/translate', { texts, language });
  return response.data.translations;
}