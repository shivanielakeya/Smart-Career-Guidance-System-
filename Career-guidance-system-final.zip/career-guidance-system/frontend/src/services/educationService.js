import apiClient from './apiClient';

export async function saveEducationRecord(payload, token) {
  const response = await apiClient.post('/education/me', payload, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
}

export async function fetchEducationRecords(token) {
  const response = await apiClient.get('/education/me', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
}
