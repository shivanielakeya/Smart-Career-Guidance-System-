import apiClient from './apiClient';

export async function sendChatMessage(messages, language = 'en') {
  const response = await apiClient.post('/chat', { messages, language });
  return response.data;
}