import apiClient from './apiClient';

export async function fetchColleges(params) {
  const response = await apiClient.get('/colleges', { params });
  return response.data;
}

export async function fetchCollege(collegeId) {
  const response = await apiClient.get(`/colleges/${collegeId}`);
  return response.data;
}