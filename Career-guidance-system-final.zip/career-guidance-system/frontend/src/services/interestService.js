import apiClient from './apiClient';

export async function fetchInterestQuestions() {
  const response = await apiClient.get('/interest/questions');
  return response.data;
}

export async function submitInterestAnswers(payload) {
  const response = await apiClient.post('/interest/submit', payload);
  return response.data;
}

export async function fetchInterestResult() {
  const response = await apiClient.get('/interest/result');
  return response.data;
}
