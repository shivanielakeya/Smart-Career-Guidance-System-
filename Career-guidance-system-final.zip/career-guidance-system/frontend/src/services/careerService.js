import apiClient from './apiClient';

export async function fetchCareers(params) {
  const response = await apiClient.get('/careers', { params });
  return response.data;
}

export async function fetchCareer(careerId) {
  const response = await apiClient.get(`/careers/${careerId}`);
  return response.data;
}
