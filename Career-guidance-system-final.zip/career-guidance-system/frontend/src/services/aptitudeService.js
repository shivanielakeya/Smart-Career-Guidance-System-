import apiClient from './apiClient';

export async function fetchAptitudeQuestions() {
  const response = await apiClient.get('/aptitude/questions');
  return response.data;
}

export async function submitAptitudeAnswers(payload) {
  const response = await apiClient.post('/aptitude/submit', payload);
  return response.data;
}

export async function fetchAptitudeResult() {
  const response = await apiClient.get('/aptitude/result');
  return response.data;
}
