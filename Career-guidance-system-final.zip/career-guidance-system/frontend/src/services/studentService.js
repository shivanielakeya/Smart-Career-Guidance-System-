import apiClient from './apiClient';

export async function saveStudentProfile(payload, token) {
  const response = await apiClient.post('/students/me', payload, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
}

export async function fetchStudentProfile(token) {
  const response = await apiClient.get('/students/me', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
}
