import apiClient from './apiClient';

export async function fetchAdminAnalytics() {
  const response = await apiClient.get('/admin/analytics');
  return response.data;
}

export async function fetchPowerBIConfig() {
  const response = await apiClient.get('/admin/analytics/powerbi-config');
  return response.data;
}

export async function recordAnalyticsEvent(payload) {
  const response = await apiClient.post('/analytics/events', payload);
  return response.data;
}