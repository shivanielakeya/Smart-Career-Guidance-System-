import { createContext, useContext, useEffect, useState } from 'react';
import { setAuthToken } from '../services/apiClient';

const AuthContext = createContext(null);

function getTokenRole(token) {
  try {
    return JSON.parse(window.atob(token.split('.')[1])).role || 'student';
  } catch {
    return 'student';
  }
}

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('auth_token'));
  const [user, setUser] = useState(() => {
    const storedToken = localStorage.getItem('auth_token');
    return storedToken ? { authenticated: true, role: getTokenRole(storedToken) } : null;
  });

  useEffect(() => {
    if (token) {
      setUser({ authenticated: true, role: getTokenRole(token) });
      localStorage.setItem('auth_token', token);
      setAuthToken(token);
    } else {
      setUser(null);
      localStorage.removeItem('auth_token');
      setAuthToken(null);
    }
  }, [token]);

  useEffect(() => {
    const handleUnauthorized = () => setToken(null);
    window.addEventListener('auth:unauthorized', handleUnauthorized);
    return () => window.removeEventListener('auth:unauthorized', handleUnauthorized);
  }, []);

  const login = (newToken) => {
    setToken(newToken);
  };

  const logout = () => {
    setToken(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, role: user?.role || 'student', login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  return useContext(AuthContext);
}
