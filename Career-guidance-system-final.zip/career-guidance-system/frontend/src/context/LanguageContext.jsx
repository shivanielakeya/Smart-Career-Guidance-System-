import { createContext, useContext, useState } from 'react';

const translations = {
  en: {
    home: 'Home', careers: 'Explore Careers', colleges: 'Colleges', howItWorks: 'How It Works', about: 'About', dashboard: 'Dashboard', admin: 'Admin', login: 'Login', logout: 'Logout', getStarted: 'Get Started', language: 'Language', english: 'English', tamil: 'தமிழ்', education: 'Education Details', personalDetails: 'Personal Details', fullName: 'Full Name', dateOfBirth: 'Date of Birth', gender: 'Gender', contactNumber: 'Contact Number', district: 'District', state: 'State', school: 'School/Institution', schoolType: 'School Type', parentName: 'Parent / Guardian Name', parentContact: 'Parent / Guardian Contact', saveEducation: 'Save Education', continueEducation: 'Continue to Education', saving: 'Saving...',
    careerCompass: 'Career Compass', smartGuidance: 'Smart guidance for students', toggleNavigation: 'Toggle navigation',
    register: 'Register', email: 'Email', password: 'Password', signingIn: 'Signing in...', creatingAccount: 'Creating account...',
    loginDescription: 'Sign in to continue your career assessment and dashboard.', registerDescription: 'Create your account to save your profile and recommendations.',
    startNow: 'Start now', later: 'Later', studentProfile: 'Student profile', assessment: 'Assessment',
    loading: 'Loading...', error: 'Unable to load this page right now.', backHome: 'Back to home', viewDetails: 'View Details',
    careerOpportunities: 'Career opportunities', allCareers: 'All careers', exploreCareersText: 'Explore careers, qualifications and the skills used in each path.', loadingCareers: 'Loading careers...', noCareers: 'No careers found for this category.', course: 'Course', skillsAptitude: 'Skills and aptitude', suitableStreams: 'Suitable streams', minimumPercentage: 'Minimum percentage', notSpecified: 'Not specified',
    collegeDirectory: 'College directory', exploreColleges: 'Explore colleges', searchCollege: 'Search by college, course or location', allCategories: 'All categories', loadingColleges: 'Loading colleges...', noColleges: 'No colleges found.', cutoff: 'Cutoff',
    aptitudeAssessment: 'Aptitude Assessment', interestAssessment: 'Interest Assessment', submitTest: 'Submit Test', submitInterests: 'Submit Interests', previous: 'Previous', next: 'Next', markReview: 'Mark for Review', clearAnswer: 'Clear Answer', studentDashboard: 'Student Dashboard', dashboardDescription: 'A personalized dashboard for your assessments, career matches and roadmap.', profileCompletion: 'Profile Completion', assessmentStatus: 'Assessment Status', profileEducation: 'Profile & Education', topCareerRecommendations: 'Top Career Recommendations', recommendedCourses: 'Recommended Courses', collegeRecommendations: 'College Recommendations', assessmentResults: 'Assessment Results', basedOnProfile: 'Based on your aptitude, interests, academic performance, and stream',
    aptitudeResult: 'Aptitude Result', interestResult: 'Interest Result', continueInterest: 'Continue to Interest Assessment', continueReview: 'Continue to Review',
    careerAssistant: 'Career Assistant', personalizedGuidance: 'Personalized guidance', closeAssistant: 'Close career assistant', openAssistant: 'Open career assistant', sendMessage: 'Send message', askCareer: 'Ask a career question...', thinking: 'Thinking...',
    logoutSession: 'Your session has expired. Please log in again.', assistantUnavailable: 'The assistant is unavailable right now. Please try again.',
  },
  ta: {
    home: 'முகப்பு', careers: 'தொழில்களை ஆராயுங்கள்', colleges: 'கல்லூரிகள்', howItWorks: 'எப்படி செயல்படுகிறது', about: 'எங்களைப் பற்றி', dashboard: 'டாஷ்போர்டு', admin: 'நிர்வாகம்', login: 'உள்நுழைவு', logout: 'வெளியேறு', getStarted: 'தொடங்குங்கள்', language: 'மொழி', english: 'English', tamil: 'தமிழ்', education: 'கல்வி விவரங்கள்', personalDetails: 'தனிப்பட்ட விவரங்கள்', fullName: 'முழுப் பெயர்', dateOfBirth: 'பிறந்த தேதி', gender: 'பாலினம்', contactNumber: 'தொடர்பு எண்', district: 'மாவட்டம்', state: 'மாநிலம்', school: 'பள்ளி / நிறுவனம்', schoolType: 'பள்ளி வகை', parentName: 'பெற்றோர் / பாதுகாவலர் பெயர்', parentContact: 'பெற்றோர் / பாதுகாவலர் தொடர்பு', saveEducation: 'கல்வியைச் சேமி', continueEducation: 'கல்விக்குத் தொடர்க', saving: 'சேமிக்கிறது...',
    careerCompass: 'தொழில் வழிகாட்டி', smartGuidance: 'மாணவர்களுக்கான சிறந்த வழிகாட்டுதல்', toggleNavigation: 'வழிசெலுத்தலை மாற்று',
    register: 'பதிவு செய்', email: 'மின்னஞ்சல்', password: 'கடவுச்சொல்', signingIn: 'உள்நுழைகிறது...', creatingAccount: 'கணக்கை உருவாக்குகிறது...',
    loginDescription: 'உங்கள் தொழில் மதிப்பீடு மற்றும் டாஷ்போர்டைத் தொடர உள்நுழையுங்கள்.', registerDescription: 'உங்கள் சுயவிவரம் மற்றும் பரிந்துரைகளைச் சேமிக்க கணக்கை உருவாக்குங்கள்.',
    startNow: 'இப்போது தொடங்கு', later: 'பின்னர்', studentProfile: 'மாணவர் சுயவிவரம்', assessment: 'மதிப்பீடு',
    loading: 'ஏற்றுகிறது...', error: 'இந்தப் பக்கத்தை இப்போது ஏற்ற முடியவில்லை.', backHome: 'முகப்புக்குத் திரும்பு', viewDetails: 'விவரங்களைக் காண்க',
    careerOpportunities: 'தொழில் வாய்ப்புகள்', allCareers: 'அனைத்து தொழில்களும்', exploreCareersText: 'ஒவ்வொரு பாதையிலும் உள்ள தொழில்கள், தகுதிகள் மற்றும் திறன்களை ஆராயுங்கள்.', loadingCareers: 'தொழில்களை ஏற்றுகிறது...', noCareers: 'இந்தப் பிரிவில் தொழில்கள் இல்லை.', course: 'பாடநெறி', skillsAptitude: 'திறன்கள் மற்றும் திறனறிவு', suitableStreams: 'பொருத்தமான பிரிவுகள்', minimumPercentage: 'குறைந்தபட்ச சதவீதம்', notSpecified: 'குறிப்பிடப்படவில்லை',
    collegeDirectory: 'கல்லூரி அடைவு', exploreColleges: 'கல்லூரிகளை ஆராயுங்கள்', searchCollege: 'கல்லூரி, பாடநெறி அல்லது இடம் மூலம் தேடுங்கள்', allCategories: 'அனைத்து பிரிவுகளும்', loadingColleges: 'கல்லூரிகளை ஏற்றுகிறது...', noColleges: 'கல்லூரிகள் இல்லை.', cutoff: 'கட்ஆஃப்',
    aptitudeAssessment: 'திறனறிவு மதிப்பீடு', interestAssessment: 'ஆர்வ மதிப்பீடு', submitTest: 'தேர்வைச் சமர்ப்பி', submitInterests: 'ஆர்வங்களைச் சமர்ப்பி', previous: 'முந்தையது', next: 'அடுத்தது', markReview: 'மறுபரிசீலனைக்கு குறி', clearAnswer: 'பதிலை அழி', studentDashboard: 'மாணவர் டாஷ்போர்டு', dashboardDescription: 'உங்கள் மதிப்பீடுகள், தொழில் பொருத்தங்கள் மற்றும் வழிகாட்டலுக்கான தனிப்பயன் டாஷ்போர்டு.', profileCompletion: 'சுயவிவர நிறைவு', assessmentStatus: 'மதிப்பீட்டு நிலை', profileEducation: 'சுயவிவரம் மற்றும் கல்வி', topCareerRecommendations: 'முக்கிய தொழில் பரிந்துரைகள்', recommendedCourses: 'பரிந்துரைக்கப்படும் பாடநெறிகள்', collegeRecommendations: 'கல்லூரி பரிந்துரைகள்', assessmentResults: 'மதிப்பீட்டு முடிவுகள்', basedOnProfile: 'உங்கள் திறனறிவு, ஆர்வங்கள், கல்வி செயல்திறன் மற்றும் பிரிவின் அடிப்படையில்',
    aptitudeResult: 'திறனறிவு முடிவு', interestResult: 'ஆர்வ முடிவு', continueInterest: 'ஆர்வ மதிப்பீட்டுக்குத் தொடர்க', continueReview: 'மதிப்பாய்வுக்குத் தொடர்க',
    careerAssistant: 'தொழில் உதவியாளர்', personalizedGuidance: 'தனிப்பயன் வழிகாட்டுதல்', closeAssistant: 'தொழில் உதவியாளரை மூடு', openAssistant: 'தொழில் உதவியாளரைத் திற', sendMessage: 'செய்தியை அனுப்பு', askCareer: 'தொழில் குறித்து கேளுங்கள்...', thinking: 'சிந்திக்கிறது...',
    logoutSession: 'உங்கள் அமர்வு முடிந்துவிட்டது. மீண்டும் உள்நுழையுங்கள்.', assistantUnavailable: 'உதவியாளர் இப்போது கிடைக்கவில்லை. மீண்டும் முயற்சிக்கவும்.',
  },
};

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState(() => localStorage.getItem('preferred_language') || 'en');

  const changeLanguage = (nextLanguage) => {
    const next = nextLanguage === 'ta' ? 'ta' : 'en';
    setLanguage(next);
    localStorage.setItem('preferred_language', next);
  };

  const t = (key) => translations[language][key] || translations.en[key] || key;

  return <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t }}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  return useContext(LanguageContext);
}