import { Link, useSearchParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchCareers } from '../services/careerService';
import { useLanguage } from '../context/LanguageContext';
import TranslatedText from '../components/TranslatedText';

export default function CareerCatalog() {
  const [searchParams] = useSearchParams();
  const category = searchParams.get('category') || '';
  const { t } = useLanguage();
  const [careers, setCareers] = useState([]);
  const [state, setState] = useState({ loading: true, error: '' });

  useEffect(() => {
    let active = true;
    setState({ loading: true, error: '' });
    fetchCareers(category ? { category } : undefined)
      .then((data) => {
        if (active) {
          setCareers(data);
          setState({ loading: false, error: '' });
        }
      })
      .catch(() => active && setState({ loading: false, error: 'Unable to load careers right now.' }));
    return () => { active = false; };
  }, [category]);

  return (
    <div className="mx-auto max-w-6xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
        <Link to="/#explore" className="text-sm font-semibold text-brand hover:text-brand-dark">{t('backHome')}</Link>
        <p className="mt-6 text-sm uppercase tracking-[0.25em] text-brand">{t('careerOpportunities')}</p>
        <h1 className="mt-2 text-3xl font-semibold text-slate-900">{category || t('allCareers')}</h1>
        <p className="mt-2 text-slate-600">{t('exploreCareersText')}</p>
      </div>

      {state.loading && <div className="rounded-3xl bg-white p-10 text-center text-slate-600">{t('loadingCareers')}</div>}
      {state.error && <div className="rounded-3xl bg-red-50 p-8 text-red-700">{state.error}</div>}
      {!state.loading && !state.error && careers.length === 0 && (
        <div className="rounded-3xl bg-white p-10 text-center text-slate-600">{t('noCareers')}</div>
      )}
      {!state.loading && !state.error && careers.length > 0 && (
        <div className="grid gap-6 md:grid-cols-2">
          {careers.map((career) => (
            <article key={career.id} className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200">
              <p className="text-xs uppercase tracking-[0.25em] text-slate-500">{career.category}</p>
              <h2 className="mt-2 text-xl font-semibold text-slate-900">{career.name}</h2>
              <p className="mt-3 text-sm text-slate-600"><TranslatedText text={career.description} /></p>
              <dl className="mt-5 space-y-2 text-sm text-slate-700">
                <div><dt className="font-semibold text-slate-900">{t('course')}</dt><dd><TranslatedText text={career.course} /></dd></div>
                <div><dt className="font-semibold text-slate-900">{t('skillsAptitude')}</dt><dd>{career.aptitude_match_categories?.join(', ') || t('notSpecified')}</dd></div>
                <div><dt className="font-semibold text-slate-900">{t('suitableStreams')}</dt><dd>{career.suitable_streams?.join(', ') || t('notSpecified')}</dd></div>
                <div><dt className="font-semibold text-slate-900">{t('minimumPercentage')}</dt><dd>{career.min_percentage}%</dd></div>
              </dl>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}