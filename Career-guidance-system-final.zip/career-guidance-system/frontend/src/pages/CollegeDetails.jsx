import { Link, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchCollege } from '../services/collegeService';
import useAuth from '../hooks/useAuth';
import { recordAnalyticsEvent } from '../services/analyticsService';

export default function CollegeDetails() {
  const { collegeId } = useParams();
  const { user } = useAuth();
  const [college, setCollege] = useState(null);
  const [state, setState] = useState({ loading: true, error: '' });

  useEffect(() => {
    let active = true;
    fetchCollege(collegeId)
      .then((data) => {
        if (active) {
          setCollege(data);
          setState({ loading: false, error: '' });
          if (user) recordAnalyticsEvent({ event_type: 'college_view', entity_id: data.id }).catch(() => {});
        }
      })
      .catch(() => active && setState({ loading: false, error: 'Unable to load institution details.' }));
    return () => { active = false; };
  }, [collegeId, user]);

  if (state.loading) return <div className="mx-auto max-w-4xl p-10 text-center text-slate-600">Loading institution details...</div>;
  if (state.error) return <div className="mx-auto max-w-4xl rounded-3xl bg-red-50 p-8 text-red-700">{state.error}</div>;

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
        <Link to="/dashboard" className="text-sm font-semibold text-brand hover:text-brand-dark">Back to dashboard</Link>
        <p className="mt-6 text-sm uppercase tracking-[0.25em] text-brand">Institution details</p>
        <h1 className="mt-2 text-3xl font-semibold text-slate-900">{college.name}</h1>
        <p className="mt-2 text-slate-600">{college.city}, {college.district}, {college.state}</p>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <section><h2 className="font-semibold text-slate-900">Available courses</h2><p className="mt-2 text-sm text-slate-600">{college.courses?.join(', ') || 'Not specified'}</p></section>
          <section><h2 className="font-semibold text-slate-900">Career opportunities</h2><p className="mt-2 text-sm text-slate-600">{college.career_opportunities?.join(', ') || 'Not specified'}</p></section>
          <section><h2 className="font-semibold text-slate-900">Eligibility cutoff</h2><p className="mt-2 text-sm text-slate-600">{college.cutoff}%</p></section>
          <section><h2 className="font-semibold text-slate-900">Category</h2><p className="mt-2 text-sm text-slate-600">{college.category}</p></section>
        </div>
      </div>
    </div>
  );
}