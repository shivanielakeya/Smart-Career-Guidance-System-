import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchColleges } from '../services/collegeService';
import { useLanguage } from '../context/LanguageContext';
import TranslatedText from '../components/TranslatedText';
import useAuth from '../hooks/useAuth';
import { recordAnalyticsEvent } from '../services/analyticsService';

export default function Colleges() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [filters, setFilters] = useState({ search: '', category: '' });
  const [colleges, setColleges] = useState([]);
  const [state, setState] = useState({ loading: true, error: '' });

  useEffect(() => {
    let active = true;
    setState({ loading: true, error: '' });
    const params = Object.fromEntries(Object.entries(filters).filter(([, value]) => value));
    fetchColleges(params)
      .then((data) => active && (setColleges(data), setState({ loading: false, error: '' })))
      .catch(() => active && setState({ loading: false, error: 'Unable to load colleges right now.' }));
    return () => { active = false; };
  }, [filters]);

  return (
    <div className="mx-auto max-w-6xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
        <Link to="/" className="text-sm font-semibold text-brand hover:text-brand-dark">{t('backHome')}</Link>
        <p className="mt-6 text-sm uppercase tracking-[0.25em] text-brand">{t('collegeDirectory')}</p>
        <h1 className="mt-2 text-3xl font-semibold text-slate-900">{t('exploreColleges')}</h1>
        <div className="mt-6 grid gap-3 md:grid-cols-[1fr_220px]">
          <input
            value={filters.search}
            onChange={(event) => setFilters((current) => ({ ...current, search: event.target.value }))}
            placeholder={t('searchCollege')}
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-brand"
          />
          <select
            value={filters.category}
            onChange={(event) => setFilters((current) => ({ ...current, category: event.target.value }))}
            className="rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-brand"
          >
            <option value="">{t('allCategories')}</option>
            <option value="Engineering">Engineering</option>
            <option value="Medical">Medical</option>
            <option value="General">General</option>
          </select>
        </div>
      </div>

      {state.loading && <div className="rounded-3xl bg-white p-10 text-center text-slate-600">{t('loadingColleges')}</div>}
      {state.error && <div className="rounded-3xl bg-red-50 p-8 text-red-700">{state.error}</div>}
      {!state.loading && !state.error && colleges.length === 0 && (
        <div className="rounded-3xl bg-white p-10 text-center text-slate-600">{t('noColleges')}</div>
      )}
      {!state.loading && !state.error && colleges.length > 0 && (
        <div className="grid gap-6 md:grid-cols-2">
          {colleges.map((college) => (
            <article key={college.id} className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200">
              <p className="text-xs uppercase tracking-[0.25em] text-slate-500">{college.category}</p>
              <h2 className="mt-2 text-xl font-semibold text-slate-900">{college.name}</h2>
              <p className="mt-2 text-sm text-slate-600"><TranslatedText text={`${college.city}, ${college.district}, ${college.state}`} /></p>
              <p className="mt-3 text-sm text-slate-600">{t('cutoff')}: {college.cutoff}%</p>
              <Link
                to={`/colleges/${college.id}`}
                onClick={() => { if (user) recordAnalyticsEvent({ event_type: 'college_selection', entity_id: college.id }).catch(() => {}); }}
                className="mt-5 inline-block rounded-full bg-brand px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-dark"
              >
                {t('viewDetails')}
              </Link>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}