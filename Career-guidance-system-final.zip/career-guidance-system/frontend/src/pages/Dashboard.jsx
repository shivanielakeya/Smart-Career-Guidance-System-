import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import useAuth from '../hooks/useAuth';
import { fetchStudentProfile } from '../services/studentService';
import { fetchEducationRecords } from '../services/educationService';
import { fetchAptitudeResult } from '../services/aptitudeService';
import { fetchInterestResult } from '../services/interestService';
import { downloadRecommendationReport, fetchRecommendations } from '../services/recommendationService';
import { useLanguage } from '../context/LanguageContext';

const INTEREST_COLORS = ['#2563eb', '#60a5fa', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'];

// Match score color helper
function getMatchColor(score) {
  if (score >= 85) return '#10b981'; // Green
  if (score >= 70) return '#f59e0b'; // Amber
  if (score >= 55) return '#f97316'; // Orange
  return '#ef4444'; // Red
}

// Match score badge component
function MatchBadge({ score }) {
  return (
    <div className="mt-3 flex items-center gap-2">
      <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-full transition-all"
          style={{ width: `${score}%`, backgroundColor: getMatchColor(score) }}
        />
      </div>
      <span className="text-sm font-semibold whitespace-nowrap" style={{ color: getMatchColor(score) }}>
        {score}%
      </span>
    </div>
  );
}

export default function Dashboard() {
  const { user, token } = useAuth();
  const { t } = useLanguage();
  const [profile, setProfile] = useState(null);
  const [education, setEducation] = useState([]);
  const [aptitude, setAptitude] = useState(null);
  const [interest, setInterest] = useState(null);
  const [recommendations, setRecommendations] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadErrors, setLoadErrors] = useState({});
  const [collegeFilter, setCollegeFilter] = useState('all'); // 'all', 'eligible', 'local'
  const [downloadState, setDownloadState] = useState({ loading: false, error: '' });

  const handleDownloadReport = async () => {
    setDownloadState({ loading: true, error: '' });
    try {
      await downloadRecommendationReport();
    } catch (error) {
      const status = error.response?.status;
      const message = status === 401
        ? 'Please log in again to download your report.'
        : status === 404
          ? 'Complete your profile and assessments before downloading the report.'
          : 'Unable to download the report. Please try again.';
      setDownloadState({ loading: false, error: message });
      return;
    }
    setDownloadState({ loading: false, error: '' });
  };

  useEffect(() => {
    if (!token) {
      setLoading(false);
      return;
    }

    Promise.allSettled([
      fetchStudentProfile(token),
      fetchEducationRecords(token),
      fetchAptitudeResult(),
      fetchInterestResult(),
      fetchRecommendations(),
    ]).then(([profileResult, educationResult, aptitudeResult, interestResult, recommendationResult]) => {
      const errors = {};

      if (profileResult.status === 'fulfilled') setProfile(profileResult.value);
      else if (profileResult.reason?.response?.status !== 404) errors.profile = true;

      if (educationResult.status === 'fulfilled') setEducation(educationResult.value);
      else if (educationResult.reason?.response?.status !== 404) errors.education = true;

      if (aptitudeResult.status === 'fulfilled') setAptitude(aptitudeResult.value);
      else if (aptitudeResult.reason?.response?.status !== 404) errors.aptitude = true;

      if (interestResult.status === 'fulfilled') setInterest(interestResult.value);
      else if (interestResult.reason?.response?.status !== 404) errors.interest = true;

      if (recommendationResult.status === 'fulfilled') setRecommendations(recommendationResult.value);
      else if (recommendationResult.reason?.response?.status !== 404) errors.recommendations = true;

      setLoadErrors(errors);
      setLoading(false);
    });
  }, [token]);

  const tenthRecord = education.find((record) => record.level === '10th') || null;
  const twelfthRecord = education.find((record) => record.level === '12th') || null;

  const steps = [
    { label: t('studentProfile'), done: Boolean(profile), path: '/personal-details' },
    { label: t('education'), done: education.length > 0, path: '/education-details' },
    { label: t('aptitudeAssessment'), done: Boolean(aptitude), path: '/aptitude-assessment' },
    { label: t('interestAssessment'), done: Boolean(interest), path: '/interest-assessment' },
    { label: t('assessmentResults'), done: Boolean(recommendations), path: '/review' },
  ];
  const completedCount = steps.filter((step) => step.done).length;
  const profileCompletion = Math.round((completedCount / steps.length) * 100);

  const aptitudeChartData = aptitude?.category_scores?.map((item) => ({
    category: item.category.replace(' Ability', '').replace(' Reasoning', '').replace(' Interpretation', ' Interp.'),
    fullCategory: item.category,
    score: item.score,
  })) || [];

  const interestChartData = interest?.scores
    ? [...interest.scores].sort((a, b) => b.score - a.score)
    : [];

  const hasAnyLoadError = Object.keys(loadErrors).length > 0;

  // Filter colleges based on selected filter
  const filteredColleges = recommendations?.colleges
    ? recommendations.colleges.filter((college) => {
        if (collegeFilter === 'eligible') return college.eligibility === true;
        if (collegeFilter === 'local') return college.location_match === true;
        return true;
      })
    : [];

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200 text-center text-slate-600">
          Loading your dashboard...
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      {hasAnyLoadError && (
        <div className="rounded-3xl border border-amber-200 bg-amber-50 px-6 py-4 text-sm text-amber-800">
          Some of your dashboard data could not be loaded right now. Refresh the page, or try again in a moment.
        </div>
      )}

      <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-slate-900">{t('studentDashboard')}</h1>
            <p className="mt-2 text-slate-600">{t('dashboardDescription')}</p>
          </div>
          <div className="rounded-3xl bg-slate-50 px-5 py-3 text-slate-700">
            {user ? `Welcome back${profile?.full_name ? `, ${profile.full_name}` : ''}!` : 'Please login to see your progress'}
          </div>
        </div>
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleDownloadReport}
            disabled={downloadState.loading || !recommendations}
            className="rounded-full bg-brand px-5 py-3 text-sm font-medium text-white shadow-lg shadow-brand/20 hover:bg-brand-dark disabled:cursor-not-allowed disabled:opacity-50"
          >
            {downloadState.loading ? 'Preparing PDF...' : 'Download Career Report'}
          </button>
          {downloadState.error && <p className="text-sm text-red-600">{downloadState.error}</p>}
        </div>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
            <p className="text-sm uppercase tracking-[0.25em] text-slate-500">{t('profileCompletion')}</p>
            <p className="mt-4 text-3xl font-semibold text-slate-900">{profileCompletion}%</p>
            <p className="mt-2 text-sm text-slate-600">{completedCount} of {steps.length} steps completed</p>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
            <p className="text-sm uppercase tracking-[0.25em] text-slate-500">10th Marks</p>
            <p className="mt-4 text-3xl font-semibold text-slate-900">
              {tenthRecord?.percentage != null ? `${tenthRecord.percentage}%` : '--'}
            </p>
            <p className="mt-2 text-sm text-slate-600">
              {tenthRecord ? `${tenthRecord.board || 'Board not specified'}` : 'Add your 10th details on the Education page.'}
            </p>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
            <p className="text-sm uppercase tracking-[0.25em] text-slate-500">12th Marks</p>
            <p className="mt-4 text-3xl font-semibold text-slate-900">
              {twelfthRecord?.percentage != null ? `${twelfthRecord.percentage}%` : '--'}
            </p>
            <p className="mt-2 text-sm text-slate-600">
              {twelfthRecord ? `${twelfthRecord.stream || 'General'}` : 'Add your 12th details on the Education page.'}
            </p>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
            <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Aptitude Summary</p>
            <p className="mt-4 text-3xl font-semibold text-slate-900">
              {aptitude?.overall_score != null ? `${aptitude.overall_score}%` : '--'}
            </p>
            <p className="mt-2 text-sm text-slate-600">
              {aptitude ? 'Overall aptitude score' : 'Complete the aptitude test to see your score.'}
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <h2 className="text-2xl font-semibold text-slate-900">{t('assessmentStatus')}</h2>
          <p className="text-sm text-slate-600">{completedCount} of {steps.length} steps completed</p>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {steps.map((step) => (
            <Link
              key={step.label}
              to={step.path}
              className={`rounded-3xl border p-4 text-sm font-medium transition ${
                step.done
                  ? 'border-brand/50 bg-brand/10 text-brand'
                  : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {step.label}
              <span className="mt-2 block text-xs uppercase tracking-[0.2em] text-slate-500">
                {step.done ? 'Completed' : 'Pending'}
              </span>
            </Link>
          ))}
        </div>
      </div>

      {profile && (
        <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
          <h2 className="text-2xl font-semibold text-slate-900">{t('profileEducation')}</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
              <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Student</p>
              <p className="mt-2 text-xl font-semibold text-slate-900">{profile.full_name}</p>
              <p className="mt-1 text-sm text-slate-600">{profile.school || 'School not provided'}</p>
              <p className="mt-1 text-sm text-slate-600">{profile.district ? `${profile.district}, ` : ''}{profile.state}</p>
            </div>
            <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
              <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Education</p>
              {education.length > 0 ? (
                education.map((record) => (
                  <p key={record.id} className="mt-2 text-sm text-slate-700">
                    {record.level} · {record.board || 'Board not specified'} · {record.marks_obtained}/{record.total_marks}
                    {record.percentage != null ? ` (${record.percentage}%)` : ''}
                  </p>
                ))
              ) : (
                <p className="mt-2 text-sm text-slate-600">No education records added yet.</p>
              )}
            </div>
          </div>
        </div>
      )}

      {recommendations?.careers && recommendations.careers.length > 0 && (
        <>
          <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
            <h2 className="text-2xl font-semibold text-slate-900">{t('topCareerRecommendations')}</h2>
            <p className="mt-1 text-sm text-slate-600">{t('basedOnProfile')}</p>
            
            <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {recommendations.careers.slice(0, 3).map((career) => (
                <div key={career.id} className="rounded-3xl border border-slate-200 p-6 hover:border-brand/50 hover:bg-slate-50/50 transition">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs uppercase tracking-[0.25em] text-slate-500">{career.category}</p>
                      <p className="mt-2 text-lg font-semibold text-slate-900">{career.name}</p>
                    </div>
                  </div>
                  
                  <p className="mt-3 text-sm text-slate-600 line-clamp-2">{career.description}</p>
                  
                  <MatchBadge score={Math.round(career.overall_score)} />
                  
                  <div className="mt-4 space-y-2">
                    {career.matched_interest_category && (
                      <p className="text-xs text-slate-600">
                        <span className="font-medium text-brand">Interest:</span> {career.matched_interest_category}
                      </p>
                    )}
                    {career.matched_aptitude_category && (
                      <p className="text-xs text-slate-600">
                        <span className="font-medium text-brand">Aptitude:</span> {career.matched_aptitude_category}
                      </p>
                    )}
                    {career.required_stream && (
                      <p className="text-xs text-slate-600">
                        <span className="font-medium text-brand">Stream:</span> {career.required_stream}
                      </p>
                    )}
                  </div>
                  
                  {career.explanation && (
                    <p className="mt-4 text-xs text-slate-600 border-t border-slate-200 pt-3">
                      {career.explanation}
                    </p>
                  )}
                  
                  <div className="mt-4 flex gap-2">
                    <span className="inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700">
                      {career.course}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {recommendations.careers.length > 3 && (
              <p className="mt-4 text-sm text-slate-600 text-center">
                Showing 3 of {recommendations.careers.length} career recommendations
              </p>
            )}
          </div>

          {recommendations.courses && recommendations.courses.length > 0 && (
            <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
              <h2 className="text-2xl font-semibold text-slate-900">{t('recommendedCourses')}</h2>
              <p className="mt-1 text-sm text-slate-600">Relevant courses from top institutions</p>
              
              <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {recommendations.courses.map((course) => (
                  <div key={course.id} className="rounded-3xl border border-slate-200 p-4">
                    <p className="text-xs uppercase tracking-[0.25em] text-slate-500">{course.category}</p>
                    <p className="mt-2 text-lg font-semibold text-slate-900">{course.name}</p>
                    <p className="mt-2 text-sm text-slate-600">{course.college}</p>
                    <p className="mt-1 text-sm text-slate-600">{course.duration}</p>
                    {course.eligibility_required && (
                      <p className="mt-2 text-xs font-medium text-brand">Eligibility: {course.eligibility_required}</p>
                    )}
                    {course.college_id ? (
                      <Link
                        to={`/colleges/${course.college_id}`}
                        className="mt-4 inline-block text-sm font-semibold text-brand hover:text-brand-dark"
                      >
                        Check institution details
                      </Link>
                    ) : (
                      <p className="mt-4 text-sm text-slate-500">Institution details unavailable</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {recommendations.colleges && recommendations.colleges.length > 0 && (
            <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 className="text-2xl font-semibold text-slate-900">{t('collegeRecommendations')}</h2>
                  <p className="mt-1 text-sm text-slate-600">Based on your academic eligibility and preferences</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setCollegeFilter('all')}
                    className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                      collegeFilter === 'all'
                        ? 'bg-brand text-white'
                        : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    All ({recommendations.colleges.length})
                  </button>
                  {recommendations.colleges.some((c) => c.eligibility) && (
                    <button
                      onClick={() => setCollegeFilter('eligible')}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                        collegeFilter === 'eligible'
                          ? 'bg-green-500 text-white'
                          : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Eligible ({recommendations.colleges.filter((c) => c.eligibility).length})
                    </button>
                  )}
                  {recommendations.colleges.some((c) => c.location_match) && (
                    <button
                      onClick={() => setCollegeFilter('local')}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                        collegeFilter === 'local'
                          ? 'bg-blue-500 text-white'
                          : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Local ({recommendations.colleges.filter((c) => c.location_match).length})
                    </button>
                  )}
                </div>
              </div>
              
              <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredColleges.map((college) => (
                  <div
                    key={college.id}
                    className={`rounded-3xl border p-4 transition ${
                      college.eligibility
                        ? 'border-green-200 bg-green-50/50'
                        : 'border-slate-200 bg-slate-50/50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-xs uppercase tracking-[0.25em] text-slate-500">{college.category}</p>
                        <p className="mt-2 text-lg font-semibold text-slate-900">{college.name}</p>
                      </div>
                      {college.location_match && (
                        <span className="rounded-full bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700">
                          📍 Local
                        </span>
                      )}
                    </div>
                    
                    <p className="mt-2 text-sm text-slate-600">{college.city}</p>
                    
                    <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-slate-500">Cutoff</p>
                        <p className="font-semibold text-slate-900">{college.cutoff}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Status</p>
                        {college.eligibility === true ? (
                          <p className="font-semibold text-green-600">Eligible ✓</p>
                        ) : college.eligibility === false ? (
                          <p className="font-semibold text-orange-600">Potential</p>
                        ) : (
                          <p className="font-semibold text-slate-600">--</p>
                        )}
                      </div>
                    </div>
                    
                    {college.match_percentage != null && (
                      <MatchBadge score={Math.round(college.match_percentage)} />
                    )}
                  </div>
                ))}
              </div>
              
              {filteredColleges.length === 0 && (
                <div className="mt-6 text-center text-slate-600">
                  <p>No colleges match your current filter.</p>
                  <button
                    onClick={() => setCollegeFilter('all')}
                    className="mt-2 text-sm font-medium text-brand hover:underline"
                  >
                    View all colleges
                  </button>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {!recommendations && (
        <div className="rounded-3xl bg-white p-10 text-center shadow-xl shadow-slate-200">
          <p className="text-slate-600">
            Complete your profile, education, aptitude and interest assessments to unlock your personalized career recommendations.
          </p>
          <Link
            to="/personal-details"
            className="mt-6 inline-flex rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark"
          >
            Continue Assessment
          </Link>
        </div>
      )}

      {aptitude && (
        <div className="rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
          <h2 className="text-2xl font-semibold text-slate-900">{t('assessmentResults')}</h2>
          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            {aptitudeChartData.length > 0 && (
              <div className="flex items-center justify-center">
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={aptitudeChartData}>
                    <PolarGrid stroke="#e2e8f0" />
                    <PolarAngleAxis dataKey="category" tick={{ fontSize: 12 }} />
                    <PolarRadiusAxis angle={90} domain={[0, 100]} />
                    <Radar name="Score" dataKey="score" stroke="#2563eb" fill="#2563eb" fillOpacity={0.6} />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            )}
            {interestChartData.length > 0 && (
              <div className="flex items-center justify-center">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={interestChartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, score }) => `${category}: ${score}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="score"
                    >
                      {interestChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={INTEREST_COLORS[index % INTEREST_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
