import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AssessmentSteps from '../components/AssessmentSteps';
import { fetchInterestQuestions, submitInterestAnswers } from '../services/interestService';
import { useLanguage } from '../context/LanguageContext';

export default function InterestAssessment() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchInterestQuestions()
      .then((data) => {
        setQuestions(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.response?.data?.detail || err.message || 'Unable to load questions');
        setLoading(false);
      });
  }, []);

  const currentQuestion = questions[currentIndex];
  const palette = useMemo(() => questions.map((question, index) => ({
    index,
    status: answers[question.id] ? 'Answered' : 'Unanswered',
  })), [questions, answers]);

  const handleAnswer = (option) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: option }));
  };

  const handleSubmit = async () => {
    if (submitting) return;
    setSubmitting(true);
    try {
      await submitInterestAnswers({ answers: Object.entries(answers).map(([question_id, answer]) => ({ question_id, answer })) });
      navigate('/interest-result');
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Unable to submit interest answers');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">{t('loading')}</div>;
  }

  if (error) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200 text-red-600">{error}</div>;
  }

  if (!currentQuestion) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">No interest questions available.</div>;
  }

  return (
    <div className="mx-auto max-w-6xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <AssessmentSteps />
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
            <h1 className="text-3xl font-semibold text-slate-900">{t('interestAssessment')}</h1>
          <p className="mt-2 text-slate-600">Choose the activities that interest you most. Your interest profile will help identify suitable career areas.</p>
        </div>
        <div className="rounded-3xl bg-slate-50 px-5 py-3 text-slate-700">
          Question {currentIndex + 1} of {questions.length}
        </div>
      </div>

      <div className="mt-8 rounded-3xl border border-slate-200 bg-slate-50 p-6">
        <h2 className="text-xl font-semibold text-slate-900">{currentQuestion.question}</h2>
        <div className="mt-6 grid gap-4">
          {currentQuestion.options.map((option) => (
            <button
              key={option.key}
              type="button"
              onClick={() => handleAnswer(option.key)}
              className={`w-full rounded-3xl border px-4 py-4 text-left shadow-sm ${answers[currentQuestion.id] === option.key ? 'border-brand bg-brand/10 text-slate-900' : 'border-slate-200 bg-white text-slate-700 hover:border-brand/80 hover:bg-slate-50'}`}
            >
              <span className="font-semibold uppercase tracking-[0.1em] text-slate-500">{option.label}</span>
              <span className="ml-3">{option.text}</span>
            </button>
          ))}
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <button
            type="button"
            disabled={currentIndex <= 0}
            onClick={() => setCurrentIndex((prev) => Math.max(prev - 1, 0))}
            className="rounded-full bg-white px-6 py-3 text-slate-700 shadow-sm hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {t('previous')}
          </button>
          <button
            type="button"
            disabled={currentIndex >= questions.length - 1}
            onClick={() => setCurrentIndex((prev) => Math.min(prev + 1, questions.length - 1))}
            className="rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark disabled:cursor-not-allowed disabled:opacity-50"
          >
            {t('next')}
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={submitting}
            className="rounded-full border border-slate-200 bg-white px-6 py-3 text-slate-700 shadow-sm hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {submitting ? t('loading') : t('submitInterests')}
          </button>
        </div>
      </div>

      <div className="mt-8 rounded-3xl border border-slate-200 bg-white p-6">
        <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Question Palette</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {palette.map((item) => (
            <button
              key={item.index}
              type="button"
              onClick={() => setCurrentIndex(item.index)}
              className={`rounded-3xl px-4 py-3 text-left text-sm ${item.status === 'Answered' ? 'bg-brand/10 text-brand' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'}`}
            >
              Question {item.index + 1}: {item.status}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
