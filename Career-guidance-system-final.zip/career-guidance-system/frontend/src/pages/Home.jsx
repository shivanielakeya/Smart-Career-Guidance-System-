import { Menu, X, ArrowRight } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchHealth } from '../services/api';

const categories = [
  'Engineering',
  'Computer Science & IT',
  'Medical & Healthcare',
  'Commerce',
  'Design',
  'Law',
  'Management',
  'Education',
];

export default function Home() {
  const [navOpen, setNavOpen] = useState(false);
  const [backendStatus, setBackendStatus] = useState('Checking API...');
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchHealth()
      .then((data) => setBackendStatus(data.message || 'API is available'))
      .catch((err) => {
        setBackendStatus('Backend unavailable');
        setError(err.message);
      });
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
      <header className="flex items-center justify-between border-b border-slate-200 pb-5">
        <div className="flex items-center gap-3">
          <div className="rounded-2xl bg-brand p-3 text-white shadow-lg shadow-brand/20">
            <ArrowRight className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-brand-dark">Career Compass</p>
            <p className="text-xs text-slate-500">Smart Guidance for Tamil Nadu Students</p>
          </div>
        </div>

        <nav className="hidden items-center gap-8 text-sm font-medium text-slate-700 md:flex">
          <a href="#home" className="hover:text-brand">Home</a>
          <a href="#explore" className="hover:text-brand">Explore Careers</a>
          <a href="#works" className="hover:text-brand">How It Works</a>
          <a href="#about" className="hover:text-brand">About</a>
          <a href="#login" className="hover:text-brand">Login</a>
          <a href="#get-started" className="rounded-full bg-brand px-4 py-2 text-white shadow-lg shadow-brand/20 hover:bg-brand-dark">Get Started</a>
        </nav>

        <button
          className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white text-slate-700 shadow-lg shadow-slate-200 md:hidden"
          type="button"
          onClick={() => setNavOpen(!navOpen)}
          aria-label="Toggle navigation"
        >
          {navOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </header>

      {navOpen && (
        <div className="mt-4 space-y-3 rounded-3xl bg-white p-4 shadow-lg shadow-slate-200 md:hidden">
          <a href="#home" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50">Home</a>
          <a href="#explore" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50">Explore Careers</a>
          <a href="#works" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50">How It Works</a>
          <a href="#about" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50">About</a>
          <a href="#login" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50">Login</a>
          <a href="#get-started" className="block rounded-xl bg-brand px-3 py-2 text-white">Get Started</a>
        </div>
      )}

      <main className="mt-12 grid gap-16 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
        <section id="home" className="space-y-8">
          <div className="max-w-2xl space-y-6">
            <p className="inline-flex rounded-full bg-brand/10 px-4 py-2 text-sm font-semibold text-brand">
              Future-ready guidance for Tamil Nadu students
            </p>
            <h1 className="text-4xl font-semibold tracking-tight text-slate-900 sm:text-5xl">
              Your Future Starts With the Right Direction.
            </h1>
            <p className="text-lg leading-8 text-slate-600">
              Discover careers, courses, colleges and personalized roadmaps based on your academic profile, aptitude, interests and strengths.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <a href="#get-started" className="inline-flex items-center justify-center rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 transition hover:bg-brand-dark">
                Get Started
              </a>
              <a href="#explore" className="inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-6 py-3 text-slate-700 shadow-sm transition hover:border-brand hover:text-brand">
                Explore Careers
              </a>
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div className="rounded-3xl bg-white p-6 shadow-lg shadow-slate-200">
              <h2 className="text-xl font-semibold text-slate-900">Personalized career evaluation</h2>
              <p className="mt-3 text-slate-600">Academic strengths, interests and aptitude are combined to recommend careers that fit your journey.</p>
            </div>
            <div className="rounded-3xl bg-white p-6 shadow-lg shadow-slate-200">
              <h2 className="text-xl font-semibold text-slate-900">College and cutoff guidance</h2>
              <p className="mt-3 text-slate-600">Browse course-aligned colleges with historical reference cutoffs for Tamil Nadu admissions.</p>
            </div>
          </div>
        </section>

        <section className="rounded-[2rem] bg-gradient-to-br from-brand to-sky-500 p-10 text-white shadow-2xl shadow-brand/20">
          <div className="space-y-4">
            <p className="text-sm uppercase tracking-[0.3em] text-sky-100">Career Guidance</p>
            <h2 className="text-3xl font-semibold">Build your academic roadmap with confidence.</h2>
            <p className="max-w-xl text-slate-100/90">Complete a guided assessment, receive explainable career matches, and download a professional report for your next step.</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-3xl bg-white/10 p-5">
                <p className="text-lg font-semibold">Assessment</p>
                <p className="mt-2 text-sm text-slate-100/90">Personal, academic and aptitude insights in one place.</p>
              </div>
              <div className="rounded-3xl bg-white/10 p-5">
                <p className="text-lg font-semibold">Roadmap</p>
                <p className="mt-2 text-sm text-slate-100/90">Step-by-step recommendations for skills and courses.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <section id="about" className="mt-20 space-y-8">
        <div className="mx-auto max-w-4xl text-center">
          <p className="text-sm uppercase tracking-[0.3em] text-brand">About the platform</p>
          <h2 className="mt-3 text-3xl font-semibold text-slate-900">A modern career guidance platform built for students in Tamil Nadu.</h2>
          <p className="mt-4 text-slate-600">We recommend careers with a balanced view of education, aptitude, interests and real career pathways, not just marks.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="rounded-3xl bg-white p-6 shadow-lg shadow-slate-200">
            <h3 className="text-xl font-semibold text-slate-900">What it does</h3>
            <p className="mt-3 text-slate-600">Collects your profile, analyzes strengths, and matches you to careers, courses, and colleges.</p>
          </div>
          <div className="rounded-3xl bg-white p-6 shadow-lg shadow-slate-200">
            <h3 className="text-xl font-semibold text-slate-900">Who it is for</h3>
            <p className="mt-3 text-slate-600">Students preparing for class 12, entrance exams, or college admission in Tamil Nadu.</p>
          </div>
          <div className="rounded-3xl bg-white p-6 shadow-lg shadow-slate-200">
            <h3 className="text-xl font-semibold text-slate-900">How recommendations are generated</h3>
            <p className="mt-3 text-slate-600">Using academic profile, aptitude scores, interest patterns, and career-fit metadata.</p>
          </div>
        </div>
      </section>

      <section id="works" className="mt-20">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-brand">How it works</p>
            <h2 className="mt-3 text-3xl font-semibold text-slate-900">A simple, guided path to career clarity.</h2>
          </div>
          <a href="#get-started" className="inline-flex items-center justify-center rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/20 hover:bg-brand-dark">
            Start your assessment
          </a>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {[
            {
              title: 'Tell Us About You',
              description: 'Enter personal and education details to build your profile.',
            },
            {
              title: 'Assess Your Strengths',
              description: 'Complete aptitude and interest assessments for deeper insights.',
            },
            {
              title: 'Discover Career Matches',
              description: 'Receive explainable career recommendations based on your profile.',
            },
            {
              title: 'Explore Courses & Colleges',
              description: 'See relevant courses, colleges, and historical cutoff guidance.',
            },
            {
              title: 'Build Your Roadmap',
              description: 'Get a personalized roadmap for skills, projects and admissions.',
            },
          ].map((item) => (
            <div key={item.title} className="rounded-3xl border border-slate-200 bg-white p-8 shadow-lg shadow-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-900">{item.title}</h3>
              <p className="mt-3 text-slate-600">{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="explore" className="mt-20">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-brand">Explore career opportunities</p>
            <h2 className="mt-3 text-3xl font-semibold text-slate-900">Browse career categories</h2>
          </div>
          <Link to="/careers" className="text-sm font-semibold text-brand hover:text-brand-dark">View all careers</Link>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {categories.map((category) => (
            <Link
              key={category}
              to={`/careers?category=${encodeURIComponent(category)}`}
              className="block cursor-pointer rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-brand/50 hover:shadow-lg"
            >
              <p className="font-semibold text-slate-900">{category}</p>
              <p className="mt-3 text-sm text-slate-600">Explore career paths, qualifications and future-ready course recommendations.</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-20 rounded-[2rem] bg-slate-950 px-8 py-12 text-white shadow-2xl shadow-slate-900/20">
        <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-slate-400">AI Career Assistant</p>
            <h2 className="mt-3 text-3xl font-semibold">Have a career question?</h2>
            <p className="mt-4 max-w-2xl text-slate-300">A future AI assistant will help answer questions about courses, careers, eligibility and college options with your profile context.</p>
            <div className="mt-8">
              <button className="rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark">
                Ask the AI Career Assistant
              </button>
            </div>
          </div>
          <div className="rounded-3xl border border-slate-800 bg-white/5 p-8">
            <p className="text-slate-300">AI Assistant is coming soon. For now, start your profile and recommendation journey.</p>
          </div>
        </div>
      </section>

      <section className="mt-10 rounded-3xl bg-white p-6 shadow-lg shadow-slate-200 md:max-w-xl">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-slate-900">Backend Status</p>
            <p className="mt-1 text-sm text-slate-600">{backendStatus}</p>
            {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
          </div>
        </div>
      </section>

      <footer className="mt-20 border-t border-slate-200 pt-10 text-slate-600">
        <div className="grid gap-6 md:grid-cols-4">
          <div>
            <p className="font-semibold text-slate-900">Smart Career Guidance</p>
            <p className="mt-3 text-sm">Helping Tamil Nadu students discover careers, courses and college pathways through thoughtful recommendations.</p>
          </div>
          <div>
            <p className="font-semibold text-slate-900">Explore</p>
            <ul className="mt-3 space-y-2 text-sm">
              <li><a href="#home" className="hover:text-brand">Home</a></li>
              <li><a href="#explore" className="hover:text-brand">Careers</a></li>
              <li><a href="#works" className="hover:text-brand">How It Works</a></li>
              <li><a href="#about" className="hover:text-brand">About</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold text-slate-900">Support</p>
            <ul className="mt-3 space-y-2 text-sm">
              <li><a href="#" className="hover:text-brand">Contact</a></li>
              <li><a href="#" className="hover:text-brand">Privacy</a></li>
              <li><a href="#" className="hover:text-brand">Terms</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold text-slate-900">Disclaimer</p>
            <p className="mt-3 text-sm text-slate-500">Career recommendations are educational guidance only and not guaranteed admission or outcomes.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
