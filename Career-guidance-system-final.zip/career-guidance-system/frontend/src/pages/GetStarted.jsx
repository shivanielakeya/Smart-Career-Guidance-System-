import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

export default function GetStarted() {
  const { t } = useLanguage();
  return (
    <div className="mx-auto max-w-5xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <h1 className="text-3xl font-semibold text-slate-900">{t('getStarted')}</h1>
      <p className="mt-3 text-slate-600">{t('registerDescription')}</p>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="text-xl font-semibold text-slate-900">{t('studentProfile')}</h2>
          <p className="mt-3 text-slate-600">Tell us about yourself and your education to unlock tailored recommendations.</p>
          <Link to="/personal-details" className="mt-6 inline-flex rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark">
            {t('startNow')}
          </Link>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="text-xl font-semibold text-slate-900">{t('assessment')}</h2>
          <p className="mt-3 text-slate-600">Complete aptitude and interest assessments to understand your strengths.</p>
          <Link to="/dashboard" className="mt-6 inline-flex rounded-full border border-slate-200 bg-white px-6 py-3 text-slate-700 shadow-sm hover:bg-slate-50">
            {t('later')}
          </Link>
        </div>
      </div>
    </div>
  );
}
