import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AssessmentSteps from '../components/AssessmentSteps';
import { fetchInterestResult } from '../services/interestService';
import { useLanguage } from '../context/LanguageContext';

export default function InterestResult() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchInterestResult()
      .then(setResult)
      .catch((err) => setError(err.response?.data?.detail || 'Unable to load interest result'));
  }, []);

  if (error) return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 text-red-600 shadow-xl shadow-slate-200">{error}</div>;
  if (!result) return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">{t('loading')}</div>;

  return (
    <div className="mx-auto max-w-6xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <AssessmentSteps />
      <h1 className="text-3xl font-semibold text-slate-900">{t('interestResult')}</h1>
      <p className="mt-2 text-slate-600">Your interest assessment has been saved successfully.</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {result.scores.map((item) => (
          <div key={item.category} className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
            <p className="text-sm uppercase tracking-[0.2em] text-slate-500">{item.category}</p>
            <p className="mt-2 text-2xl font-semibold text-slate-900">{item.score}%</p>
          </div>
        ))}
      </div>
      <button type="button" onClick={() => navigate('/review')} className="mt-8 rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark">
        {t('continueReview')}
      </button>
    </div>
  );
}