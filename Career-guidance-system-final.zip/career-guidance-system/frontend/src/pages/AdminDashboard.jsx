import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';
import apiClient from '../services/apiClient';
import AdminAnalytics from '../components/AdminAnalytics';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user, token } = useAuth();
  const [stats, setStats] = useState(null);
  const [students, setStudents] = useState([]);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user || !token) {
      navigate('/login');
      return;
    }

    const fetchData = async () => {
      try {
        const [statsRes, studentsRes, activityRes] = await Promise.all([
          apiClient.get('/admin/dashboard', { headers: { Authorization: `Bearer ${token}` } }),
          apiClient.get('/admin/students', { headers: { Authorization: `Bearer ${token}` } }),
          apiClient.get('/admin/activity-logs', { headers: { Authorization: `Bearer ${token}` } }),
        ]);
        setStats(statsRes.data.stats);
        setStudents(studentsRes.data);
        setActivity(activityRes.data);
      } catch (err) {
        setError(err.response?.data?.detail || 'Unable to load admin dashboard.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user, token, navigate]);

  if (loading) {
    return <div className="mx-auto max-w-6xl p-10 text-center text-slate-600">Loading admin dashboard...</div>;
  }

  if (error) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-red-50 p-8 text-red-700">{error}</div>;
  }

  return (
    <div className="mx-auto max-w-6xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      <div className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-brand">Admin Dashboard</p>
            <h1 className="mt-2 text-3xl font-semibold text-slate-900">Operations overview</h1>
          </div>
          <button
            type="button"
            onClick={() => window.open(`${import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api'}/admin/recommendations/export-pdf`, '_blank')}
            className="rounded-full bg-brand px-5 py-2.5 text-white shadow-lg shadow-brand/20 hover:bg-brand-dark"
          >
            Export PDF
          </button>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-5">
          {[
            ['Students', stats?.students ?? 0],
            ['Admins', stats?.admins ?? 0],
            ['Careers', stats?.careers ?? 0],
            ['Colleges', stats?.colleges ?? 0],
            ['Avg Aptitude', `${stats?.avg_aptitude_score ?? 0}%`],
          ].map(([label, value]) => (
            <div key={label} className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
              <p className="text-xs uppercase tracking-[0.2em] text-slate-500">{label}</p>
              <p className="mt-3 text-3xl font-semibold text-slate-900">{value}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        <div className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200">
          <h2 className="text-2xl font-semibold text-slate-900">Student management</h2>
          <div className="mt-6 space-y-4">
            {students.length === 0 ? (
              <p className="text-slate-600">No students registered yet.</p>
            ) : (
              students.slice(0, 8).map((student) => (
                <div key={student.id} className="flex items-center justify-between rounded-2xl border border-slate-200 p-4">
                  <div>
                    <p className="font-medium text-slate-900">{student.full_name || student.email}</p>
                    <p className="text-sm text-slate-600">{student.email}</p>
                  </div>
                  <div className="text-right text-sm text-slate-600">
                    <div>{student.aptitude_score != null ? `${student.aptitude_score}%` : 'No score'}</div>
                    <div>{student.education_count} records</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200">
          <h2 className="text-2xl font-semibold text-slate-900">Recent activity</h2>
          <div className="mt-6 space-y-4">
            {activity.length === 0 ? (
              <p className="text-slate-600">No activity available.</p>
            ) : (
              activity.slice(0, 8).map((log, index) => (
                <div key={`${log.email}-${index}`} className="rounded-2xl border border-slate-200 p-4">
                  <p className="font-medium text-slate-900">{log.name || log.email}</p>
                  <p className="text-sm text-slate-600">{log.role} • {log.user_email}</p>
                  <p className="mt-1 text-xs text-slate-500">{new Date(log.created_at).toLocaleString()}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <AdminAnalytics />

      <CatalogManagement token={token} />
    </div>
  );
}
