import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AssessmentSteps from '../components/AssessmentSteps';
import { fetchAptitudeResult } from '../services/aptitudeService';
import { fetchInterestResult } from '../services/interestService';
import { fetchRecommendations } from '../services/recommendationService';

export default function ReviewAssessment() {
  const navigate = useNavigate();
  const [aptitude, setAptitude] = useState(null);
  const [interest, setInterest] = useState(null);
  const [recommendations, setRecommendations] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([fetchAptitudeResult(), fetchInterestResult(), fetchRecommendations()])
      .then(([aptitudeData, interestData, recommendationData]) => {
        setAptitude(aptitudeData);
        setInterest(interestData);
        setRecommendations(recommendationData);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.response?.data?.detail || err.message || 'Unable to load review data');
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">Loading review...</div>;
  }

  if (error) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200 text-red-600">{error}</div>;
  }

  return (
    <div className="mx-auto max-w-6xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <AssessmentSteps />
      <h1 className="text-3xl font-semibold text-slate-900">Review Your Assessment</h1>
      <p className="mt-2 text-slate-600">Check your profile, education, aptitude, and interest summaries before final submission.</p>

      <section className="mt-8 rounded-3xl border border-slate-200 bg-slate-50 p-6">
        <h2 className="text-2xl font-semibold text-slate-900">Aptitude Summary</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          {aptitude?.category_scores?.map((item) => (
            <div key={item.category} className="rounded-3xl bg-white p-4 shadow-sm">
              <p className="text-sm uppercase tracking-[0.25em] text-slate-500">{item.category}</p>
              <p className="mt-2 text-2xl font-semibold text-slate-900">{item.score}%</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8 rounded-3xl border border-slate-200 bg-slate-50 p-6">
        <h2 className="text-2xl font-semibold text-slate-900">Interest Summary</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          {interest?.scores?.map((item) => (
            <div key={item.category} className="rounded-3xl bg-white p-4 shadow-sm">
              <p className="text-sm uppercase tracking-[0.25em] text-slate-500">{item.category}</p>
              <p className="mt-2 text-2xl font-semibold text-slate-900">{item.score}%</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-2xl font-semibold text-slate-900">Recommendation Preview</h2>
        <div className="mt-4 space-y-4">
          {recommendations?.careers?.slice(0, 3).map((career) => (
            <div key={career.id} className="rounded-3xl border border-slate-200 p-4">
              <p className="text-sm uppercase tracking-[0.25em] text-slate-500">{career.category}</p>
              <p className="mt-2 text-xl font-semibold text-slate-900">{career.name}</p>
              <p className="mt-2 text-sm text-slate-600">Match: {career.overall_score}%</p>
            </div>
          ))}
        </div>
      </section>

      <div className="mt-8 flex justify-end">
        <button
          type="button"
          onClick={() => navigate('/dashboard')}
          className="rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark"
        >
          Go to Dashboard
        </button>
      </div>
    </div>
  );
}
