import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AssessmentSteps from '../components/AssessmentSteps';
import { fetchAptitudeResult } from '../services/aptitudeService';
import { useLanguage } from '../context/LanguageContext';

export default function AptitudeResult() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchAptitudeResult()
      .then(setResult)
      .catch((err) => setError(err.response?.data?.detail || 'Unable to load aptitude result'));
  }, []);

  if (error) return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 text-red-600 shadow-xl shadow-slate-200">{error}</div>;
  if (!result) return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">{t('loading')}</div>;

  return (
    <div className="mx-auto max-w-6xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <AssessmentSteps />
      <h1 className="text-3xl font-semibold text-slate-900">{t('aptitudeResult')}</h1>
      <p className="mt-2 text-slate-600">Your aptitude assessment has been saved successfully.</p>
      <p className="mt-8 text-5xl font-semibold text-brand">{result.overall_score}%</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {result.category_scores.map((item) => (
          <div key={item.category} className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
            <p className="text-sm uppercase tracking-[0.2em] text-slate-500">{item.category}</p>
            <p className="mt-2 text-2xl font-semibold text-slate-900">{item.score}%</p>
          </div>
        ))}
      </div>
      <button type="button" onClick={() => navigate('/interest-assessment')} className="mt-8 rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark">
        {t('continueInterest')}
      </button>
    </div>
  );
}