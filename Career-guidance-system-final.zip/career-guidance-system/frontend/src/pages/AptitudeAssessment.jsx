import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AssessmentSteps from '../components/AssessmentSteps';
import { fetchAptitudeQuestions, submitAptitudeAnswers } from '../services/aptitudeService';
import { useLanguage } from '../context/LanguageContext';

const initialStatus = {
  unanswered: 'Unanswered',
  answered: 'Answered',
  marked: 'Marked',
};

export default function AptitudeAssessment() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [marked, setMarked] = useState(new Set());
  const [timer, setTimer] = useState(30 * 60);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const hasSubmittedRef = useRef(false);

  useEffect(() => {
    fetchAptitudeQuestions()
      .then((data) => {
        setQuestions(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.response?.data?.detail || err.message || 'Unable to load questions');
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    if (timer <= 0 && questions.length > 0) {
      handleSubmit();
      return;
    }

    const interval = setInterval(() => {
      setTimer((prev) => Math.max(prev - 1, 0));
    }, 1000);

    return () => clearInterval(interval);
  }, [timer, questions.length]);

  const currentQuestion = questions[currentIndex];

  const palette = useMemo(() => questions.map((question, index) => ({
    index,
    status: answers[question.id] ? initialStatus.answered : marked.has(question.id) ? initialStatus.marked : initialStatus.unanswered,
  })), [questions, answers, marked]);

  const handleAnswer = (option) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: option }));
  };

  const handleMark = () => {
    setMarked((prev) => new Set(prev).add(currentQuestion.id));
  };

  const handleClear = () => {
    setAnswers((prev) => {
      const copy = { ...prev };
      delete copy[currentQuestion.id];
      return copy;
    });
    setMarked((prev) => {
      const copy = new Set(prev);
      copy.delete(currentQuestion.id);
      return copy;
    });
  };

  const handleSubmit = async () => {
    if (submitting || hasSubmittedRef.current) return;
    hasSubmittedRef.current = true;
    setSubmitting(true);
    try {
      await submitAptitudeAnswers({ answers: Object.entries(answers).map(([question_id, answer]) => ({ question_id, answer })) });
      navigate('/aptitude-result');
    } catch (err) {
      hasSubmittedRef.current = false;
      setError(err.response?.data?.detail || err.message || 'Unable to submit answers');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmitClick = () => {
    const unanswered = questions.length - Object.keys(answers).length;
    const message = unanswered > 0
      ? `You have ${unanswered} unanswered question${unanswered === 1 ? '' : 's'}. Submit anyway?`
      : 'Submit your aptitude test? You will not be able to change your answers after this.';
    if (window.confirm(message)) {
      handleSubmit();
    }
  };

  if (loading) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">{t('loading')}</div>;
  }

  if (error) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200 text-red-600">{error}</div>;
  }

  if (!currentQuestion) {
    return <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">No questions available.</div>;
  }

  return (
    <div className="mx-auto max-w-6xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <AssessmentSteps />
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
            <h1 className="text-3xl font-semibold text-slate-900">{t('aptitudeAssessment')}</h1>
          <p className="mt-2 text-slate-600">Answer the questions within the allotted time. Your result will be calculated securely on the server.</p>
        </div>
        <div className="rounded-3xl bg-slate-50 px-5 py-3 text-slate-700">
          Time left: {Math.floor(timer / 60).toString().padStart(2, '0')}:{(timer % 60).toString().padStart(2, '0')}
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_0.6fr]">
        <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Question {currentIndex + 1} of {questions.length}</p>
              <h2 className="mt-2 text-xl font-semibold text-slate-900">{currentQuestion.question}</h2>
              <p className="mt-2 text-sm text-slate-600">Category: {currentQuestion.category} · Difficulty: {currentQuestion.difficulty}</p>
            </div>
            <button type="button" onClick={handleClear} className="rounded-full bg-white px-4 py-2 text-slate-700 shadow-sm hover:bg-slate-100">
              {t('clearAnswer')}
            </button>
          </div>

          <div className="mt-8 grid gap-4">
            {['option_a', 'option_b', 'option_c', 'option_d'].map((optionKey) => (
              <button
                key={optionKey}
                type="button"
                onClick={() => handleAnswer(optionKey)}
                className={`w-full rounded-3xl border px-4 py-4 text-left shadow-sm ${answers[currentQuestion.id] === optionKey ? 'border-brand bg-brand/10 text-slate-900' : 'border-slate-200 bg-white text-slate-700 hover:border-brand/80 hover:bg-slate-50'}`}
              >
                <span className="font-semibold uppercase tracking-[0.1em] text-slate-500">{optionKey.replace('option_', '').toUpperCase()}.</span>
                <span className="ml-3">{currentQuestion[optionKey]}</span>
              </button>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <button
              type="button"
              disabled={currentIndex <= 0}
              onClick={() => setCurrentIndex((prev) => Math.max(prev - 1, 0))}
              className="rounded-full bg-white px-6 py-3 text-slate-700 shadow-sm hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {t('previous')}
            </button>
            <button
              type="button"
              disabled={currentIndex >= questions.length - 1}
              onClick={() => setCurrentIndex((prev) => Math.min(prev + 1, questions.length - 1))}
              className="rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark disabled:cursor-not-allowed disabled:opacity-50"
            >
              {t('next')}
            </button>
            <button
              type="button"
              onClick={() => {
                setMarked((prev) => new Set(prev).add(currentQuestion.id));
                setCurrentIndex((prev) => Math.min(prev + 1, questions.length - 1));
              }}
              className="rounded-full border border-slate-200 bg-white px-6 py-3 text-slate-700 shadow-sm hover:bg-slate-50"
            >
              {t('markReview')}
            </button>
          </div>

          <button
            type="button"
            onClick={handleSubmitClick}
            disabled={submitting}
            className="mt-6 rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark disabled:cursor-not-allowed disabled:opacity-50"
          >
            {submitting ? t('loading') : t('submitTest')}
          </button>
        </div>

        <div className="space-y-5">
          <div className="rounded-3xl border border-slate-200 bg-white p-6">
            <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Progress</p>
            <div className="mt-4 grid gap-3">
              {palette.map((item) => (
                <button
                  type="button"
                  key={item.index}
                  onClick={() => setCurrentIndex(item.index)}
                  className={`w-full rounded-3xl px-4 py-3 text-left text-sm ${item.status === initialStatus.answered ? 'bg-brand/10 text-brand' : item.status === initialStatus.marked ? 'bg-yellow-100 text-yellow-700' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'}`}
                >
                  Question {item.index + 1}: {item.status}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-6">
            <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Answer Summary</p>
            <div className="mt-4 space-y-2 text-sm text-slate-700">
              <p>Answered: {Object.keys(answers).length}</p>
              <p>Marked for Review: {marked.size}</p>
              <p>Remaining: {questions.length - Object.keys(answers).length}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
