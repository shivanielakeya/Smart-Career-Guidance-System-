import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { saveEducationRecord } from '../services/educationService';
import useAuth from '../hooks/useAuth';
import AssessmentSteps from '../components/AssessmentSteps';
import { useLanguage } from '../context/LanguageContext';

export default function EducationDetails() {
  const navigate = useNavigate();
  const { token } = useAuth();
  const { t } = useLanguage();
  const [form, setForm] = useState({
    level: '12th',
    board: 'State Board',
    year: new Date().getFullYear(),
    total_marks: 500,
    marks_obtained: '',
    percentage: '',
    stream: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    setForm({ ...form, [event.target.name]: event.target.value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');

    try {
      await saveEducationRecord(form, token);
      navigate('/aptitude-assessment');
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Unable to save education details');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <AssessmentSteps />
      <h1 className="text-3xl font-semibold text-slate-900">{t('educationDetails')}</h1>
      <p className="mt-2 text-slate-600">Provide your 10th/12th record to help build your academic profile.</p>

      <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">Education Level</span>
            <select
              name="level"
              value={form.level}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            >
              <option value="10th">10th Standard</option>
              <option value="12th">12th Standard</option>
            </select>
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700">Stream / Group</span>
            <input
              name="stream"
              value={form.stream}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="Computer Science, Commerce, Bio-Maths"
            />
          </label>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">Board</span>
            <input
              name="board"
              value={form.board}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700">Year</span>
            <input
              type="number"
              name="year"
              value={form.year}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            />
          </label>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">Marks Obtained</span>
            <input
              type="number"
              name="marks_obtained"
              value={form.marks_obtained}
              onChange={handleChange}
              required
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700">Total Marks</span>
            <input
              type="number"
              name="total_marks"
              value={form.total_marks}
              onChange={handleChange}
              required
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            />
          </label>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">Percentage</span>
            <input
              type="number"
              step="0.01"
              name="percentage"
              value={form.percentage}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            />
          </label>
          <div className="flex items-end">
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark"
            >
              {loading ? t('saving') : t('saveEducation')}
            </button>
          </div>
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}
      </form>
    </div>
  );
}
