import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { saveStudentProfile } from '../services/studentService';
import useAuth from '../hooks/useAuth';
import AssessmentSteps from '../components/AssessmentSteps';
import { useLanguage } from '../context/LanguageContext';

export default function PersonalDetails() {
  const navigate = useNavigate();
  const { token } = useAuth();
  const { t } = useLanguage();
  const [form, setForm] = useState({
    full_name: '',
    date_of_birth: '',
    gender: '',
    email: '',
    contact_number: '',
    district: '',
    state: 'Tamil Nadu',
    school: '',
    school_type: '',
    parent_name: '',
    parent_contact: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    setForm({ ...form, [event.target.name]: event.target.value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');

    try {
      await saveStudentProfile(form, token);
      navigate('/education-details');
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Unable to save profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl rounded-3xl bg-white p-10 shadow-xl shadow-slate-200">
      <AssessmentSteps />
      <h1 className="text-3xl font-semibold text-slate-900">{t('personalDetails')}</h1>
      <p className="mt-2 text-slate-600">Fill in the student profile information to continue the assessment.</p>

      <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('fullName')}</span>
            <input
              name="full_name"
              value={form.full_name}
              onChange={handleChange}
              required
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="Student name"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('dateOfBirth')}</span>
            <input
              type="date"
              name="date_of_birth"
              value={form.date_of_birth}
              onChange={handleChange}
              required
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            />
          </label>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('gender')}</span>
            <select
              name="gender"
              value={form.gender}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-700 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            >
              <option value="">Prefer not to say</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </label>

          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('contactNumber')}</span>
            <input
              name="contact_number"
              value={form.contact_number}
              onChange={handleChange}
              type="tel"
              required
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="Mobile number"
            />
          </label>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('district')}</span>
            <input
              name="district"
              value={form.district}
              onChange={handleChange}
              required
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="District"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('state')}</span>
            <input
              name="state"
              value={form.state}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="State"
            />
          </label>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('school')}</span>
            <input
              name="school"
              value={form.school}
              onChange={handleChange}
              required
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="School name"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('schoolType')}</span>
            <input
              name="school_type"
              value={form.school_type}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="Public, private, matriculation"
            />
          </label>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('parentName')}</span>
            <input
              name="parent_name"
              value={form.parent_name}
              onChange={handleChange}
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="Parent or guardian name"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700">{t('parentContact')}</span>
            <input
              name="parent_contact"
              value={form.parent_contact}
              onChange={handleChange}
              type="tel"
              className="mt-2 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              placeholder="Parent mobile number"
            />
          </label>
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}
        <div className="flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => navigate('/dashboard')}
            className="rounded-full border border-slate-200 bg-white px-6 py-3 text-slate-700 shadow-sm hover:bg-slate-50"
          >
            Back to Dashboard
          </button>
          <button
            type="submit"
            disabled={loading}
            className="rounded-full bg-brand px-6 py-3 text-white shadow-lg shadow-brand/25 hover:bg-brand-dark"
          >
            {loading ? t('saving') : t('continueEducation')}
          </button>
        </div>
      </form>
    </div>
  );
}
