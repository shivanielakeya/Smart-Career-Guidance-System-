import { useEffect, useRef, useState } from 'react';
import { Bot, LoaderCircle, MessageCircle, Send, X } from 'lucide-react';
import useAuth from '../hooks/useAuth';
import { sendChatMessage } from '../services/chatService';
import { useLanguage } from '../context/LanguageContext';

export default function CareerChatbot() {
  const { user } = useAuth();
  const { language, t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([{ role: 'assistant', content: t('askCareer') }]);
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  useEffect(() => {
    setMessages((current) => current.length === 1 && current[0].role === 'assistant'
      ? [{ role: 'assistant', content: t('askCareer') }]
      : current);
  }, [language]);

  if (!user) return null;

  const handleSubmit = async (event) => {
    event.preventDefault();
    const content = draft.trim();
    if (!content || loading) return;

    const userMessage = { role: 'user', content };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setDraft('');
    setError('');
    setLoading(true);

    try {
      const result = await sendChatMessage(nextMessages, language);
      setMessages((current) => [...current, { role: 'assistant', content: result.message }]);
    } catch (requestError) {
      const status = requestError.response?.status;
      setError(status === 401 || status === 403
        ? t('logoutSession')
        : requestError.response?.data?.detail || t('assistantUnavailable'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 sm:bottom-8 sm:right-8">
      {open && (
        <section className="mb-4 flex h-[min(620px,calc(100vh-7rem))] w-[min(calc(100vw-2rem),390px)] flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl shadow-slate-400/30" aria-label={t('careerAssistant')}>
          <div className="flex items-center justify-between bg-brand px-5 py-4 text-white">
            <div className="flex items-center gap-3">
              <span className="rounded-2xl bg-white/15 p-2"><Bot className="h-5 w-5" /></span>
              <div>
                <h2 className="font-semibold">{t('careerAssistant')}</h2>
                <p className="text-xs text-white/75">{t('personalizedGuidance')}</p>
              </div>
            </div>
            <button type="button" onClick={() => setOpen(false)} className="rounded-full p-2 hover:bg-white/15" aria-label={t('closeAssistant')}>
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="min-h-0 flex-1 space-y-4 overflow-y-auto bg-slate-50 p-4" aria-live="polite">
            {messages.map((message, index) => (
              <div key={`${message.role}-${index}`} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-6 ${message.role === 'user' ? 'rounded-br-md bg-brand text-white' : 'rounded-bl-md bg-white text-slate-700 shadow-sm'}`}>
                  {message.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-sm text-slate-500"><LoaderCircle className="h-4 w-4 animate-spin" /> {t('thinking')}</div>
            )}
            {error && <p className="rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p>}
            <div ref={endRef} />
          </div>

          <form onSubmit={handleSubmit} className="border-t border-slate-200 bg-white p-3">
            <div className="flex items-end gap-2">
              <label className="sr-only" htmlFor="career-chat-message">{t('careerAssistant')}</label>
              <textarea
                id="career-chat-message"
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' && !event.shiftKey) {
                    event.preventDefault();
                    event.currentTarget.form.requestSubmit();
                  }
                }}
                rows={1}
                maxLength={2000}
                placeholder={t('askCareer')}
                className="max-h-28 min-h-11 flex-1 resize-none rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm text-slate-800 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
              />
              <button type="submit" disabled={loading || !draft.trim()} className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand text-white shadow-lg shadow-brand/20 hover:bg-brand-dark disabled:cursor-not-allowed disabled:opacity-50" aria-label={t('sendMessage')}>
                <Send className="h-4 w-4" />
              </button>
            </div>
          </form>
        </section>
      )}

      <button type="button" onClick={() => setOpen((current) => !current)} className="ml-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand text-white shadow-xl shadow-brand/30 transition hover:scale-105 hover:bg-brand-dark" aria-label={open ? t('closeAssistant') : t('openAssistant')}>
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>
    </div>
  );
}