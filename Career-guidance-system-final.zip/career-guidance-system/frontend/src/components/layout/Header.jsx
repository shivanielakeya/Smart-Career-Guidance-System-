import { Link, useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import useAuth from '../../hooks/useAuth';
import { useLanguage } from '../../context/LanguageContext';

export default function Header() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const { user, role, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();

  const navItems = [
    { label: t('home'), to: '/' },
    { label: t('careers'), to: '/careers' },
    { label: t('colleges'), to: '/colleges' },
    { label: t('howItWorks'), to: '/get-started' },
    { label: t('about'), to: '/get-started' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm shadow-sm shadow-slate-100">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-3">
          <div className="rounded-2xl bg-brand p-3 text-white shadow-lg shadow-brand/20">
            <span className="text-lg font-bold">SC</span>
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-brand-dark">{t('careerCompass')}</p>
            <p className="text-xs text-slate-500">{t('smartGuidance')}</p>
          </div>
        </Link>

        <nav className="hidden items-center gap-8 text-sm font-medium text-slate-700 md:flex">
          {navItems.map((item) => (
            <Link key={item.label} to={item.to} className="hover:text-brand">
              {item.label}
            </Link>
          ))}
          {user ? (
            <>
              <Link to="/dashboard" className="hover:text-brand">
                {t('dashboard')}
              </Link>
              {role === 'admin' && <Link to="/admin" className="hover:text-brand">{t('admin')}</Link>}
              <button
                type="button"
                onClick={() => {
                  logout();
                  navigate('/');
                }}
                className="rounded-full bg-slate-100 px-4 py-2 text-slate-700 hover:bg-slate-200"
              >
                {t('logout')}
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="hover:text-brand">
                {t('login')}
              </Link>
              <Link to="/register" className="rounded-full bg-brand px-4 py-2 text-white shadow-lg shadow-brand/20 hover:bg-brand-dark">
                {t('getStarted')}
              </Link>
            </>
          )}
        </nav>

        <label className="mr-3 hidden items-center gap-2 text-xs text-slate-500 md:flex">
          {t('language')}
          <select value={language} onChange={(event) => setLanguage(event.target.value)} className="rounded-full border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus:border-brand" aria-label={t('language')}>
            <option value="en">{t('english')}</option>
            <option value="ta">{t('tamil')}</option>
          </select>
        </label>
        <button
          type="button"
          className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white text-slate-700 shadow-lg shadow-slate-200 md:hidden"
          onClick={() => setOpen(!open)}
          aria-label={t('toggleNavigation')}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-200 bg-white p-4 md:hidden">
          <div className="space-y-3">
            <label className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-sm text-slate-700">
              {t('language')}
              <select value={language} onChange={(event) => setLanguage(event.target.value)} className="rounded-full border border-slate-200 bg-white px-3 py-1.5 outline-none" aria-label={t('language')}>
                <option value="en">{t('english')}</option>
                <option value="ta">{t('tamil')}</option>
              </select>
            </label>
            {navItems.map((item) => (
              <Link key={item.label} to={item.to} className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50" onClick={() => setOpen(false)}>
                {item.label}
              </Link>
            ))}
            {user ? (
              <>
                <Link to="/dashboard" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50" onClick={() => setOpen(false)}>
                  {t('dashboard')}
                </Link>
                {role === 'admin' && <Link to="/admin" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50" onClick={() => setOpen(false)}>{t('admin')}</Link>}
                <button
                  type="button"
                  onClick={() => {
                    logout();
                    setOpen(false);
                    navigate('/');
                  }}
                  className="w-full rounded-xl bg-slate-100 px-3 py-2 text-slate-700 hover:bg-slate-200"
                >
                  {t('logout')}
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="block rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50" onClick={() => setOpen(false)}>
                  {t('login')}
                </Link>
                <Link to="/register" className="block rounded-xl bg-brand px-3 py-2 text-white" onClick={() => setOpen(false)}>
                  {t('getStarted')}
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
