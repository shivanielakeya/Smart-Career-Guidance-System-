import { useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { fetchAdminAnalytics, fetchPowerBIConfig } from '../services/analyticsService';

const COLORS = ['#2563eb', '#0f766e', '#f59e0b', '#dc2626', '#7c3aed', '#0891b2', '#db2777'];

function ChartPanel({ title, children }) {
  return (
    <section className="rounded-3xl bg-white p-6 shadow-xl shadow-slate-200">
      <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
      <div className="mt-5 h-64">{children}</div>
    </section>
  );
}

export default function AdminAnalytics() {
  const [analytics, setAnalytics] = useState(null);
  const [powerBI, setPowerBI] = useState(null);
  const [state, setState] = useState({ loading: true, error: '' });

  useEffect(() => {
    Promise.all([fetchAdminAnalytics(), fetchPowerBIConfig()])
      .then(([data, powerBIConfig]) => {
        setAnalytics(data);
        setPowerBI(powerBIConfig);
        setState({ loading: false, error: '' });
      })
      .catch((error) => setState({ loading: false, error: error.response?.data?.detail || 'Unable to load analytics.' }));
  }, []);

  if (state.loading) return <section className="rounded-3xl bg-white p-8 text-slate-600">Loading analytics...</section>;
  if (state.error) return <section className="rounded-3xl bg-red-50 p-8 text-red-700">{state.error}</section>;

  const summary = analytics.summary;
  return (
    <section className="space-y-8">
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-brand">Power BI Analytics</p>
          <h2 className="mt-2 text-3xl font-semibold text-slate-900">Student insight center</h2>
          <p className="mt-2 text-slate-600">Live aggregates from the Career Guidance database.</p>
        </div>
        <p className="text-sm text-slate-500">Admin access only</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ['Registered students', summary.total_students],
          ['Profiles completed', summary.profile_completion],
          ['Aptitude completion', `${summary.aptitude_completion_rate}%`],
          ['Interest completion', `${summary.interest_completion_rate}%`],
        ].map(([label, value]) => (
          <div key={label} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-xs uppercase tracking-[0.2em] text-slate-500">{label}</p>
            <p className="mt-3 text-3xl font-semibold text-slate-900">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-8 xl:grid-cols-2">
        <ChartPanel title="Aptitude score distribution">
          <ResponsiveContainer width="100%" height="100%"><BarChart data={analytics.aptitude_score_distribution}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="range" /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="count" fill="#2563eb" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer>
        </ChartPanel>
        <ChartPanel title="Interest category distribution">
          <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={analytics.interest_category_distribution} dataKey="count" nameKey="category" outerRadius="75%" label>{analytics.interest_category_distribution.map((item, index) => <Cell key={item.category} fill={COLORS[index % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer>
        </ChartPanel>
        <ChartPanel title="Most recommended careers">
          <ResponsiveContainer width="100%" height="100%"><BarChart data={analytics.most_recommended_careers} layout="vertical" margin={{ left: 24 }}><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" allowDecimals={false} /><YAxis type="category" dataKey="name" width={120} /><Tooltip /><Bar dataKey="count" fill="#0f766e" radius={[0, 6, 6, 0]} /></BarChart></ResponsiveContainer>
        </ChartPanel>
        <ChartPanel title="Student stream distribution">
          <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={analytics.student_stream_distribution} dataKey="count" nameKey="stream" outerRadius="75%" label>{analytics.student_stream_distribution.map((item, index) => <Cell key={item.stream} fill={COLORS[index % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer>
        </ChartPanel>
        <ChartPanel title="Assessment completion trends">
          <ResponsiveContainer width="100%" height="100%"><LineChart data={analytics.assessment_completion_trends}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis allowDecimals={false} /><Tooltip /><Legend /><Line type="monotone" dataKey="aptitude" stroke="#2563eb" strokeWidth={3} /><Line type="monotone" dataKey="interest" stroke="#f59e0b" strokeWidth={3} /></LineChart></ResponsiveContainer>
        </ChartPanel>
        <section className="rounded-3xl bg-white p-6 shadow-xl shadow-slate-200">
          <h3 className="text-lg font-semibold text-slate-900">College engagement</h3>
          <div className="mt-5 grid gap-6 sm:grid-cols-2">
            {[['Most viewed', analytics.college_views], ['Most selected', analytics.college_selections]].map(([title, rows]) => (
              <div key={title}><p className="text-sm font-semibold text-slate-700">{title}</p>{rows.length ? rows.slice(0, 5).map((row) => <div key={row.name} className="mt-3 flex justify-between gap-3 text-sm"><span className="truncate text-slate-600">{row.name}</span><span className="font-semibold text-slate-900">{row.count}</span></div>) : <p className="mt-3 text-sm text-slate-500">No events recorded yet.</p>}</div>
            ))}
          </div>
        </section>
      </div>

      <section className="rounded-3xl bg-slate-950 p-6 text-white shadow-xl shadow-slate-300">
        <h3 className="text-lg font-semibold">Power BI report</h3>
        {powerBI?.configured ? <iframe title="Power BI career analytics" src={powerBI.embed_url} className="mt-5 h-[520px] w-full rounded-2xl border-0 bg-white" allowFullScreen /> : <p className="mt-3 max-w-3xl text-sm text-slate-300">Power BI is not configured. Set POWERBI_EMBED_URL, POWERBI_EMBED_TOKEN, and POWERBI_REPORT_ID in the backend environment, then restart the API.</p>}
      </section>
    </section>
  );
}