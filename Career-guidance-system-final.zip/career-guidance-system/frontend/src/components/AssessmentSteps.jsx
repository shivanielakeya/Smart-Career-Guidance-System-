import { Link, useLocation } from 'react-router-dom';

const steps = [
  { label: 'Personal', path: '/personal-details' },
  { label: 'Education', path: '/education-details' },
  { label: 'Aptitude', path: '/aptitude-assessment' },
  { label: 'Interests', path: '/interest-assessment' },
  { label: 'Review', path: '/review' },
];

export default function AssessmentSteps() {
  const { pathname } = useLocation();

  return (
    <div className="mb-8 rounded-3xl bg-slate-50 p-4 shadow-sm shadow-slate-200">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm font-semibold uppercase tracking-[0.25em] text-slate-500">Assessment Progress</p>
        <div className="text-sm text-slate-600">Complete all 5 steps to receive your recommendation.</div>
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-5">
        {steps.map((step, index) => {
          const active = pathname === step.path;
          const completed = steps.findIndex((item) => item.path === pathname) > index;
          return (
            <Link
              key={step.label}
              to={step.path}
              className={`rounded-3xl border px-4 py-3 text-center text-xs font-semibold uppercase tracking-[0.15em] transition ${
                active ? 'border-brand bg-brand text-white' : completed ? 'border-brand/50 bg-brand/10 text-brand' : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span className="block text-sm text-slate-900">{index + 1}</span>
              {step.label}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
