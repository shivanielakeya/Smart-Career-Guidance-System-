import { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { translateTexts } from '../services/translationService';

export default function TranslatedText({ text }) {
  const { language } = useLanguage();
  const [translated, setTranslated] = useState(text);

  useEffect(() => {
    let active = true;
    setTranslated(text);
    if (!text || language === 'en') return undefined;
    translateTexts([text], language)
      .then(([value]) => active && setTranslated(value || text))
      .catch(() => active && setTranslated(text));
    return () => { active = false; };
  }, [text, language]);

  return translated;
}
