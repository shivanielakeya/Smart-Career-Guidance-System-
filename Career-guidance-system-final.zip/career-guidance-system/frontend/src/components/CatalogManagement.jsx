import { useEffect, useState } from 'react';
import apiClient from '../services/apiClient';

const emptyCareer = {
  name: '', category: '', description: '', course: '', college: '',
  aptitude_match_categories: '', base_score: '60', suitable_streams: '', min_percentage: '50',
};

const emptyCollege = {
  name: '', category: '', city: '', district: '', state: '', cutoff: '50',
  courses: '', career_opportunities: '',
};

function listValue(value) {
  return Array.isArray(value) ? value.join(', ') : value || '';
}

function toList(value) {
  return value.split(',').map((item) => item.trim()).filter(Boolean);
}

export default function CatalogManagement({ token }) {
  const [careers, setCareers] = useState([]);
  const [colleges, setColleges] = useState([]);
  const [careerForm, setCareerForm] = useState(emptyCareer);
  const [collegeForm, setCollegeForm] = useState(emptyCollege);
  const [editingCareerId, setEditingCareerId] = useState(null);
  const [editingCollegeId, setEditingCollegeId] = useState(null);
  const [state, setState] = useState({ loading: true, saving: false, error: '', notice: '' });
  const headers = { Authorization: `Bearer ${token}` };

  const loadCatalog = async () => {
    const [careerResponse, collegeResponse] = await Promise.all([
      apiClient.get('/careers'),
      apiClient.get('/colleges'),
    ]);
    setCareers(careerResponse.data);
    setColleges(collegeResponse.data);
  };

  useEffect(() => {
    loadCatalog()
      .then(() => setState((current) => ({ ...current, loading: false })))
      .catch((error) => setState((current) => ({ ...current, loading: false, error: error.response?.data?.detail || 'Unable to load catalog.' })));
  }, []);

  const submitCareer = async (event) => {
    event.preventDefault();
    setState((current) => ({ ...current, saving: true, error: '', notice: '' }));
    const payload = {
      ...careerForm,
      base_score: Number(careerForm.base_score),
      min_percentage: Number(careerForm.min_percentage),
      aptitude_match_categories: toList(careerForm.aptitude_match_categories),
      suitable_streams: toList(careerForm.suitable_streams),
    };
    try {
      if (editingCareerId) await apiClient.put(`/careers/${editingCareerId}`, payload, { headers });
      else await apiClient.post('/careers', payload, { headers });
      await loadCatalog();
      setCareerForm(emptyCareer);
      setEditingCareerId(null);
      setState((current) => ({ ...current, saving: false, notice: 'Career saved.' }));
    } catch (error) {
      setState((current) => ({ ...current, saving: false, error: error.response?.data?.detail || 'Unable to save career.' }));
    }
  };

  const submitCollege = async (event) => {
    event.preventDefault();
    setState((current) => ({ ...current, saving: true, error: '', notice: '' }));
    const payload = {
      ...collegeForm,
      cutoff: Number(collegeForm.cutoff),
      courses: toList(collegeForm.courses),
      career_opportunities: toList(collegeForm.career_opportunities),
    };
    try {
      if (editingCollegeId) await apiClient.put(`/colleges/${editingCollegeId}`, payload, { headers });
      else await apiClient.post('/colleges', payload, { headers });
      await loadCatalog();
      setCollegeForm(emptyCollege);
      setEditingCollegeId(null);
      setState((current) => ({ ...current, saving: false, notice: 'College saved.' }));
    } catch (error) {
      setState((current) => ({ ...current, saving: false, error: error.response?.data?.detail || 'Unable to save college.' }));
    }
  };

  const removeCareer = async (career) => {
    if (!window.confirm(`Delete ${career.name}?`)) return;
    try {
      await apiClient.delete(`/careers/${career.id}`, { headers });
      await loadCatalog();
      setState((current) => ({ ...current, notice: 'Career deleted.', error: '' }));
    } catch (error) {
      setState((current) => ({ ...current, error: error.response?.data?.detail || 'Unable to delete career.' }));
    }
  };

  const removeCollege = async (college) => {
    if (!window.confirm(`Delete ${college.name}?`)) return;
    try {
      await apiClient.delete(`/colleges/${college.id}`, { headers });
      await loadCatalog();
      setState((current) => ({ ...current, notice: 'College deleted.', error: '' }));
    } catch (error) {
      setState((current) => ({ ...current, error: error.response?.data?.detail || 'Unable to delete college.' }));
    }
  };

  const updateCareerField = (field, value) => setCareerForm((current) => ({ ...current, [field]: value }));
  const updateCollegeField = (field, value) => setCollegeForm((current) => ({ ...current, [field]: value }));

  if (state.loading) return <div className="rounded-3xl bg-white p-8 text-slate-600">Loading career and college catalogs...</div>;

  return (
    <div className="space-y-8">
      {(state.error || state.notice) && (
        <div className={`rounded-3xl p-4 text-sm ${state.error ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'}`}>
          {state.error || state.notice}
        </div>
      )}

      <section className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div><h2 className="text-2xl font-semibold text-slate-900">Career management</h2><p className="mt-1 text-sm text-slate-600">View and manage database career records.</p></div>
          <button type="button" onClick={() => { setEditingCareerId(null); setCareerForm(emptyCareer); }} className="rounded-full bg-brand px-4 py-2 text-sm font-semibold text-white hover:bg-brand-dark">Add career</button>
        </div>
        <form onSubmit={submitCareer} className="mt-6 grid gap-3 md:grid-cols-2">
          {[
            ['name', 'Career name'], ['category', 'Category'], ['course', 'Course'], ['college', 'College'],
            ['base_score', 'Base score'], ['min_percentage', 'Minimum percentage'],
          ].map(([field, label]) => <input key={field} required value={careerForm[field]} onChange={(event) => updateCareerField(field, event.target.value)} placeholder={label} className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />)}
          <input required value={careerForm.aptitude_match_categories} onChange={(event) => updateCareerField('aptitude_match_categories', event.target.value)} placeholder="Aptitude categories, comma separated" className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />
          <input required value={careerForm.suitable_streams} onChange={(event) => updateCareerField('suitable_streams', event.target.value)} placeholder="Suitable streams, comma separated" className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />
          <textarea required value={careerForm.description} onChange={(event) => updateCareerField('description', event.target.value)} placeholder="Description" className="min-h-24 rounded-2xl border border-slate-200 px-4 py-3 text-sm md:col-span-2" />
          <button disabled={state.saving} className="rounded-full bg-slate-900 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50 md:col-span-2">{editingCareerId ? 'Update career' : 'Save career'}</button>
        </form>
        <div className="mt-8 space-y-3">
          {careers.map((career) => <div key={career.id} className="flex flex-col gap-3 rounded-2xl border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold text-slate-900">{career.name}</p><p className="text-sm text-slate-600">{career.category} · {career.course}</p></div><div className="flex gap-2"><button type="button" onClick={() => { setEditingCareerId(career.id); setCareerForm({ ...career, aptitude_match_categories: listValue(career.aptitude_match_categories), suitable_streams: listValue(career.suitable_streams), base_score: String(career.base_score), min_percentage: String(career.min_percentage) }); }} className="rounded-full border border-slate-200 px-3 py-1.5 text-sm">Edit</button><button type="button" onClick={() => removeCareer(career)} className="rounded-full border border-red-200 px-3 py-1.5 text-sm text-red-700">Delete</button></div></div>)}
        </div>
      </section>

      <section className="rounded-3xl bg-white p-8 shadow-xl shadow-slate-200">
        <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
          <div><h2 className="text-2xl font-semibold text-slate-900">College management</h2><p className="mt-1 text-sm text-slate-600">View and manage database college records.</p></div>
          <button type="button" onClick={() => { setEditingCollegeId(null); setCollegeForm(emptyCollege); }} className="rounded-full bg-brand px-4 py-2 text-sm font-semibold text-white hover:bg-brand-dark">Add college</button>
        </div>
        <form onSubmit={submitCollege} className="mt-6 grid gap-3 md:grid-cols-2">
          {[['name', 'College name'], ['category', 'Category'], ['city', 'City'], ['district', 'District'], ['state', 'State'], ['cutoff', 'Cutoff']].map(([field, label]) => <input key={field} required value={collegeForm[field]} onChange={(event) => updateCollegeField(field, event.target.value)} placeholder={label} className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />)}
          <input required value={collegeForm.courses} onChange={(event) => updateCollegeField('courses', event.target.value)} placeholder="Courses, comma separated" className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />
          <input required value={collegeForm.career_opportunities} onChange={(event) => updateCollegeField('career_opportunities', event.target.value)} placeholder="Career opportunities, comma separated" className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />
          <button disabled={state.saving} className="rounded-full bg-slate-900 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50 md:col-span-2">{editingCollegeId ? 'Update college' : 'Save college'}</button>
        </form>
        <div className="mt-8 space-y-3">
          {colleges.map((college) => <div key={college.id} className="flex flex-col gap-3 rounded-2xl border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold text-slate-900">{college.name}</p><p className="text-sm text-slate-600">{college.category} · {college.city}, {college.state}</p></div><div className="flex gap-2"><button type="button" onClick={() => { setEditingCollegeId(college.id); setCollegeForm({ ...college, courses: listValue(college.courses), career_opportunities: listValue(college.career_opportunities), cutoff: String(college.cutoff) }); }} className="rounded-full border border-slate-200 px-3 py-1.5 text-sm">Edit</button><button type="button" onClick={() => removeCollege(college)} className="rounded-full border border-red-200 px-3 py-1.5 text-sm text-red-700">Delete</button></div></div>)}
        </div>
      </section>
    </div>
  );
}